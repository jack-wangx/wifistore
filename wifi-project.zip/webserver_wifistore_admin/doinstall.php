<?php
	logFile(error.log, "进入判断是否存在卸载APP！");
	$appsName=array($appsName);
	$appsNamedb=array($appsNamedb);

	$userId=$J->data[0]->userId;
	//echo $userId."<br><br>";
	foreach($J->data as $obj){
		$appPackageName=$obj->appPackageName;
		array_push($appsName, $appPackageName);
	}
	$strsql="select appPagesname from APPExj where userID='$userId'";
	logFile(error.log, "APPExj 执行SQL语句！".$strsql);
	$resultap=mysql_query($strsql) or die("select contact failed:".mysql_error());
	while($rows=mysql_fetch_array($resultap))
	{
	  $appPagesname = $rows['appPagesname'];//把id存放到数组里
	  //echo $appsNamedb;
	  logFile(error.log, "APPExj 执行SQL语句后的appsNamedb=".$appsNamedb);
	  array_push($appsNamedb, $appPagesname);
	}
	$intersection = array_diff($appsNamedb,$appsName);
	//print_r($intersection);
	//print_r($appsName);
	//print_r($appsNamedb); 
	foreach ($intersection as $values) {
		logFile(error.log, "APPExj foreach执行是否存在");
		
		//echo $values;
		if(!is_array($values)){
			//echo "RRRR=".$values."<br>";
			$strsqlappexjbak="insert into APPExjBak (versionCode,userId,usedCount,usedTime,updateTimes,apiLevel,appPagesname,issystemApp,appName,uploadTime,versionName,addTime) select versionCode,userId,usedCount,usedTime,updateTimes,apiLevel,appPagesname,issystemApp,appName,uploadTime,versionName,addTime from APPExj where appPagesname='$values' and userID='$userId'";  
			//echo $strsqlappexjbak;
			$resultappbak = mysql_query($strsqlappexjbak) or die("insert APPExjBak where is_array($values)  failed:".mysql_error());
			$count = mysql_affected_rows();
			//echo "count=".$count."<br>";

			if($count != 0){
				
				$strsqlappexj="delete from APPExj where appPagesname='$values' and userID='$userId'";
				//echo $strsqlappexj;
				$resultapp=mysql_query($strsqlappexj) or die("insert APPExj where is_array($values) failed:".mysql_error());

				if(isset($resultappbak) && isset($resultapp)) logFile(error.log, "app不存在 刪除 APPExj 應用数据成功！");//echo "{flag':'doinstall'}";
				else logFile(error.log, "刪除 APPExj 應用数据出現問題！");//echo "{'flag':'999'}";
			}else{
				logFile(error.log, "刪除 APPExj 應用数据出現問題！"); //"{flag':'doinstall'}";
			}
		}
		if(is_array($values) || count($values)==0){
			//echo "XXXXX=".$values."<br>";
			logFile(error.log, "app不存在 APPExj 應用数据！");
		}else{
			logFile(error.log, "app不存在 APPExj 判断结束！");
		}
		
	}
?>