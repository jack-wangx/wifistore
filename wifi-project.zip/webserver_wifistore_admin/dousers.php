<?php
	foreach($J->data as $obj){
		$deviceModle=$obj->deviceModle;
		$activiatioDate=$obj->activiatioDate;
		$isActivity=$obj->isActivity;
		// $userId=$obj->userId;
		$longitude=$obj->longitude;
		$latitude=$obj->latitude;
		$projectId=$obj->projectId;
		$solutionProviders=$obj->solutionProviders;
		$deviceId=$obj->deviceId;
		$otaVersionCode=$obj->otaVersionCode;
		$sysVersionCode=$obj->sysVersionCode;
		// $wifiMacAddress=$obj->wifiMacAddress;

		$simCount=$obj->simCount;
		
		
		$hardwareId=$obj->hardwareId;
		$screenSize=$obj->screenSize;
		$networkOperator=$obj->a_networkOperator;
		$networkType=$obj->a_networkType;
		//echo $latitude."&&".$longitude;
		
		if($simCount==0){
			$sql_select_user="select userId from UserInfo where hardwareId='$hardwareId'";
			$sim1_iccid=0;
			$sim2_iccid=0;
		}elseif ($simCount==1) {
			$iccid=$obj->a_iccid;
			$sim1_iccid=$iccid[0];
			$sim2_iccid=0;
			$sql_select_user="select userId from UserInfo where (hardwareId='$hardwareId' and sim1_iccid='$sim1_iccid') or (hardwareId='$hardwareId' and sim2_iccid='$sim1_iccid')";
		}elseif ($simCount==2) {
			$iccid=$obj->a_iccid;
			$sim1_iccid=$iccid[0];
			$sim2_iccid=$iccid[1];
			$sql_select_user="select userId from UserInfo where hardwareId='$hardwareId' and (sim1_iccid='$sim1_iccid' or sim1_iccid='$sim2_iccid' or sim2_iccid='$sim1_iccid' or  sim2_iccid='$sim2_iccid')";
		}else{
			$sql_select_user="select userId from UserInfo where hardwareId='$hardwareId'";
		}
	
		
		
		$result=mysql_query($sql_select_user);
		$counts = mysql_num_rows($result);
		
		if($counts >0){
			$rows=mysql_fetch_array($result);
			$userId=$rows['userId'];
		    
		    $strsqluf="update UserInfo set otaversioncode='$otaVersionCode' where userId='".$userId."'";
		    $result=mysql_query($strsqluf) or die("update contact failed:".mysql_error());
		    if(strcasecmp($latitude, 'unknow')!=0 && strcasecmp($longitude, 'unknow')!=0){
		    	$strsql="insert into UserPath (userId,longitude,latitude,uploadTime) values ('$userId','$longitude','$latitude','$uploadTime')";
				
				$result=mysql_query($strsql) or die("insert contact failed:".mysql_error());
		    }
		    
			
		}else{
			$userId=create_guid();
			if(strcasecmp($latitude, 'unknow')==0||strcasecmp($longitude, 'unknow')==0){
				$provinceId=0;
			}else{
				$strsql="insert into UserPath (userId,longitude,latitude,uploadTime) values ('$userId','$longitude','$latitude','$uploadTime')";
				
				$resultpath=mysql_query($strsql) or die("insert UserPath failed:".mysql_error());
				$provinceId=getProvinceId($latitude,$longitude);
			}
			$axoValue="";
			$sql_get_axo_value="select axo_value from long_custom_axo_details where device='$deviceModle' and project='$projectId' and solutionProvider='$solutionProviders'";
			$axoResult=mysql_query($sql_get_axo_value);
			while($axoRow=mysql_fetch_array($axoResult)){
				$axoValue=$axoRow['axo_value'];
			}
			
			$strsqluser="insert into UserInfo (userId,deviceModel,activationDate,projectId,solutionProviders,deviceId,axo_value,otaversioncode,provinceId,simCount,hardwareId,sysVersionCode,sim1_iccid,sim2_iccid,screenSize) 
						values('$userId','$deviceModle','$activiatioDate','$projectId','$solutionProviders','$deviceId','$axo_value','$otaVersionCode','$provinceId',$simCount,'$hardwareId','$sysVersionCode','$sim1_iccid','$sim2_iccid',$screenSize)";  
			
			$resultuser=mysql_query($strsqluser);

			
			
			
		}
		insertOrUpdateSimInfo($userId,array($sim1_iccid,$sim2_iccid),$networkOperator,$networkType);

		echo "{'isHave':0,'flag':'0','userId':'$userId'}";
		break;
	}

	function insertOrUpdateSimInfo($userId,$sim_iccids,$networkOperator=array('0','0'),$networkType=array(0,0)){

		for($i=0;$i<count($sim_iccids);$i++){
			$sim_iccid=$sim_iccids[$i];
			if($sim_iccids[$i]!=0){
				$network_operator=$networkOperator[$i];
				$network_type=$networkType[$i];
				$sql_select_sim="select id from sim_info where userId='$userId' and sim_iccid='$sim_iccid'";
				$result=mysql_query($sql_select_sim);
				if(mysql_num_rows($result)>0){
					//update
					$rows=mysql_fetch_array($result);
					$id=$rows['id'];
					
					$sql_update_sim_info="update sim_info set network_perator='$network_operator',network_type='$network_type' where id=$id";
					mysql_query($sql_update_sim_info);
				}else{
					//insert
					$sql_insert_sim_info="insert into sim_info(userId,sim_iccid,network_perator,network_type) values('$userId','$sim_iccid','$network_operator','$network_type')";
					mysql_query($sql_insert_sim_info);
				}
			}
		}
		
	}

	function create_guid(){
			$charid=strtoupper(md5(uniqid(mt_rand(),true)));
			$hyphen = chr(45);
			$uuid = substr($charid, 0,8).$hyphen.substr($charid, 8, 4).$hyphen
					.substr($charid, 12, 4).$hyphen.substr($charid, 16, 4).$hyphen
					.substr($charid, 20, 12);
			return $uuid;
	}

	function getProvinceId($latitude,$longitude){
		$url="http://api.map.baidu.com/geocoder?location=$latitude,$longitude&output=json&key=4d8f2016c4d7aecee9deea9f22fa562e";
		//echo $url."<br>";
		$provinceData=urldecode(file_get_contents($url));
		//echo "provinceData=".$provinceData."<br>";
		$provinceData=json_decode($provinceData);
		$province=$provinceData->result->addressComponent->province;
		if(empty($province)){
			return 0;
		}
		$strsql="select provinceid from province where province='$province'";
		//echo $strsql;
		$result=mysql_query($strsql);
		if(mysql_num_rows($result)>0){
			$rows=mysql_fetch_array($result);
			return $rows['provinceid'];
		}else{
			return 0;
		}
		
	}
?>
