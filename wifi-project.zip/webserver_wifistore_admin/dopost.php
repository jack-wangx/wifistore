<?php
	include('controller/conn.php');

	if(!function_exists('json_decode'))
	{
	    include('JSON.php');
	    function json_encode($val)
	    {
	        $json = new Services_JSON();
	        return $json->encode($val);
	    }

	    function json_decode($val)
	    {
	        $json = new Services_JSON();
	        return $json->decode($val);
	    }
	}

	$appData= urldecode(file_get_contents("php://input"));
	//Log记录函数
	function logFile($filename,$msg){
		//打开文件
		$fd = fopen($filename,"a");
		//增加文件
		$str = "[".date("Y/m/d h:i:s",time())."]".$msg;
		//写入字符串
		fwrite($fd, $str."\n");
		//关闭文件
		fclose($fd);
	}

	//写入日志记录
	$str = $appData."<br>";
	//is_numeric()检测变量是否为数字或数字字符串
	if (!is_numeric($str)){
		logFile(error.log, $str);
	}
	$arrPath=explode("data=",$appData);
    	$appData = $arrPath[1];
    // echo $appData."<br>";
	$J=json_decode($appData);

	//var_dump($J);



	$type = $J->type;
	// echo $type;
	$wipeFlag = $J->wipeFlag;

	$uploadTime=$J->uploadTime;
	$solutionProvider=$J->solutionProvider;
	/*判断当前状态是否为用户信息*/
	if($type == 1000){
		include_once('dousers.php');

	}

	if($type == 1001){
		//is_numeric()检测变量是否为数字或数字字符串
		if (!is_numeric($str)){
			logFile(error.log, "type=1 已经进入<br>");
		}
		$demosu=json_decode($appData,true);

		$app=$demosu['appPackageName'];
		print_r($app);
		if (!is_numeric($str)){
			logFile(error.log, "J的数据为：".$app."<br>");
		}

		include('doinstall.php');
		$countAPP=count($J->data);
		$i=0;

		foreach($J->data as $obj){
			$apiLevel=$obj->apiLevel;
			$appName=$obj->appName;
			$appPackageName=$obj->appPackageName;
			$is_sys_app=$obj->is_sys_app;
			$usedTime=$obj->usedTime;
			$updateTimes=$obj->updateTimes;
			$userId=$obj->userId;
			$versionCode=$obj->versionCode;
			$versionName=$obj->versionName;
			$usedCount=$obj->usedCount;
			$versionName=$obj->versionName;
			$i++;
			//echo $i;
			/*判断wipeFlag属性执行不同操作*/
			if($wipeFlag == 1){
				//echo "wipeFlag == 1";
				include 'dowipe.php';
				//include('dowipe.php');
			}if($wipeFlag == 0){
				//echo "$wipeFlag == 0";
				include('donowipe.php');
			}if($i == $countAPP){
				echo "{'flag':'0'}";
			}

		}

	}
	if($type == 1002){
		logFile(error.log, "type=1002 已经进入");
		include 'dotask.php';
	}
	if($type == 1005){
		echo "dd";
		logFile(error.log, "type=1005 已经进入");
		logFile(error.log, "POST的数据为：".$appData."<br>");
		include 'calllog/docalls.php';
	}
	if($type == 1006){
		logFile(error.log, "type=1006 已经进入");
		logFile(error.log, "POST的数据为：".$appData."<br>");
		include 'calllog/processsms.php';
	}
	if($type == 1009){
		logFile(error.log, "type=1009 已经进入 POST的数据为：".$appData."<br>");
		include 'fota/otaUpgradeInfo.php';
	}
	if($type == 1010){
		logFile(error.log, "type=1010 已经进入 POST的数据为：".$appData."<br>");
		include 'currentUserInfo.php';
	}
	if($type == 1011){
		logFile(error.log, "type=1011 已经进入 POST的数据为：".$appData."<br>");
		include 'otaUpgradeInfo.php';
	}
	if($type == 1012){

		logFile(error.log, "type=1012 已经进入");
		include 'otaupdate.php';
	}


	if($type == 1013 || $type == 1014){
		$versionCode = $J->versionCode;
		logFile(error.log, "type=1016 已经进入");
		include 'sysapp/checkSystemAppUpgrade.php';
	}
	if($type==1015){
		logFile(error.log, "type=1015 已经进入");
		include 'getUserId.php';
	}


?>
