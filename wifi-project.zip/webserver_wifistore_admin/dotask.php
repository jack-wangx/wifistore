<?php

	$solutionProvider=$J->solutionProvider;
	$project=$J->projectId;
	$device=$J->deviceModle;
	// include 'conn/common_config.php';
	// $solutionProvider='chengkai';
	// $project='1234';
	// $device='test';
	if(empty($solutionProvider)||empty($project)||empty($device)){

		echo '{"flag":"1"}';

	}else{

		$sql_select_axo_value="select axo_value from long_custom_axo_details where solution_provider='$solutionProvider' and device='$device' and project='$project'";
		$result=mysql_query($sql_select_axo_value);
		if(mysql_num_rows($result)>0){
			$row=mysql_fetch_array($result);
			$axoValue=$row['axo_value'];

			$strsql="SELECT *
			FROM assignmentList a
			INNER JOIN task_app_map b on a.Id = b.assignmentId
			INNER JOIN task_axo_map c on a.Id = c.assignmentId
			INNER JOIN appPush d on b.appId = d.Id
			WHERE c.axo_value = '$axoValue'
			AND a.status = -1 order by rand() limit 1";

			$result=mysql_query($strsql);


			$count=mysql_num_rows($result);


			//根据服务端检索记录数返回给客户端不同结果
			$task=array();
			if($count > 0){
				$rows=mysql_fetch_array($result);
				$task['flag']=0;
				$versionCode=$rows['versionCode'];
				if(empty($versionCode)){
				    $versionCode=0;
				}
				$task['task']=array(
					'packageName' => $rows['packageName'],
					'appUrl' => 'http://' . $_SERVER['HTTP_HOST'] . $rows['appUrl'],
					'fileName' => $rows['fileName'],
					'type' => $rows['tasktype'],
					'appName' => $rows['appName'],
					'versionCode' => $versionCode,
					'description' => $rows['description'],
					'taskuniqueId' => $rows['taskuniqueId'],
					'picUrl' => 'http://' . $_SERVER['HTTP_HOST'] . $rows['picUrl'],
					'md5Value' => $rows['md5Value']
				);



			}else{
				$task['flag']=1;
			}
			echo json_encode($task)	;

		}else{
			echo '{"flag":"1"}';
		}
	}


?>
