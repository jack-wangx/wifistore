<?php
function isAdmin($groupId,$sp){
    $sql_select_group_name="select name from long_aro_groups where id=$groupId";
    
    $result=mysql_query($sql_select_group_name);
    if(mysql_num_rows($result)>0){
        $row=mysql_fetch_array($result);
        $name=$row['name'];
        
        if(strcasecmp($name, $sp.'_admin')==0){
            return 0;
        }else{
            return 1;
        }
    }else{
        return 2;
    }
}

function getAxoInfos($type,$groupId,$sp,$project,$device){
    
    switch ($type) {
        case 'admin':
            $axoDetailArray=getAxoDetailsArrayBySp($sp,$device,$project);
            break;
        case 'user':
            $axoDetailArray=getAxoDetailsArray($groupId,$device,$project);
            break;
    }
    return $axoDetailArray;
}

function getAxoDetailsArray($groupId,$device,$project){
    if(empty($groupId)){
        return;
    }
    mysql_query('set character set default');
    $sql_select_axo_details="select id,axo_value,device,project from long_axo la inner join long_custom_aro_group_axo_map lcagam on la.id=lcagam.axo_id inner join long_custom_axo_details lcad on la.value=lcad.axo_value where lcagam.aro_group_id=$groupId and hidden=0";
    
    if(!empty($device)&& strcasecmp($device, '0')!=0){
        $sql_select_axo_details.=" and device='$device'";
    }
    if(!empty($project)&& strcasecmp($project, '0')!=0){
        $sql_select_axo_details.=" and project='$project'";
    }
    
    $i=0;
    $result=mysql_query($sql_select_axo_details);
    while($row=mysql_fetch_array($result)){
        $axoArray[$i]=array(
            'id'=>$row['id'],
            'value'=> $row['axo_value'],
            'device'=> $row['device'],
            'project'=> $row['project']
            );
        $i++;
    }
    return $axoArray;
}
function getAxoDetailsArrayBySp($solutionProvider,$device,$project){
    if(empty($solutionProvider)){
        return;
    }
    mysql_query('set character set default');
    $sql_select_axo_details="select id,axo_value,device,project from long_axo la inner join long_custom_axo_details lcad on la.value=lcad.axo_value where solution_provider='$solutionProvider' and hidden=0";
    if(!empty($device)&&strcasecmp($device, '0')!=0){
        $sql_select_axo_details.=" and device='$device'";
    }
    if(!empty($project)&&strcasecmp($project, '0')!=0){
        $sql_select_axo_details.=" and project='$project'";
    }
    
    $i=0;
    $result=mysql_query($sql_select_axo_details);
    while($row=mysql_fetch_array($result)){
        $axoArray[$i]=array(
            'id'=>$row['id'],
            'value'=> $row['axo_value'],
            'device'=> $row['device'],
            'project'=> $row['project']
            );
        $i++;
    }
    return $axoArray;
}

function getSingleElementArray($elementsArray,$elementName){

    if(empty($elementsArray)){
        return;
    }
    $elementArray=array();
    for($i=0;$i<count($elementsArray);$i++){
        $row=$elementsArray[$i];
        $elementValue= $row[$elementName];
        if(!in_array($elementValue, $elementArray)){
            
            array_push($elementArray, $elementValue);
        }
        
    }
    
    return $elementArray;
}
?>
