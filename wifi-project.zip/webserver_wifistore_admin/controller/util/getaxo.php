<?php
	include_once('../conn.php');
	
	include_once('../util/axo_util.php');
	session_start();
	$action=$_POST['action'];
	$sp = $_SESSION['solutionProvider'];
	$groupId=$_SESSION['groupId'];

//$action='select';
//$sp = 'chengkai';
//$groupId=21;
	switch($action){
		case 'axo':
			$is_admin=isAdmin($groupId,$sp);
			if($is_admin==0){
				$axoDetailArray=getAxoInfos('admin',$groupId,$sp,NULL,NULL);
			}elseif ($is_admin==1) {
				$axoDetailArray=getAxoInfos('user',$groupId,$sp,NULL,NULL);
			}else{
				return json_encode(array('status'=>2001));
			}
			echo json_encode($axoDetailArray);
			break;
	}

	
	function logFile($filename,$msg){
		
			//打开文件
			$fd = fopen($filename,"a");
			//增加文件
			$str = "[".date("Y/m/d h:i:s",time())."]".$msg;
			//写入字符串
			fwrite($fd, $str."\n");
			//关闭文件
			fclose($fd);
	}
	
	
?>
