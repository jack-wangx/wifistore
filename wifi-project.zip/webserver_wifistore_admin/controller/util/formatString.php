<?php

	function passJudgement($str){
		if(empty($str)){
			return false;
		}
		if (preg_match('/^[a-zA-Z]\\w{8,20}$/', $str)) {
	    	return true;
		} else {
	    	return false;
		}
	}

	function strJudgement($str){
		if(empty($str)){
			return false;
		}
		if (preg_match('/^[a-zA-Z]\\w{4,20}$/', $str)) {
	    	return true;
		} else {
	    	return false;
		}
	}
	function projectAndDeviceJudgement($str){
		if(empty($str)){
			return false;
		}
		if (preg_match('/^[a-zA-Z]\\w{2,20}$/', $str)) {
	    	return true;
		} else {
	    	return false;
		}
	}
?>