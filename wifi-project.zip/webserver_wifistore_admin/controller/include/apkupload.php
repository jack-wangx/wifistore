<?php
	/*
	Uploadify 后台处理
	*/
	//设置上传目录
	$path = "/uploads/apk/";
	$tasktype=$_POST['taskvalue'];
	$device=$_POST['deviceid'];
	$project=$_POST['projectid'];
	$appsList=$_POST['apps'];
	if($device==-1){
		$device="";
	}
	if($project==-1){
		$project="";
	}
	mysql_query("set names utf8");
	if (!empty($_FILES) && $getvalue =="uploadapk") {

		$targetPath=$_SERVER['DOCUMENT_ROOT'];
		//得到上传的临时文件流
		$tempFile = $_FILES['Filedata']['tmp_name'];
		//允许的文件后缀
		$fileTypes = array('apk');
		//得到文件原名
		$fileName = iconv("UTF-8","UTF-8",date("ymdHis").$_FILES["Filedata"]["name"]);
		$size=$_FILES["Filedata"]["szie"];
		$fileParts = pathinfo($_FILES['Filedata']['name']);

		//$apk_file="/home/www/html/longfota/uploads/apk/130724004324momo_4.1c_c1.apk";

		$appUrl=$cfg_basehost."/".$path.$fileName;
		if(!in_array($fileParts['extension'], $fileTypes)){
			$arr['status']= 5001;
			echo json_encode($arr);
		}elseif ($size > 51200) {
			$arr['status']= 5002;
			echo json_encode($arr);
		}

		//$apk_file=$movePath;
		$apk_file=$targetPath.$path.$fileName;
		$apk_new_name=$fileName;
		$file_path=$targetPath.$path;

		if (!file_exists($file_path)) {
		    mkdir($file_path, 0777);
		}

		$resultvalue= move_uploaded_file($tempFile,$file_path.$fileName);
		include_once('getapk.php');
		//echo $movePath.$fileName.$cfg_basehost.$mkdirs;
		$value= readApkInfoFromFile($apk_file,$get_icon=true,$fileName,$cfg_basehost,$mkdirs);
		$iconspath=$value['result_icon'];
		$result_appName=$value['result_appName'];
		$result_version_code=$value['result_version_code'];
		$result_packgesName=$value['result_packgesName'];
		$md5value=md5_file($apk_file);
		$uuid=creatguid();
		$uploadtime=date("Y-m-d h:m:s");
		$strsql="insert into appPush (apkuuid,packageName,appUrl,appName,versionCode,picUrl,fileName,md5value,uploadtime) values  ('$uuid','$result_packgesName','$appUrl','$result_appName','$result_version_code','$iconspath','$fileName','$md5value','$uploadtime')";
		mysql_query($strsql) or die("insert failed:".mysql_error());
		$count=mysql_affected_rows();
		if($count>0){
			$arr['status']= 1000;
			$arr['picUrl']=$iconspath;
			$arr['appName']=$result_appName;
			$arr['uuid']=$uuid;
			echo json_encode($arr);
		}
	}elseif($getvalue =="addapk") {
			//{"formaction":"addapk","deviceid":"-1","projectid":"-1","taskvalue":"0","apps":[{"uuid":"669A6DF98327B87F2F0279BCDC744CE4","description":"CoolMarket可能是你喜欢的应用哦"}]}
			//$appsArray=json_decode($appsList);
			//$testvalue=var_dump($appsList);
			$createtime=date("Y-m-d h:m:s");
			foreach ($appsList as $key => $value) {
				$uuid=$value['uuid'];
				$description=$value['description'];
				if($uuid == null || $description==null){
					$arr['status']=9999;
					echo json_encode($arr);
				}else{
					$strsql="update appPush set description='$description' where apkuuid='$uuid'";
					mysql_query($strsql);
					$count=mysql_affected_rows();

					if($count > 0){
						$is_admin=isAdmin($groupId,$sp);
						if($is_admin==0){
							$axoDetailArray=getAxoInfos('admin',$groupId,$sp,$project,$device);
							$axoValueArray=getSingleElementArray($axoDetailArray,'value');

						}elseif ($is_admin==1) {
							$axoDetailArray=getAxoInfos('user',$groupId,$sp,$project,$device);
						// echo json_encode($axoDetailArray);
						}else{
							echo json_encode(array('status'=>2001));
						return;
						}
						/*$arr['status']="value=".json_encode($axoValueArray);
						echo json_encode($arr);*/

						$strsql="select * from assignmentList WHERE apkuuid='$uuid'" or die ("insert failed:".mysql_error());;
						$result=mysql_query($strsql);
						$count=mysql_num_rows($result);

						if($count < 1){
							$axoLen=sizeof($axoValueArray);
							$strsql="insert into assignmentList (apkuuid,tasktype,createtime) values ('$uuid',$tasktype,'$createtime')";
							mysql_query($strsql);

							$strsql="select id from assignmentList where apkuuid='$uuid'";
							$result=mysql_query($strsql);
							$row=mysql_fetch_array($result);
							$assignmentId=$row['id'];

							for($i=0;$i<$axoLen;$i++){
								$axo_value=$axoValueArray[$i];
								$axomap_strsql="insert into task_axo_map (assignmentId,axo_value) values($assignmentId,'$axo_value')";
								mysql_query($axomap_strsql);
							}
							$appmap_strsql="insert into task_app_map (assignmentId,appId) values($assignmentId,'$uuid')";
							mysql_query($appmap_strsql);
						}elseif ($count>0) {
							$axoLen=sizeof($axoValueArray);
							for($i=0;$i<$axoLen;$i++){
								$axo_value=$axoValueArray[$i];
								while ($row=mysql_fetch_array($result)) {
									$assignmentId=$row['id'];
									$axomap_strsql="insert into task_axo_map (assignmentId,axo_value) values($assignmentId,'$axo_value')";
									mysql_query($appmap_strsql);
								}
							}
							$appmap_strsql="insert into task_app_map (assignmentId,appId) values($assignmentId,'$uuid')";
							mysql_query($appmap_strsql);
						}


					}else{
						$arr['status']=9999;
						//echo json_encode($arr);
					}
				}
			}
			if($axoLen==$i){
			$arr['status']=1;
				echo json_encode($arr);
			}else{
			$arr['status']=0;
				echo json_encode($arr);
			}
			//$arr['status']="dddddddddd";
			//echo json_encode($arr);
	}elseif ($getvalue == "delapk") {
		$is_admin=isAdmin($groupId,$sp);
		if($is_admin==0){
			$axoDetailArray=getAxoInfos('admin',$groupId,$sp,$project,$device);
			$axoValueArray=getSingleElementArray($axoDetailArray,'value');

		}elseif ($is_admin==1) {
			$axoDetailArray=getAxoInfos('user',$groupId,$sp,$project,$device);
		// echo json_encode($axoDetailArray);
		}else{
			echo json_encode(array('status'=>2001));
		return;
		}

		foreach ($appsList as $key => $value) {
			$packageName=$value['packageName'];
			$description=$value['description'];
			$uuid=creatguid();
			$uploadtime=date("Y-m-d h:m:s");
			$select_task_app="select appName from appPush where packageName='$packageName'";
			$result=mysql_query($select_task_app);
			$rows=mysql_fetch_row($result);
			$appName=$rows['appName'];
			if($appName == "" || $appName ==null)
			{
				$appName="NO NAME";
			}
			$strsql="insert into appPush (apkuuid,description,appName,uploadtime) values  ('$uuid','$description','$appName','$uploadtime')";
			mysql_query($strsql);

			$strsql="select * from assignmentList WHERE apkuuid='$uuid'" or die ("insert failed:".mysql_error());;
			$result=mysql_query($strsql);
			$count=mysql_num_rows($result);

			if($count < 1){
				$axoLen=sizeof($axoValueArray);
				$strsql="insert into assignmentList (apkuuid,tasktype,createtime) values ('$uuid',$tasktype,'$uploadtime')";
				mysql_query($strsql);

				$strsql="select id from assignmentList where apkuuid='$uuid'";
				$result=mysql_query($strsql);
				$row=mysql_fetch_array($result);
				$assignmentId=$row['id'];

				for($i=0;$i<$axoLen;$i++){
					$axo_value=$axoValueArray[$i];
					$axomap_strsql="insert into task_axo_map (assignmentId,axo_value) values($assignmentId,'$axo_value')";
					mysql_query($axomap_strsql);
				}
				$appmap_strsql="insert into task_app_map (assignmentId,appId) values($assignmentId,'$uuid')";
				mysql_query($appmap_strsql);
			}elseif ($count>0) {
				$axoLen=sizeof($axoValueArray);
				for($i=0;$i<$axoLen;$i++){
					$axo_value=$axoValueArray[$i];
					while ($row=mysql_fetch_array($result)) {
						$assignmentId=$row['id'];
						$axomap_strsql="insert into task_axo_map (assignmentId,axo_value) values($assignmentId,'$axo_value')";
						mysql_query($appmap_strsql);
					}
				}
				$appmap_strsql="insert into task_app_map (assignmentId,appId) values($assignmentId,'$uuid')";
				mysql_query($appmap_strsql);
			}
		}
		if($axoLen==$i){
		$arr['status']=1;
			echo json_encode($arr);
		}else{
		$arr['status']=0;
			echo json_encode($arr);
		}

	}

	function creatguid() {
	    $charid = strtoupper(md5(uniqid(mt_rand(), true)));

	    $uuid =

	    substr($charid, 0, 8).

	    substr($charid, 8, 4).

	    substr($charid,12, 4).

	    substr($charid,16, 4).

	    substr($charid,20,12);

	    return $uuid;
	}
?>
