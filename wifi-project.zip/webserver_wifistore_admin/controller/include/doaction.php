<?php
function creatguid() {
    $charid = strtoupper(md5(uniqid(mt_rand(), true)));

    $uuid =

    substr($charid, 0, 8).

    substr($charid, 8, 4).

    substr($charid,12, 4).

    substr($charid,16, 4).

    substr($charid,20,12);

    return $uuid;
}

include '../conn.php';
$solutionProviders=$_POST['solutionProviders'];
$axo_value=$_POST['axo_value'];
$apps = $_POST['apps'];
$tasktype=$_POST['tasktype'];
$deleappvalue=$_POST['deleapp'];
$packageName=$_POST['packageName'];
$description=$_POST["description"];
$uploadtime=date('Y-m-d H:i:s',time());
switch($_POST['formaction']){
	case 'login':
		echo "login successful !";
	break;
	case 'add':
		if($tasktype == 2 || $tasktype== 3){
			//向assignmentList中添加任务列表
			for ($i=0; $i < count($apps); $i++) {
				$app = $apps[$i];
				$packageName = $app['packageName'];
				$strsql="select appName, appUrl, versionCode, picUrl, fileName, md5value, uploadtime
				from appPush where packageName='$packageName'";
				$result=mysql_query($strsql) or die("select appPush:".mysql_error());
				$myrow=mysql_fetch_array($result);
				$appUrl = $myrow['appUrl'];
				$appName=$myrow['appName'];
				$versionCode = $myrow['versionCode'];
				$iconUrl = $myrow['picUrl'];
				$fileName = $myrow['fileName'];
				$md5Value = $myrow['md5value'];
				$uploadtime = $myrow['uploadtime'];

				if($appName == "" || $appName ==null){
					$appName="NO NAME";
				}

				$appUUID = creatguid();
				$strsql="insert into appPush (apkuuid,packageName,appUrl,appName,
					versionCode,picUrl,fileName,md5value,uploadtime)
				values  ('$appUUID','$packageName','$appUrl','$appName',
					'$versionCode','$iconUrl','$fileName','$md5Value','$uploadtime')";
				//echo $strsql;
				$result=mysql_query($strsql) or die("insert failed:".mysql_error());
				$apps[$i]['uuid'] = $appUUID;
			}
			$assignmentUUID = creatguid();
			$strsql="insert into assignmentList (uuid, review, tasktype, provinceId, createTime, remark) values ('$assignmentUUID',0,$tasktype,0,now(),'$remark')";
			mysql_query($strsql) ;//or die("insert assignmentList:".mysql_error());

			//增加task_axo_map
			$strsql = "select Id from assignmentList where uuid='$assignmentUUID'";
			$rs = mysql_query($strsql) or die("select assignmentList:".mysql_error());
			$temp = mysql_fetch_array($rs);
			$assignmentId = $temp['Id'];
			$strsql = "insert task_axo_map (assignmentId, axo_value) values($assignmentId, '$axo_value')";
			mysql_query($strsql) or die("insert task_axo_map:".mysql_error());
			for ($i=0; $i < count($apps); $i++) {
				$app = $apps[$i];
				$appUUID = $app['uuid'];
				$strsql = "select Id from appPush where apkuuid='$appUUID'";
				$rs = mysql_query($strsql) or die("select appPush:".mysql_error());
				$temp = mysql_fetch_array($rs);
				$appId = $temp['Id'];
				$remark = $app['description'];
				//修改app描述信息
				$strsql = "update appPush set description='$remark' where Id=$appId";
				mysql_query($strsql) or die("update appPush:".mysql_error());
				//增加task_app_map
				$strsql = "insert task_app_map (assignmentId, appId) values($assignmentId, $appId)";
				mysql_query($strsql) or die("insert task_app_map:".mysql_error());
			}
				//echo "<meta http-equiv='refresh' content='3;url=../app/app_manage.php'>APP添加成功!正在返回......";
			// }
			echo('{"status":1}');
		} else {
			//echo "add successful !result_version_code=".$result_version_code;
			//$strsql="insert into appPush (packageName,appUrl,tasktype,appName,versionCode,description,picUrl,fileName,md5Value,taskuniqueId,uploadtime,appStatus) values ('$result_packgesName','$appurl',$tasktype,'$result_appName','$result_version_code','$description','$result_icon','$fileName','$md5file','$taskuniqueId','$uploadtime',1)";
			// $result=mysql_query($strsql) or die("insert failed:".mysql_error());
			// if(isset($result)){
			//插入assignmentList
			$assignmentUUID = creatguid();
			$strsql="insert into assignmentList (uuid, review, tasktype, provinceId, createTime, remark) values ('$assignmentUUID',0,$tasktype,0,now(),'$remark')";
			mysql_query($strsql) ;//or die("insert assignmentList:".mysql_error());

			//增加task_axo_map
			$strsql = "select Id from assignmentList where uuid='$assignmentUUID'";
			$rs = mysql_query($strsql) or die("select assignmentList:".mysql_error());
			$temp = mysql_fetch_array($rs);
			$assignmentId = $temp['Id'];
			$strsql = "insert task_axo_map (assignmentId, axo_value) values($assignmentId, '$axo_value')";
			mysql_query($strsql) or die("insert task_axo_map:".mysql_error());
			for ($i=0; $i < count($apps); $i++) {
				$app = $apps[$i];
				$appUUID = $app['uuid'];
				$strsql = "select Id from appPush where apkuuid='$appUUID'";
				$rs = mysql_query($strsql) or die("select appPush:".mysql_error());
				$temp = mysql_fetch_array($rs);
				$appId = $temp['Id'];
				$remark = $app['description'];
				//修改app描述信息
				$strsql = "update appPush set description='$remark' where Id=$appId";
				mysql_query($strsql) or die("update appPush:".mysql_error());
				//增加task_app_map
				$strsql = "insert task_app_map (assignmentId, appId) values($assignmentId, $appId)";
				mysql_query($strsql) or die("insert task_app_map:".mysql_error());
			}
				//echo "<meta http-equiv='refresh' content='3;url=../app/app_manage.php'>APP添加成功!正在返回......";
			// }
			echo('{"status":1}');
		}
		break;
	//系统自身逻辑暂时未更改
	case 'addsys':
	//echo "addsys";
		if($deleappvalue == 2 || $deleappvalue== 3){
			$strsql="select appName from sysPush where packageName='$packageName'";
			$result=mysql_query($strsql) or die("select sysPush:".mysql_error());
			$myrow=mysql_fetch_array($result);
			$appName=$myrow["appName"];

			if($appName == "" || $appName ==null){
				$appName="NO NAME";
			}

			$strsql="insert into sysPush (solutionProviders,projectId,packageName,tasktype,appName,description,taskuniqueId,uploadtime,appStatus) values ('$solutionProviders','$projectId','$packageName',$tasktype,'$appName','$description','$taskuniqueId','$uploadtime',0)";
			$result=mysql_query($strsql) or die("insert sysPush failed:".mysql_error());
			if(isset($result)){
				echo "<meta http-equiv='refresh' content='3;url=../sysapp/app_manage.php'>添加成功!正在返回......";
			}
		}else{
			//echo "add successful !result_version_code=".$result_version_code;
			$strsql="insert into sysPush (solutionProviders,projectId,packageName,appUrl,tasktype,appName,versionCode,description,picUrl,fileName,md5Value,taskuniqueId,uploadtime,appStatus,filesize) values ('$solutionProviders','$projectId','$result_packgesName','$appurl',$tasktype,'$result_appName','$result_version_code','$description','$result_icon','$fileName','$md5file','$taskuniqueId','$uploadtime',0,'$filesize')";
			//echo $strsql;
			$result=mysql_query($strsql) or die("insert sysPush failed:".mysql_error());
			if(isset($result)){
				//echo "<meta http-equiv='refresh' content='3;url=../sysapp/app_manage.php'>添加成功!正在返回......";
			}
		}

		break;
	case 'addrom':
		include '../conn/common_config.php';
		$strsql="select * from rominfo where versionCode='$versionCode'";
		$result=mysql_query();
		if($result>0){
			echo "该版本的rom包已存在，请重新命名版本号。<a href='#' onClick='javascript :history.back(-1);'>返回上一页</a>";
		}else{
			$strsqls="insert into rominfo (axo_value,versionCode,versionRemark,uploadtime,romurl,rompackgesname,delflag,md5value) values  ('$axo_value','$versionCode','$versionRemark','$uploadtime','$romurl','$rompackgesname',1,'$md5')";
			//echo $strsqls;
			mysql_query($strsqls);
			$count=mysql_affected_rows();
			echo "<meta http-equiv='refresh' content='3;url=../fota/ver_manage.php'>添加成功!正在返回......";
		}
		break;
}
?>
