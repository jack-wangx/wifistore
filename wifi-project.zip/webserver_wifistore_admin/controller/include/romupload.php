<?php
	/*
	Uploadify 后台处理
	*/

	//设置上传目录
	$path = "uploads/rom/";
	
	if (!empty($_FILES) && $getvalue =="uploadrom") {
		$targetPath=$_SERVER['DOCUMENT_ROOT'];
		//得到上传的临时文件流
		$tempFile = $_FILES['Filedata']['tmp_name'];
		//允许的文件后缀
		$fileTypes = array('zip');
		//得到文件原名
		$fileName = iconv("UTF-8","UTF-8",$_FILES["Filedata"]["name"]);
		$size=$_FILES["Filedata"]["szie"];
		$fileParts = pathinfo($_FILES['Filedata']['name']);
		//echo "tmppath=".$tmpFiles."path=".$targetPath."<br/>name=".$targetPath.$path.$fileName;
		$movePath=$targetPath.$path.$fileName;
		$resultvalue= move_uploaded_file($tempFile,$movePath);
		if(!is_dir($path))
		   mkdir($path);
		if ($resultvalue==1 && in_array($fileParts['extension'], $fileTypes)){
			//echo "success!";
			exec("unzip -j ".$movePath." system/build.prop -d ".$unzip_path);
			$versionCodeArray=exec("cat ".$unzip_path."/build.prop | grep ro.build.display.id");
			$versionArray=explode("=", $versionCodeArray);
			$versionCode=$versionArray[1];
			$solutionproviderArray=exec("cat ".$unzip_path."/build.prop | grep -v '#' | grep ro.fota.solutionprovider");
			$solutionprovider=explode("=", $solutionproviderArray);
			$sp=$solutionprovider[1];
			$projectidArray=exec("cat ".$unzip_path."/build.prop | grep -v '#' | grep ro.fota.projectid");
			$projectidArray=explode("=", $projectidArray);
			$projectid=$projectidArray[1];
			$deviceArray=exec("cat ".$unzip_path."/build.prop | grep -v '#' | grep ro.product.device");
			$deviceArray=explode("=",$deviceArray);
			$device=$deviceArray[1];

			if($versionCode =="" || $versionCode==null || $solutionprovider=="" || $solutionprovider==null || $projectid=="" || $projectid==null || $device==null || $device==""){
				echo '{"errorcode":4002}';
				return;
			}else{
				$strsql="select axo_value from long_custom_axo_details where device='$device' and project='$projectid' and solution_provider='$sp'";
				$result= mysql_query($strsql) or die("select lu:".mysql_error());;
				$myrow = mysql_fetch_array($result);
				$axo_value=$myrow["axo_value"];
				$rompackgesname=$fileName;
				$uploadtime=date("Y-m-d h:m:s");
				$md5value=md5_file($movePath);
				$strsqls="insert into rominfo (romuuid,axo_value,versionCode,uploadtime,romurl,rompackgesname,md5value,filesize) values  ('$timestamp$md5value','$axo_value','$versionCode','$uploadtime','$movePath','$rompackgesname','$md5value','$size')";
				echo $strsqls;
				mysql_query($strsqls);
				$count=mysql_affected_rows();
				if($count>0){
					echo '{"fileName":"'.$fileName.'","uuid":"'.$md5value.'","errorcode":1000}';
				}
				exec("rm -rf ".$unzip_path."/build.prop");
			}
			
		}else{
			echo '{"errorcode":9999}';
		}
	}

function creatguid() {
    $charid = strtoupper(md5(uniqid(mt_rand(), true)));

    $uuid =

    substr($charid, 0, 8).

    substr($charid, 8, 4).

    substr($charid,12, 4).

    substr($charid,16, 4).

    substr($charid,20,12);

    return $uuid;
}
?>
