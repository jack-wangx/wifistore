<?php
	session_start();
	header("Content-type:text/html;charset=utf-8");
	include_once("./config.cache.inc.php");
	include_once("../conn.php");
	include_once("../util/axo_util.php");
	$_SERVER['DOCUMENT_ROOT'] = dirname(__FILE__) . '/../..';
	$files=$_POST['typeCode'];//
	$getvalue=$_POST['formaction'];
	$timestamp=$_POST['timestamp'];
	$sp = $_SESSION['solutionProvider'];
	$groupId=$_SESSION['groupId'];
	if ($tasktype == 2 || $tasktype == 3) {
	    //include_once("doaction.php");
	}else{
		$apkdata=$_POST['data'];
		if($getvalue =="addapk" || $getvalue =="uploadapk" || $getvalue=="delapk"){
		    include('apkupload.php');
		}else if($getvalue =="uploadrom"){
		   include('romupload.php');
		}
	}

	function changeFileSize($filesize)
	{
	    if($filesize >= 1073741824)
	    {
		$filesize = round($filesize / 1073741824  ,2) . ' GiB';
	    } elseif($filesize >= 1048576)
	    {
		$filesize = round($filesize / 1048576 ,2) . ' MiB';
	    } elseif($filesize >= 1024)
	    {
		$filesize = round($filesize / 1024, 2) . ' KiB';
	    } else
	    {
		$filesize = $filesize . ' Bytes';
	    }
	    return $filesize;
	}
?>
