#!/bin/bash -x
export AAPT=$(cat $CURR/aapt.txt | head -n1)

if [ ! -f "$AAPT" ]; then
    for dir in $(find /var/www -name android-sdk-linux -type d 2>/dev/null); do
        if [ -f $dir/platform-tools/aapt ]; then
             AAPT="$dir/platform-tools/aapt"
             echo "$AAPT" > $CURR/aapt.txt
             exit
        fi
    done
    for dir in $(find /usr/local -name android-sdk-linux -type d 2>/dev/null); do
        if [ -f $dir/platform-tools/aapt ]; then
             AAPT="$dir/platform-tools/aapt"
             echo "$AAPT" > $CURR/aapt.txt
             exit
        fi
    done
    for dir in $(find /home -name android-sdk-linux -type d 2>/dev/null); do
        if [ -f $dir/platform-tools/aapt ]; then
             AAPT="$dir/platform-tools/aapt"
             echo "$AAPT" > $CURR/aapt.txt
             exit
        fi
    done
    for dir in $(find /opt -name android-sdk-linux -type d 2>/dev/null); do
        if [ -f $dir/platform-tools/aapt ]; then
             AAPT="$dir/platform-tools/aapt"
             echo "$AAPT" > $CURR/aapt.txt
             exit
        fi
    done
    for dir in $(find / -name android-sdk-linux -type d 2>/dev/null); do
        if [ -f $dir/platform-tools/aapt ]; then
             AAPT="$dir/platform-tools/aapt"
             echo "$AAPT" > $CURR/aapt.txt
             exit
        fi
    done
fi

if [ ! -f $AAPT ]; then
    unset AAPT
    echo null
fi
echo $AAPT
exit
