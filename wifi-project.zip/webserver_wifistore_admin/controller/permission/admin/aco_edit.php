<?php
		
		// getAcoList(21,null);
		function getAcoList($group_id,$filter_aco_ids){

			
			$sql_search_aco_list="select long_aco.id, long_aco_map.value, long_acl.allow,max(long_acl.updated_date),
						long_aco_map.section_value, long_aco.name from long_aco_map  
						inner join long_aro_groups_map on 
						long_aro_groups_map.acl_id=long_aco_map.acl_id inner join long_aco  
						on long_aco_map.value= long_aco.value and 
						long_aco_map.section_value=long_aco.section_value 
						inner join long_acl on long_aco_map.acl_id=long_acl.id 
						where group_id=$group_id ";
			
			if(!empty($filter_aco_ids)){
				$acl_ids_sql = implode(',', $filter_aco_ids);
				$sql_search_aco_list .=' and long_aco.id NOT IN ('. $acl_ids_sql . ')';
			}
			$sql_search_aco_list.=' group by name';
				//echo $sql_search_aco_list;
			// logFile('error_log',$sql_search_aco_list);
				$result = mysql_query($sql_search_aco_list);
				// $i=1;
			$arr=array();
			while ($rows=mysql_fetch_array($result)) {
					
				array_push($arr, array('id'  => $rows['id'],
	 									'name' => $rows['name'],
										'value' => $rows['value'],
										'allow' =>$rows['allow'],
										'section_value' => $rows['section_value']));
					
			}
			return $arr;

		}

		

		function getFilterAcoIds($group_id){

			$sql_search_aco_list="select long_aco.id, long_aco_map.value, max(long_acl.updated_date),
						long_aco_map.section_value, long_aco.name from long_aco_map  
						inner join long_aro_groups_map on 
						long_aro_groups_map.acl_id=long_aco_map.acl_id inner join long_aco  
						on long_aco_map.value= long_aco.value and 
						long_aco_map.section_value=long_aco.section_value 
						inner join long_acl on long_aco_map.acl_id=long_acl.id 
						where group_id=$group_id group by name";
			$result = mysql_query($sql_search_aco_list);
			$aco_ids=array();
			while ($rows=mysql_fetch_array($result)) {
				array_push($aco_ids, $rows['id']);
			}
			return $aco_ids;

		}
		

		
		
?>