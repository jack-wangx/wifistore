
<?php
	header("Content-type: text/html; charset=utf-8"); 
	require_once("../../gacl/admin/gacl_admin.inc.php");
	include_once('allow.php');
	include_once('../../util/formatString.php');
	if(!getPermission()){
		return;
	}
		 $action=$_POST["action"];
		// $action='update';
		session_start();
		switch ($action) {
			case 'insert':
				$group_name=$_POST['group_name'];
				$group_parent_id=$_POST['group_parent_id'];

				if(empty($group_name) || empty($group_parent_id)){
					echo json_encode(array('status'  => 2001));
					return;
				}
				if(!strJudgement($group_name)){
					echo json_encode(array('status'  => 2002));
					return;
				}
				// $group_name=$_SESSION['solutionProvider'].'_'.$group_name;
				$sql_select_group="select name from long_aro_groups where name='$group_name'";
				$result=mysql_query($sql_select_group);
				$num=mysql_num_rows($result);
				if($num>1){
					echo  json_encode(array('status'  => 9999));
					return;
				}elseif ($num==1) {
					echo  json_encode(array('status'  => 2003));
					return;
				}else{
					$status = addGroup($gacl_api,$group_name,$group_parent_id);
				
					switch ($status) {
						case 'have':
							echo  json_encode(array('status'  => 2003));
							break;
						case 'false':
							echo  json_encode(array('status'  => 9999));
							break;
						
						default:
							echo  json_encode(array('status'  => 1000));
							# code...
							break;
					}
				}

				
				
				break;

			case 'update':

				$group_id=$_POST['group_id'];
				// $parent_id=$_POST['parent_id'];
				$name=$_POST['name'];
				// $group_id=50;
				// $parent_id=49;//$_POST['parent_id'];
				// $name='group2';

				if(empty($group_id)){
					echo  json_encode(array('status'  => 9999));
					return;
				}
				if(empty($name)){
					echo json_encode(array('status' => 2001));
					return;
				}elseif (!strJudgement($name)) {
					echo json_encode(array('status' => 2002));
					return;
				}
				$sql_select_group="select name from long_aro_groups where name='$name'";
				$result=mysql_query($sql_select_group);
				$num=mysql_num_rows($result);
				if($num>1){
					echo  json_encode(array('status'  => 9999));
				}elseif ($num==1) {
					echo  json_encode(array('status'  => 2003));
				}else{
					$status=$gacl_api->edit_group($group_id, NULL, $name, NULL, $group_type='ARO');
					if($status){
						echo  json_encode(array('status'  => 1000));
					}else{
						echo  json_encode(array('status'  => 1001));
					}
				}
				
				


				break;

			case 'delete':
			
				$groupId=$_POST['groupId'];
				if(empty($groupId)){
					echo json_encode(array('status'  => 9999));
					return;
				}
				

				
				$sql_query_user="select count(*) count from spUser where groupId='$groupId'";
				$result=mysql_query($sql_query_user);
				$rows=mysql_fetch_array($result);
				$count=$rows['count'];
				$group_children_ids=$gacl_api->get_group_children($groupId, 'ARO', 'NO_RECURSE');
				//$count=mysql_num_rows($result);
				if($count > 0||count($group_children_ids)>0){
					$arr['status'] = 1001;
					echo json_encode($arr);
 				}else{
					$result=$gacl_api->del_group($groupId, FALSE, 'ARO');
					if($result){
						echo json_encode(array('status'  => 1000));
					}else{
						echo json_encode(array('status'  => 9999));
					}
					
 				}
				
				
 				break;
			case 'select':

				$type=$_POST['type'];
				$functions=$_POST['functions'];

				$solution_provider=$_SESSION['solutionProvider'];
				$group_parent_name=$solution_provider.'_user';
				$sql_search_group_id="select id from long_aro_groups where name='$group_parent_name'";
				
				$result=mysql_query($sql_search_group_id);
				
				if(mysql_num_rows($result)>0){
					$rows=mysql_fetch_array($result);
					$group_parent_id=$rows['id'];
				}else{
					return false;
				}

				if(strcasecmp($functions,'add')==0||strcasecmp($functions,'edit')==0){
					$groupData=$gacl_api->get_group_data($group_parent_id,"ARO");
					if(count($groupData)>0){
						$objects=getObjectRow($group_parent_id);

					
						$arr['groups'][0] = array(
	 						'groupId'  => $groupData[0],
	 						'groupParentId'=>$groupData[1],
	 						'groupParentName'=>getGroupNameById($groupData[1]),
	 						'groupValue' => $groupData[2],
							'groupName' => $groupData[3],
							'objectsNum'=> $objects
							);
					}
				}

				switch ($type) {
					case 'all':
						$group_children_ids=$gacl_api->get_group_children($group_parent_id, 'ARO', 'RECURSE');
						break;
					case 'one':
						
						$group_children_ids=$gacl_api->get_group_children($group_parent_id, 'ARO', 'NO_RECURSE');
						break;
					
					default:
						# code...
						break;
				}

				for($i = 0;$i<count($group_children_ids);$i++){
					$children_id=$group_children_ids[$i];
					$groupData=$gacl_api->get_group_data($children_id,"ARO");

					$objects=getObjectRow($children_id,$solution_provider);
					// if($objects == 0){ 						
					// $sql_search_group_id="select count(*) count from spUser where groupId=$children_id"; 						
					// $result=mysql_query($sql_get_count_by_group_id); 						
					// 	if(mysql_num_rows($result)>0){ 							
					// 	$rows=mysql_fetch_array($result); 							
					// 	$objects=$rows['count']; 						
					// 	} 					
					// }
					if (strcasecmp($functions,'edit')==0) {
						$group_id=$_POST['groupId'];
						if($group_id==$groupData[0]){
							continue;
						}
					}
					
					$arr['groups'][$i+1] = array(
	 					'groupId'  => $groupData[0],
	 					'groupParentId'=>$groupData[1],
	 					'groupParentName'=>getGroupNameById($groupData[1]),
	 					'groupValue' => $groupData[2],
						'groupName' => $groupData[3],
						'objectsNum'=>$objects
						);
				}
				
				echo json_encode($arr);
				
				
				break;
			case 'select_one':
				$group_id=$_POST['groupId'];
				if(empty($group_id)){
					echo json_encode(array('status'  => 9999));
					return;
				}
				$sql_select_groupinfo="select parent_id,name from long_aro_groups where id=$group_id";
				$result=mysql_query($sql_select_groupinfo);
				if(count($result)>0){
					$rows=mysql_fetch_array($result);
					echo json_encode(array(
						'status'  => 1000,
						'parent_id' => $rows['parent_id'],
						'name' => $rows['name']
						));
				}else{
					echo json_encode(array('status'  => 1002));
				}

				break;
			
			default:
				# code...
				break;
		}

		function getGroupNameById($group_id){
			$sql_select_groupName="select name from long_aro_groups where id=$group_id";
			$result=mysql_query($sql_select_groupName);
			if(mysql_num_rows($result)>0){
				$rows=mysql_fetch_array($result);;
				return $rows['name'];
			}else{
				return 'default';
			}
		}

		function addGroup($gacl_api,$group_name,$group_parent_id){

			$sql_search_group_name="select id from long_aro_groups where name='$group_name'";
			$result=mysql_query($sql_search_group_name);
			$count=mysql_num_rows($result);
			// echo $count;
			// $count=mysql_num_fields();
			if($count>0){
				return 'have';
			}else{
				
				$value=create_guid();

				$result=$gacl_api->add_group($value, $group_name, $group_parent_id, 'ARO');
				
				return $result;
				
			}

		}

		function create_guid(){
			$charid=strtoupper(md5(uniqid(mt_rand(),true)));
			$hyphen = chr(45);
			$uuid = chr(123).substr($charid, 0,8).$hyphen.substr($charid, 8, 4).$hyphen
					.substr($charid, 12, 4).$hyphen.substr($charid, 16, 4).$hyphen
					.substr($charid, 20, 12).chr(125);
			return $uuid;
		}

		
		function getObjectNum($group_id){
			$sql_get_count_by_group_id='select count(aro_id) count from long_groups_aro_map where group_id=$group_id';
			$result=mysql_query($sql_get_count_by_group_id);
			if(mysql_num_rows($result)>0){
				$rows=mysql_fetch_array($result);
				return $rows['count'];
			}else{
				return 0;
			}
		}
		
		function getObjectRow($group_id,$solution_provider){
			$sql_get_count_by_group_id = "select count(*) count from spUser where groupId=$group_id and solutionProvider='$solution_provider'";
			// logFile(error_log,$sql_get_count_by_group_id);
			$result=mysql_query($sql_get_count_by_group_id);
			if(mysql_num_rows($result)>0){
				$rows=mysql_fetch_array($result);
				return $rows['count'];
			}else{
				return 0;
			}
		}

		function logFile($filename,$msg){
			//打开文件
			$fd = fopen($filename,"a");
			//增加文件
			$str = "[".date("Y/m/d h:i:s",time())."]".$msg;
			//写入字符串
			fwrite($fd, $str."\n");
			//关闭文件
			fclose($fd);
		}
?>