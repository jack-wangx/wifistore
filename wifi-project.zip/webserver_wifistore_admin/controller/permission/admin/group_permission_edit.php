<?php
	require_once("../../gacl/admin/gacl_admin.inc.php");
	include_once('allow.php');
	include_once('aco_edit.php');
	if(!getPermission()){
		return;
	}
		$action=$_POST["action"];
		session_start();
		switch ($action) {
			case 'insert':
				
				
				break;

			case 'update':

			// $jsonArray=json_encode(urldecode(file_get_contents("php://input")));
			//logFile(error.log, urldecode(file_get_contents("php://input")));
				
			//logFile(error.log, $jsonArray);	


				$group_id=$_POST['group_id'];

					
				$aco_update_list=$_POST['groups'];
				

				if(empty($aco_update_list) || count($aco_update_list)<1){
					echo json_encode(array('status'  => 9999));	
				}else{
					
					for ($i=0;$i<count($aco_update_list);$i++) {
						$group=$aco_update_list[$i];

						$aco_value=$group['value'];
						$allow=$group['allow'];
						// logFile(error.log, $aco_value);
						
						$sql_search_aco_list="select long_aco.id aco_id ,long_acl.id acl_id ,long_acl.allow from long_aco_map  
						inner join long_aro_groups_map on 
						long_aro_groups_map.acl_id=long_aco_map.acl_id inner join long_aco  
						on long_aco_map.value= long_aco.value and 
						long_aco_map.section_value=long_aco.section_value 
						inner join long_acl on long_aco_map.acl_id=long_acl.id 
						where group_id=$group_id and long_aco.value='$aco_value'";
						
						$result=mysql_query($sql_search_aco_list);
						$count=mysql_num_rows($result);
						
						if($count==1){
							
							$rows=mysql_fetch_array($result);
							$mAllow=$rows['allow'];
							//logFile(error.log, $mAllow.'&&'.$allow);
							if($allow==$mAllow){
								
								$status=true;
								continue;
							}else{
								
								$status=updateAclByGroupIdAndAcoValue($group_id,$aco_value,$rows['aco_id'],$rows['acl_id'],$allow);
							}
							

						}else if($count==0){
							
							$status=addAclByGroupIdAndAcoValue($group_id,$aco_value,$allow);	
						}else{
							
							$status = false;
						}
						if(!$status)break;
					}

					if($status){
						echo json_encode(array('status'  => 1000));			
					}else{
						echo json_encode(array('status'  => 9999));		
					}

				}

				
				


				break;

			case 'delete':
				
				break;
			case 'select':
				$solutionProvider=$_SESSION['solutionProvider'];
				
				$group_id=$_POST['group_id'];
				$group_parent_id=$gacl_api->get_group_parent_id($group_id,'ARO');
				$group_parent_data=$gacl_api->get_group_data($group_parent_id,'ARO');
				if(empty($group_parent_data)){
					return false;
				}else{
					$inherit_group=array('name'=>$group_parent_data[3],'group_id'=>$group_parent_data[0]);
				}
				if(strcasecmp($group_parent_data[3], $solutionProvider.'_admin')==0){
					$group_admin_name=$solutionProvider.'_admin';
				}else{
					$group_admin_name=$solutionProvider.'_user';
				}
				
				$group_admin_id=getGroupId($group_admin_name);
				//logFile('error_log',$group_admin_id);

				$ownlist=getAcoList($group_id,null);
				$inheritlist=getAcoList($group_parent_id,null);
				$availablelist=getAcoList($group_admin_id,getFilterAcoIds($group_id));

				$responseArray['inheritgroup']=$inherit_group;
				$responseArray['inheritlist']=$inheritlist;
				$responseArray['ownlist']=$ownlist;
				$responseArray['availablelist']=$availablelist;

				echo json_encode($responseArray);



				
				break;
			
			default:
				# code...
				break;
		}

		function logFile($filename,$msg){
			//打开文件
			$fd = fopen($filename,"a");
			//增加文件
			$str = "[".date("Y/m/d h:i:s",time())."]".$msg;
			//写入字符串
			fwrite($fd, $str."\n");
			//关闭文件
			fclose($fd);
		}


		

		function getGroupId($group_name){
			$sql_get_group_name="select id from long_aro_groups where name='$group_name'";
			$result=mysql_query($sql_get_group_name);
			if(mysql_num_rows($result)>0){
				$rows=mysql_fetch_array($result);
				return $rows['id'];
			}else{
				return null;
			}
		}

		function updateAclByGroupIdAndAcoValue($group_id,$aco_value,$aco_id,$acl_id,$allow){

			$sql_select_acoNum_by_aclId='select count(acl_id) acoSum from long_aco_map where acl_id='.$acl_id;
			
			$result=mysql_query($sql_select_acoNum_by_aclId);
			if(mysql_num_rows($result)>0){
				$rows=mysql_fetch_array($result);
				$aco_sum=$rows['acoSum'];
				
				if($aco_sum==1){
					$sql_update_acl='update long_acl set allow='.$allow .' where id='.$acl_id;
					//logFile(error.log, $sql_update_acl);
					mysql_query($sql_update_acl);
					return true;
				}else if($aco_sum>1){
					$new_acl_id=getAclId();
					$sql_insert_acl="insert into long_acl(id,section_value,allow,enabled,updated_date) values(".$acl_id.",'".$section_value."',".$allow.',1,'.time().')';
					$sql_update_aco_map="update  long_aco_map set acl_id=".$new_acl_id." where value='".$aco_value."'";
					//logFile(error.log, 'sql_update_aco_map'.$sql_update_aco_map);
					$sql_insert_aro_group_map='insert into long_aro_groups_map(acl_id,group_id) values('.$acl_id.','.$group_id.')';

					mysql_query('BEGIN');

					mysql_query($sql_insert_acl);
					mysql_query($sql_update_aco_map);
					mysql_query($sql_insert_aro_group_map);
					if(mysql_errno()){
						//add   failed;
						mysql_query('ROLLBACK');
						return false;

					}else{
						//add  success
						mysql_query('COMMIT');
						return true;
					}
				}else{
					return false;
				}
			
			}
		}

		function addAclByGroupIdAndAcoValue($group_id,$aco_value,$allow){

			
			$aco_section_value=getSectionValue($aco_value);
			
			if(empty($aco_section_value)){
				return false;
			}

			$acl_id=getAclId();
			//logFile(error.log, 'acl_id'.$acl_id);
			$section_value='user';
			$sql_insert_acl="insert into long_acl(id,section_value,allow,enabled,updated_date) values(".$acl_id.",'".$section_value."',".$allow.',1,'.time().')';
			//logFile(error.log, 'sql_insert_acl'.$sql_insert_acl);
			$sql_insert_aco_map="insert into long_aco_map(acl_id,section_value,value) values (".$acl_id.",'".$aco_section_value."','".$aco_value."')";
			//logFile(error.log, 'sql_insert_aco_map'.$sql_insert_aco_map);
			$sql_insert_aro_group_map='insert into long_aro_groups_map(acl_id,group_id) values('.$acl_id.','.$group_id.')';
			//logFile(error.log, 'sql_insert_aro_group_map'.$sql_insert_aro_group_map);

			mysql_query('BEGIN');

			mysql_query($sql_insert_acl);
			mysql_query($sql_insert_aco_map);
			mysql_query($sql_insert_aro_group_map);
			if(mysql_errno()){
				//add   failed;
				mysql_query('ROLLBACK');
				return false;

			}else{
				//add  success
				mysql_query('COMMIT');
				return true;
			}

		}

		function getSectionValue($aco_value){
			$sql_select_aco_section_value="select section_value from long_aco where value='$aco_value'";
			$result=mysql_query($sql_select_aco_section_value);
			while ($rows=mysql_fetch_array($result)) {
				return $rows['section_value'];
			}
			return null;
		}

		function getAclId(){
			$sql_select_acl_id='select id from long_acl_seq order by id desc limit 1';
			$result=mysql_query($sql_select_acl_id);
			while ($rows=mysql_fetch_array($result)) {
				$id=$rows['id']+1;
				$sql_insert_acl_seq='update long_acl_seq set id='.$id;
				//logFile(error.log, $sql_insert_acl_seq);
				mysql_query($sql_insert_acl_seq);
				return $id;
			}
			return 10;
		}

?>