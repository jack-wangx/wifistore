<?php
		require_once("../../gacl/admin/gacl_admin.inc.php");
		include_once('allow.php');
		include_once('../../util/formatString.php');
		if(!getPermission()){
			return;
		}
		if(empty($_POST["action"])){
			$action=$_GET["action"];
		}else{
			$action=$_POST["action"];
		}

		session_start();
		$solutionProvider=$_SESSION["solutionProvider"];
		switch ($action) {
			case 'insert':
				
				
				//$projectId=$_SESSION["projectId"];
				$groupId=$_POST["groupId"];
				$userName=trim($_POST["userName"]);
				if(empty($userName)){
					echo  json_encode(array('status'  => 2001));
					return;
				}elseif(!strJudgement($userName)){
					echo json_encode(array('status'  => 2002));
					return;
				}
				$password=md5('12345678');
				
				//$password=md5($_POST["password"],true);
				$sql_check_user_name="select id from spUser where userName = '$userName'";
				$result=mysql_query($sql_check_user_name);
				$num = mysql_num_rows($result);
				if($num>0){
					echo  json_encode(array('status'  => 2003));
					//return username is exist;
				}else{
					
					$uuid=create_guid();
					
					$sql_insert_user="insert into spUser(`userName`,`password`,`uniqueId`,`groupId`,`solutionProvider`) values('$userName','$password','$uuid','$groupId','$solutionProvider')";
					
					$id_aro=getSeq("long_aro_seq");
					

					$id_aro_section=getSeq("long_aro_sections_seq");
					
					
					$sql_insert_gacl_aro="insert into long_aro (`id`,`section_value`,`value`,`order_value`,`name`,`hidden`) value($id_aro,'$solutionProvider','$uuid',1,'$userName',0)";
					
					
					$sql_select_aro_section="select id from long_aro_sections where value = '$solutionProvider'";
					$result=mysql_query($sql_select_aro_section);
					
					$sql_insert_gacl_aro_sections="insert into long_aro_sections (`id`,`value`,`order_value`,`name`,`hidden`) values($id_aro_section,'$solutionProvider',1,'$solutionProvider',0)";
				
					
					mysql_query('BEGIN');

					mysql_query($sql_insert_user);
					mysql_query($sql_insert_gacl_aro);
					if(mysql_num_rows($result)==0){
						mysql_query($sql_insert_gacl_aro_sections);
					}
					if(mysql_errno()){
						//add new user failed;
						echo  json_encode(array('status'  => 9999));
						mysql_query('ROLLBACK');

					}else{
						//add new user success
						echo  json_encode(array('status'  => 1000));
						mysql_query('COMMIT');
					}
					
				}
				break;

			case 'update':
				$userName=$_POST['userName'];
				$uniqueId=$_POST['uniqueId'];
				$group_id=$_POST['groupId'];
				if(empty($userName)){
					echo json_encode(array('status'  => 2001));
					return;
				}
				if(!strJudgement($userName)){
					echo json_encode(array('status'  => 2002));
					return;
				}
				if(empty($uniqueId)||empty($group_id)){
					echo json_encode(array('status'  => 9999));
					return;
				}
				$sql_select_user_by_uniqueId="select userName from spUser where uniqueId='$uniqueId'";
				$result=mysql_query($sql_select_user_by_uniqueId);
				if(mysql_num_rows($result)!=1){
					echo json_encode(array('status'  => 9999));
					return;
				}else{
					$row=mysql_fetch_array($result);
					if(!strcasecmp($userName, $row['userName'])==0){
						$sql_select_user="select userName from spUser where userName='$userName' and solutionProvider='$solutionProvider'";
						$result=mysql_query($sql_select_user);
						if(mysql_num_rows($result)>0){
							echo json_encode(array('status'  => 2003));
							return;
						}
					}
					
				}
				
				$sql_update_user="update spUser set groupId=$group_id, userName='$userName' where uniqueId='$uniqueId'";
				
				mysql_query('BEGIN');

				mysql_query($sql_update_user);
					
					
				if(mysql_errno()){
					//add new user failed;
					echo  json_encode(array('status'  => 9999));
					mysql_query('ROLLBACK');

				}else{
					//add new user success
					echo  json_encode(array('status'  => 1000));
					mysql_query('COMMIT');
				}

				break;

			case 'delete':
				$uniqueId=$_POST["uniqueId"];
				if(empty($uniqueId)){

					echo json_encode(array('status'  => 9999));
					return;
				}
				$sql_delete_user="delete from spUser where uniqueId='$uniqueId'";
				
				// //add aro delete features
				// $sql_get_aro_id="select uniqueId from spUser where id=$userId";
				// $result=mysql_query($sql_get_aro_id);

				// if(mysql_num_rows($result)>0){
				// 	$row=mysql_fetch_array($result);
				// 	$aro_id = $row['uniqueId'];
					$sql_delete_aro="delete from long_aro where value='$uniqueId'";
					
					mysql_query($sql_delete_aro);
				// }
				
				
				$success=mysql_query($sql_delete_user);
				
				if($success){
					echo  json_encode(array('status'  => 1000));
				}else{
					echo  json_encode(array('status'  => 1001));
				}
				break;
			case 'select':
				$solutionProvider=$_SESSION["solutionProvider"];
				$groupId=$_POST['groupId'];
				if(empty($solutionProvider)){
					return;
				}
				$solutionProvider_name=$solutionProvider.'_user';
				
				if(empty($groupId)){
					$sql_query_group="select id from long_aro_groups where name='$solutionProvider_name'";
					$result=mysql_query($sql_query_group);
					if(mysql_num_rows($result)<1){
						return;
					}
					$rows=mysql_fetch_array($result);
					$sp_id=$rows['id'];
					// logFile('errorlog', $groupId);
					$group_children_ids=$gacl_api->get_group_children($sp_id, 'ARO', 'RECURSE');
					array_push($group_children_ids, $sp_id);
					if(count($group_children_ids)>0){
					
						$sql_select_user="select sp.id,sp.uniqueId, sp.userName,g.name from spUser sp inner join long_aro_groups g on sp.groupId=g.id  
										where sp.solutionProvider='$solutionProvider' and sp.groupId in(".implode(',',$group_children_ids).")";
						//logFile('errorlog', $sql_select_user);
					
					}
				}else{
					// $group_children_ids=$gacl_api->get_group_children($groupId, 'ARO', 'RECURSE');
					$sql_select_user="select sp.id,sp.uniqueId, sp.userName,g.name from spUser sp inner join long_aro_groups g on sp.groupId=g.id  
										where sp.solutionProvider='$solutionProvider' and sp.groupId =$groupId";
				}
				

				
				
				
				$result=mysql_query($sql_select_user);
				$i=0;
				while($row=mysql_fetch_array($result)){
	 				if(strcasecmp($_SESSION['userId'], $row['id'])==0){
	 					continue;
	 				}
	 				$arr['users'][$i] = array(
	 				'userId'  => $row['id'],
	 				'uniqueId'=> $row['uniqueId'],
	 				'userName' => $row['userName'],
					'groupName' => $row['name'],
					);
					$i=$i+1;
	 			}

				echo json_encode($arr);
				break;
			case 'select_one';

				$uniqueId=$_POST['uniqueId'];
				if(empty($uniqueId)){
					echo  json_encode(array('status'  => 9999));
					return;
				}
				$sql_select_user_by_uniqueId="select userName,uniqueId,groupId from spUser where uniqueId='$uniqueId' ";
				$result=mysql_query($sql_select_user_by_uniqueId);
				if(mysql_num_rows($result)>0){
					$rows=mysql_fetch_array($result);
					echo json_encode(array(
					'status'  => 1000,
	 				'userName'  => $rows['userName'],
	 				'uniqueId'=> $rows['uniqueId'],
	 				'groupId' => $rows['groupId']
					));
				}else{
					echo  json_encode(array('status'  => 1002));
				}
				break;
			case 'modifyPassw':
				$old_passw=$_POST['old_passw'];
				$new_passw=$_POST['new_passw'];
				$uniqueId=$_POST['uniqueId'];
				if(empty($old_passw)||empty($new_passw)||empty($uniqueId)){
					echo  json_encode(array('status'  => 2001));
					return;
				}
				md5($old_passw);
				$sql_select_user="select password from spUser where uniqueId='$uniqueId'";
				$result=mysql_query($sql_select_user);
				if(mysql_num_rows($result)>0){
					$rows=mysql_fetch_array($result);
					$passw=$rows['password'];
					if(strcasecmp($old_passw, $passw)==0){
						$new_passw=md5($new_passw);
						$sql_update_user="update spUser set password='$new_passw' where uniqueId='$uniqueId'";
						mysql_query($sql_update_user);
						echo  json_encode(array('status'  => 1000));
					}else{
						echo  json_encode(array('status'  => 3001));
					}
				}else{
					echo  json_encode(array('status'  => 1002));
				}
				
			
			default:
				# code...
				break;
		}
		

		function create_guid(){
			$charid=strtoupper(md5(uniqid(mt_rand(),true)));
			$hyphen = chr(45);
			$uuid = chr(123).substr($charid, 0,8).$hyphen.substr($charid, 8, 4).$hyphen
					.substr($charid, 12, 4).$hyphen.substr($charid, 16, 4).$hyphen
					.substr($charid, 20, 12).chr(125);
			return $uuid;
		}
		function getSeq($tableName){
			$sql_select_seq="select id from $tableName order by id desc limit 1";
			$result=mysql_query($sql_select_seq);
			
			$id=10;
			 
			if(mysql_num_rows($result)>0){
				while($rows=mysql_fetch_array($result)){
						$id=$rows["id"]+1;
						
				}
			}
			
			
			$sql_insert_seq="insert into $tableName (`id`)values($id)";
			
			mysql_query($sql_insert_seq);
			
			return $id;
			
		}

		function logFile($filename,$msg){
			//打开文件
			$fd = fopen($filename,"a");
			//增加文件
			$str = "[".date("Y/m/d h:i:s",time())."]".$msg;
			//写入字符串
			fwrite($fd, $str."\n");
			//关闭文件
			fclose($fd);
		}

		
?>