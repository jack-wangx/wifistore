<form   action="fota/show.php"   method="get">   
      <!--<input type="text" name="data" style="width:900px;height:500px;">-->
      <textarea cols="100" rows="20" id="type" name="type"></textarea>
      <input   type="submit">
  </form> 
