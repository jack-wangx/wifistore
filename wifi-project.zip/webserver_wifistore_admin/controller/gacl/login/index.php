<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>欢迎登陆!</title>
<link rel="stylesheet"  href="../../style/css/style.css" type="text/css" />
<script src="/scripts/vendor/jquery.js"></script>
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
<script src="/scripts/vendor/jquery.tools.min.js"></script>

<style type="text/css"></style>
</head>

<body>

	<div class="panel_middle">
    	<div class="login_logo">
        	<img src="../../style/img/login_title.gif" />
        </div>

        <div class="divlabel"><br /><br /><br />账户:<input class="input_normal" type="text" name="username" id="username" value="请输入用户名"/><br />密码:<input id="password" name="password" class="input_normal" type="password" />
        </div>
        <br/>
        <input class="submit_btn" type="button" value="登录"/>

    </div>

  <? include("../../include/foot.php") ?>
</body>
<script src="/scripts/src/common/common.js"></script>
<script type="text/javascript">
//--------------------- submit edited perms -------------------------------------

function submition(){
  var username = $("#username").val();
  var password = $("#password").val();
  if(username == "" || password == ""){
	  alert("未输入用户名或密码");
   	  return false;
		}
  
	
  var data={"actions" : "login", "username" : username, "password" : password};
  $.ajax({
    type: 'POST',
    url: './dologin.php',
    data: data,
    dataType:'json',
    beforeSend:function(){
      
    },
    success:function(json){
      
		if(json.status==0)
		{
  			window.location.href="../admin/index.php";
  	}else if(json.status==1){
  			alert("密码错误");
  	}else if(json.status==2){
          alert("用户名错误");
    }
    },
    complete:function(){  
    },
    error:function(){
		alert("提交失败，未链接到网络");
    }
  });
}
$(".submit_btn").click(function (){
	submition();
	}

);


$("#username").focus(function () {
      if($(this).val() == "请输入用户名")
			{
				$(this).val("");
				}
			$(this).removeClass("input_normal");
			$(this).addClass("input_active");
        });
$("#username").blur(function () {
            if($(this).val() == "")
			{
				$(this).val("请输入用户名");
				}
			$(this).removeClass("input_active");
			$(this).addClass("input_normal");
        });
$("#password").focus(function () {
			$(this).removeClass("input_normal");
			$(this).addClass("input_active");
        });
$("#password").blur(function () {
			$(this).removeClass("input_active");
			$(this).addClass("input_normal");
        });

</script>
</html>
