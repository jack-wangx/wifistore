<?php
    require_once("../../conn.php");
   
    $lifeTime = 1 * 3600;  
    
    session_set_cookie_params($lifeTime); 
    session_start();
    $mActions;
    if($_POST['actions'])
    {
    	$mActions=$_POST['actions'];
    }else{
    	$mActions=$_GET['actions'];
    }



    switch($mActions){
        case 'login':
            $username= trim($_POST['username']);
            $password= trim($_POST['password']);
            
    		
            $rs="select * from gacl_user where userName = '$username'";
            //echo $rs;
            $result=mysql_query($rs);
            if ($row=mysql_fetch_array($result)) 
            {
                if ($row["password"]==$password) 
                {
    				$_SESSION["userName"] = $row["userName"];
    				
    				echo  json_encode(array('status'  => 0));

                } else {
                    echo  json_encode(array('status'  => 1));
                }

            } else {
                echo  json_encode(array('status'  => 2));
            }
            break;
        case 'logout':
            session_unset(); 
            session_destroy();
            header("Location: login.php");
            break;

    }

    
?>
