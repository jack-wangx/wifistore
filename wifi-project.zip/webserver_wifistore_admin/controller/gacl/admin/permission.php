<?php

	function getPermission(){
		session_start();

		if(empty($_SESSION["userName"])){
			
			return false;
		}else{
			return true;
		}
	}
?>