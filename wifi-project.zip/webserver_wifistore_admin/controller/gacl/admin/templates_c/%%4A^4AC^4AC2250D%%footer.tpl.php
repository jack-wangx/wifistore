<?php /* Smarty version 2.6.14, created on 2013-04-02 11:55:49
         compiled from phpgacl/footer.tpl */ ?>
		</div></div>
		
		<div id="bot-br"><div id="bot-bl"><div id="bot-tr"><div id="bot-tl">
			<a href="http://phpgacl.sourceforge.net">phpGACL</a> v<?php echo $this->_tpl_vars['phpgacl_version']; ?>
 (Schema v<?php echo $this->_tpl_vars['phpgacl_schema_version']; ?>
) - Generic Access Control Lists
			<br />
			Copyright &copy; 2005 <a href="about.php">Mike Benoit</a>
		</div></div></div></div>
		
	<!-- End Body -->
  </body>
</html>