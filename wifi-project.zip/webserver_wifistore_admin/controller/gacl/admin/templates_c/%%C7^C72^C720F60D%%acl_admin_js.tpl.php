<?php /* Smarty version 2.6.14, created on 2013-04-02 11:55:53
         compiled from phpgacl/acl_admin_js.tpl */ ?>
<?php echo '
<script language="JavaScript" src="admin_functions.js">
</script>
'; ?>