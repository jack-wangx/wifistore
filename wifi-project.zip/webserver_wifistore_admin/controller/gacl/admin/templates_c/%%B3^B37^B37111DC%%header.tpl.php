<?php /* Smarty version 2.6.14, created on 2013-04-02 11:55:49
         compiled from phpgacl/header.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
  <head>
    <title>phpGACL - <?php echo $this->_tpl_vars['page_title']; ?>
</title>
    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
    <link rel="stylesheet" href="admin.css" type="text/css" title="phpGACL" />