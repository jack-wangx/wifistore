<div id="bot-br">
	<div id="bot-bl">
		<div id="bot-tr">
			<div id="bot-tl">
				<a href="http://phpgacl.sourceforge.net">phpGACL</a> v3.3.3 (Schema v2.1) - Generic Access Control Lists
				<br />
				Copyright &copy; 2004 <a href="about.php">Mike Benoit</a>
			</div>
		</div>
	</div>
</div>	
  </body>
</html>