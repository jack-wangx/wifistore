<html>
<head>
    <title>phpGACL Millennium Falcon API</title>
    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
    <link rel="stylesheet" href="../../../admin/admin.css" type="text/css" title="phpGACL Millennium Demo" /> 
</head>
<body>
<div id="top-tr">
	<div id="top-tl">
		<div id="top-br">
			<div id="top-bl">
				<h1><span>phpGACL</span></h1>
				<h2>phpGACL Millennium Falcon API demo.</h2>
			<ul id="menu">
				<li <?php if($URL == 'index'){ echo("class='current'");}?>><a href='index.php?do=index'>Index</a></li>
				<li <?php if($URL == 'example1'){ echo("class='current'");}?>><a href='index.php?do=example1'>Defining Access Control</a></li>
				<li <?php if($URL == 'example2'){ echo("class='current'");}?>><a href='index.php?do=example2'>Fine-grain Access Control</a></li>
				<li <?php if($URL == 'example3'){ echo("class='current'");}?>><a href='index.php?do=example3'>Multi-level Groups</a></li>
			</ul>
			</div>
		</div>
	</div>
</div>
