<?php

	function getPermission(){
		session_start();
		
		if(empty($_SESSION["solutionProvider"])){
			
			return 1002;
		}else{
			$allow=$_SESSION["app"];
			
			if(empty($allow)){
				
				return 1001;
			}elseif ($allow==1) {
				
				return 1000;
			}else{
				
				return 1002;
			}
		}
	}
	

	function logFile($filename,$msg){
			//打开文件
			$fd = fopen($filename,"a");
			//增加文件
			$str = "[".date("Y/m/d h:i:s",time())."]".$msg;
			//写入字符串
			fwrite($fd, $str."\n");
			//关闭文件
			fclose($fd);
		}
?>
