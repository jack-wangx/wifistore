<?php
$conn = @mysql_connect("127.0.0.1","root","99001122");
if (!$conn){
	echo 'faild';
    die("连接数据库失败：" . mysql_error());
}
mysql_select_db("wifi-store", $conn);
mysql_query("set names 'utf8'");
?>
