<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script type="text/javascript" src="__VENDOR__/jquery/modernizr.custom.46021.js"></script>
  <link rel="stylesheet" href="__VENDOR__/bootstrap/css/bootstrap.css" />
  <link rel="stylesheet" href="__VENDOR__/bootstrap/css/responsive.css" />
  <link rel="stylesheet" href="/content/css/matrix-style.css" />
  <link rel="stylesheet" href="/content/css/matrix-media.css" />
  <link rel="stylesheet" href="/content/css/common.css" />
  <link rel="stylesheet" href="__VENDOR__/bootstrap/css/bootstrap-modal.css" type="text/css" />
  <link rel="stylesheet" href="__VENDOR__/Gritter/css/custom.gritter.css" />
  <link href="/content/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!--[if lte IE 7]>
    <link href="/content/font-awesome/css/font-awesome-ie7.css" rel="stylesheet" />
  <![endif]-->
  <title>
    首页
  </title>
  
</head>
<body>
  <!--Header-part-->
  <div id="header">
    <h1><a href="dashboard.html">Longfota</a></h1>
  </div>
  <!--close-Header-part-->

  <!--top-Header-menu-->
  <div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
      <!--<li class="dropdown" id="profile-messages"><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i><span class="text">Welcome User</span><b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#"><i class="icon-user"></i>My Profile</a></li>
            <li class="divider"></li>
            <li><a href="#"><i class="icon-check"></i>My Tasks</a></li>
            <li class="divider"></li>
            <li><a href="login.html"><i class="icon-key"></i>Log Out</a></li>
          </ul>
        </li>
        <li class="dropdown" id="menu-messages"><a href="#" data-toggle="dropdown" data-target="#menu-messages" class="dropdown-toggle"><i class="icon icon-envelope"></i><span class="text">Messages</span> <span class="label label-important">5</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a class="sAdd" title="" href="#"><i class="icon-plus"></i>new message</a></li>
            <li class="divider"></li>
            <li><a class="sInbox" title="" href="#"><i class="icon-envelope"></i>inbox</a></li>
            <li class="divider"></li>
            <li><a class="sOutbox" title="" href="#"><i class="icon-arrow-up"></i>outbox</a></li>
            <li class="divider"></li>
            <li><a class="sTrash" title="" href="#"><i class="icon-trash"></i>trash</a></li>
          </ul>
        </li>-->
      <!--        <li class=""><a title="" href="#"><i class="icon icon-cog"></i><span class="text">Settings</span></a></li>-->
      <li class="">
        <a title="" href="__APP__/Account/logout">
          <i class="icon icon-share-alt"></i>
          <span class="text">注销</span>
        </a>
      </li>
      <li class="help">
        <a title="" href="#">
          <i class="icon-question-sign"></i>
          <span class="text">帮助</span>
        </a>
      </li>
    </ul>
  </div>
  <!--close-top-Header-menu-->
  <!--start-top-serch-->
 <!--  <div id="search">
    <input type="text" placeholder="Search here..." />
    <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
  </div> -->
  <!--close-top-serch-->
  <!--sidebar-menu-->
  <div id="sidebar">
    <?php echo W('Sidebar', $Think.MODULE_NAME);?>
  </div>
  <!--sidebar-menu-->

  <!--main-container-part-->
  <div id="content">
    <!--breadcrumbs-->
    <div id="content-header">
      <div id="breadcrumb">
  <?php if(is_array($breadcrumb)): foreach($breadcrumb as $key=>$bread): ?><a href="<?php echo ($bread['href']); ?>" title="<?php echo ($bread['title']); ?>" class="tip-bottom">
      <i class="<?php echo ($bread['icon']); ?>"></i><?php echo ($bread['desc']); ?>
    </a><?php endforeach; endif; ?>
</div>

    </div>
    <!--End-breadcrumbs-->

    <!--Action boxes-->
    <div class="container-fluid">
      
    </div>
  </div>

  <!--end-main-container-part-->

  <!--Footer-part-->

  <div class="row-fluid">
    <div id="footer" class="span12">
      <div>2013 &copy; 文腾通信科技. </div>
      <div>服务热线:021-53332301 Email:service@wenteng.com 文腾通信科技 沪ICP备12015xx号</div>
    </div>
  </div>

  <div class="modal hide fade" id="help-modal">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h3>
        <i class="icon-question-sign"></i>
        <span>帮助</span>
      </h3>
    </div>
    <div class="modal-body">
    </div>
    <div class="modal-footer">
      <a href="#" class="btn btn-primary" data-dismiss="modal">我知道了</a>
    </div>
  </div>

  <!--end-Footer-part-->

  <script src="__VENDOR__/jquery/jquery.js"></script>
  <script src="__VENDOR__/matrix/matrix.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-tooltip.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-typeahead.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-button.js"></script>
  <script src="__VENDOR__/Gritter/js/jquery.gritter.custom.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-modal.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-modalmanager.js"></script>
  <!--[if lte IE 8]>
  <script src="__VENDOR__/repond/respond.js"></script>
  <![endif]-->
  <script type="text/javascript">
    var ROOT = '__APP__';
    $(function () {
      $('.help a').on('click', function () {
        $.get('/help.html', function (html) {
          $('#help-modal .modal-body').html(html);
          $('#help-modal').modal('show');
        });
      });
    });
  </script>
  
</body>
</html>