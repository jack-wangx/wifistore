<?php if (!defined('THINK_PATH')) exit();?><a href="#" class="visible-phone"><i class="icon <?php echo ($currItem[1]); ?>"></i><?php echo ($currItem[0]); ?></a>
<ul>
  <?php if(is_array($menus)): foreach($menus as $action=>$menu): $className = ''; ?>
    <?php $name = $menu[0]; ?>
    <?php $icon = $menu[1]; ?>
    <?php $url = $action; ?>
    <?php if($action == $curr): $className=$className.' active'; endif; ?>
    <?php if (is_array($menu['menus'])) { $className = $className . ' submenu'; $name = $menu["text"]; $icon = $menu["icon"]; $url = "#"; $expandUrl="icon-double-angle-down"; if ($menu["menus"][$curr]) { $className = $className . ' open'; $expandUrl = "icon-double-angle-up"; } } ?>
    <li class="<?php echo ($className); ?>">
      <a href="<?php echo U($url);?>">
        <i class="icon <?php echo ($icon); ?>"></i><span><?php echo ($name); ?></span>
        <?php if(is_array($menu['menus'])): ?><span class="pull-right">
          <i class="icon icon-double-angle-down"></i>
          <i class="icon icon-double-angle-up for-open"></i>
        </span><?php endif; ?>
      </a>
      <?php if(is_array($menu['menus'])): ?><ul>
          <?php $subMenus = $menu['menus']; ?>
          <?php if(is_array($subMenus)): foreach($subMenus as $submenuUrl=>$submenu): ?><li class="<?php echo ($submenuUrl==$curr?'active':''); ?>"><a href="<?php echo U($submenuUrl);?>"><?php echo ($submenu[0]); ?></a></li><?php endforeach; endif; ?>
        </ul><?php endif; ?>
    </li><?php endforeach; endif; ?>
</ul>