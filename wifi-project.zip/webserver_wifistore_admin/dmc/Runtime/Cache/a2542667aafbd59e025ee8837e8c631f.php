<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>欢迎登陆!</title>
  <link rel="stylesheet" href="/content/css/bootstrap.css" />
  <link rel="stylesheet" href="/content/css/bootstrap-responsive.css" />
  <link rel="stylesheet" href="/content/css/matrix-login.css" />
  <link href="/content/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <style type="text/css">
  </style>
</head>

<body>
  <div id="loginbox">
    <form id="loginform" class="form-vertical" method="post">
      <div class="control-group normal_text">
        <h3>
          <img src="/content/img/logo.png" alt="Logo" /></h3>
      </div>
      <div class="control-group">
        <div class="controls">
          <div class="main_input_box">
            <span class="add-on bg_lg"><i class="icon-user"></i></span>
            <input type="text" name="username" id="username" placeholder="账号" />
          </div>
        </div>
      </div>
      <div class="control-group">
        <div class="controls">
          <div class="main_input_box">
            <span class="add-on bg_ly"><i class="icon-lock"></i></span>
            <input type="password" name="password" id="password" placeholder="密码" />
          </div>
        </div>
      </div>
      <div class="form-actions">
        <span class="pull-left"><a href="#" class="flip-link btn btn-info" id="to-recover">忘记了密码?</a></span>
        <span class="pull-right">
          <button type="submit" class="btn submit_btn btn-success"
            data-loading-text="登录中..." data-redirect-text="正在跳转..." />登录</button>
        </span>
      </div>
    </form>
    <!--    <form id="recoverform" action="#" class="form-vertical">
      <p class="normal_text">Enter your e-mail address below and we will send you instructions how to recover a password.</p>

      <div class="controls">
        <div class="main_input_box">
          <span class="add-on bg_lo"><i class="icon-envelope"></i></span>
          <input type="text" placeholder="E-mail address" />
        </div>
      </div>

      <div class="form-actions">
        <span class="pull-left"><a href="#" class="flip-link btn btn-success" id="to-login">&laquo; Back to login</a></span>
        <span class="pull-right"><a class="btn btn-info" />Reecover</a></span>
      </div>
    </form>-->
  </div>
</body>
  <script src="__VENDOR__/jquery/jquery.js"></script>
  <script src="__VENDOR__/jquery/jquery-migrate.min.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap.min.js"></script>
  <script src="__VENDOR__/matrix/matrix.login.js"></script>

<script type="text/javascript">
  //--------------------- submit edited perms -------------------------------------

  $('#loginform').on('submit', function (e) {
    submition();
    return false;
  });

  function submition() {
    console.log(Date.now());
    $('.submit_btn').button('loading');
    var username = $("#username").val();
    var password = $("#password").val();
    if (username == "" || password == "") {
      alert("未输入用户名或密码");
      return false;
    }


    var data = { "actions": "login", "username": username, "password": password };
    $.ajax({
      type: 'POST',
      url: '__ACTION__',
      data: data,
      dataType: 'json',
      beforeSend: function () {

      },
      success: function (json) {
        $('.submit_btn').button('reset');
        if (json.status == 0) {
          $('.submit_btn').button('redirect');
          window.location.href = "__APP__/Index/index";
        } else if (json.status == 1) {
          alert("密码错误");
        } else if (json.status == 2) {
          alert("用户名错误");
        }
      },
      complete: function () {
      },
      error: function () {
        $('.submit_btn').button('reset');
        alert("提交失败，未链接到网络");
      }
    });
  }

  $("#username").focus(function () {
    if ($(this).val() == "请输入用户名") {
      $(this).val("");
    }
    $(this).removeClass("input_normal");
    $(this).addClass("input_active");
  });
  $("#username").blur(function () {
    if ($(this).val() == "") {
      $(this).val("请输入用户名");
    }
    $(this).removeClass("input_active");
    $(this).addClass("input_normal");
  });
  $("#password").focus(function () {
    $(this).removeClass("input_normal");
    $(this).addClass("input_active");
  });
  $("#password").blur(function () {
    $(this).removeClass("input_active");
    $(this).addClass("input_normal");
  });

</script>

</html>