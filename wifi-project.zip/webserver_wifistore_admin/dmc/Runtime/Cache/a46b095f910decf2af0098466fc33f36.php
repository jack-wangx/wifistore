<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script type="text/javascript" src="__VENDOR__/jquery/modernizr.custom.46021.js"></script>
  <link rel="stylesheet" href="__VENDOR__/bootstrap/css/bootstrap.css" />
  <link rel="stylesheet" href="__VENDOR__/bootstrap/css/responsive.css" />
  <link rel="stylesheet" href="/content/css/matrix-style.css" />
  <link rel="stylesheet" href="/content/css/matrix-media.css" />
  <link rel="stylesheet" href="/content/css/common.css" />
  <link rel="stylesheet" href="__VENDOR__/bootstrap/css/bootstrap-modal.css" type="text/css" />
  <link rel="stylesheet" href="__VENDOR__/Gritter/css/custom.gritter.css" />
  <link href="/content/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!--[if lte IE 7]>
    <link href="/content/font-awesome/css/font-awesome-ie7.css" rel="stylesheet" />
  <![endif]-->
  <title>
    修改内容
  </title>
  
  <link rel="stylesheet" href="/content/css/style.css" type="text/css" />
  <link rel="stylesheet" href="__VENDOR__/fileupload/css/jquery.fileupload.css" type="text/css" />
  <link rel="stylesheet" href="__VENDOR__/select2/select2.css" type="text/css" />
  <!-- <link rel="stylesheet" href="__VENDOR__/fileupload/css/jquery.fileupload-ui.css" type="text/css" /> -->
  <style type="text/css">
    .screenshot-preview {
      margin: 0;
      padding: 0;
      list-style: none;
    }
    .screenshot-preview li {
      float: left;
      margin: 10px 10px 10px 0;
    }
    .screenshot-preview li img {
      max-width: 48px;
      max-height: 60px;
    }

    .screenshot-preview canvas {
      display: block;
    }
    .screenshot-preview .cancel-btn {
      display: block;
      text-align: center;
      margin: 0;
      padding: 0;
      width: 100%;
      box-sizing: border-box;
      font-size: 14px;
    }
    .cover-preview {
      margin-top: 10px;
    }
    .cover-preview img {
      max-width: 160px;
      max-height: 120px;
    }
  </style>

</head>
<body>
  <!--Header-part-->
  <div id="header">
    <h1><a href="dashboard.html">Longfota</a></h1>
  </div>
  <!--close-Header-part-->

  <!--top-Header-menu-->
  <div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
      <!--<li class="dropdown" id="profile-messages"><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i><span class="text">Welcome User</span><b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#"><i class="icon-user"></i>My Profile</a></li>
            <li class="divider"></li>
            <li><a href="#"><i class="icon-check"></i>My Tasks</a></li>
            <li class="divider"></li>
            <li><a href="login.html"><i class="icon-key"></i>Log Out</a></li>
          </ul>
        </li>
        <li class="dropdown" id="menu-messages"><a href="#" data-toggle="dropdown" data-target="#menu-messages" class="dropdown-toggle"><i class="icon icon-envelope"></i><span class="text">Messages</span> <span class="label label-important">5</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a class="sAdd" title="" href="#"><i class="icon-plus"></i>new message</a></li>
            <li class="divider"></li>
            <li><a class="sInbox" title="" href="#"><i class="icon-envelope"></i>inbox</a></li>
            <li class="divider"></li>
            <li><a class="sOutbox" title="" href="#"><i class="icon-arrow-up"></i>outbox</a></li>
            <li class="divider"></li>
            <li><a class="sTrash" title="" href="#"><i class="icon-trash"></i>trash</a></li>
          </ul>
        </li>-->
      <!--        <li class=""><a title="" href="#"><i class="icon icon-cog"></i><span class="text">Settings</span></a></li>-->
      <li class="">
        <a title="" href="__APP__/Account/logout">
          <i class="icon icon-share-alt"></i>
          <span class="text">注销</span>
        </a>
      </li>
      <li class="help">
        <a title="" href="#">
          <i class="icon-question-sign"></i>
          <span class="text">帮助</span>
        </a>
      </li>
    </ul>
  </div>
  <!--close-top-Header-menu-->
  <!--start-top-serch-->
 <!--  <div id="search">
    <input type="text" placeholder="Search here..." />
    <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
  </div> -->
  <!--close-top-serch-->
  <!--sidebar-menu-->
  <div id="sidebar">
    <?php echo W('Sidebar', $Think.MODULE_NAME);?>
  </div>
  <!--sidebar-menu-->

  <!--main-container-part-->
  <div id="content">
    <!--breadcrumbs-->
    <div id="content-header">
      <div id="breadcrumb">
  <?php if(is_array($breadcrumb)): foreach($breadcrumb as $key=>$bread): ?><a href="<?php echo ($bread['href']); ?>" title="<?php echo ($bread['title']); ?>" class="tip-bottom">
      <i class="<?php echo ($bread['icon']); ?>"></i><?php echo ($bread['desc']); ?>
    </a><?php endforeach; endif; ?>
</div>

    </div>
    <!--End-breadcrumbs-->

    <!--Action boxes-->
    <div class="container-fluid">
      
  <div class="container">
    <div class="container">
      <div class="panel">
        <div class="panelhead">修改<?php echo ($typeName); ?></div>
        <div class="panelcontent">
          <?php if($type == 'soft'): ?><div class="divform">
  <form class="form-horizontal" action="__APP__/Content/updatePost"
    method="post" id="addSoft" enctype="multipart/form-data">
    <input type="hidden" name="contentUuid" id="softUUID" value="<?php echo ($contentArray['contentUuid']); ?>"/>
    <input type="hidden" name="deletedPics" />
    <input type="hidden" name="type" value="soft" />
    <fieldset>
      <legend>填写应用信息</legend>
      <div class="control-group">
        <label class="control-label" for="softName">应用名称</label>
        <div class="controls">
          <input type="text" name="name" id="softName" data-auto="true" value="<?php echo ($contentArray['name']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="softFile">应用文件</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-folder-close"></i>
            <span id="softFileName"><?php echo ($contentArray['name']); ?>.apk</span>
            <input id="softFile" type="file" name="softFile" title="<?php echo ($contentArray['name']); ?>.apk, 点击重新选择" />
          </span>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="softScreenshot">应用截图</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-picture"></i>
            <span>选择截图图片(jpg, jpeg, png)...</span>
            <input id="softScreenshot" type="file" name="softScreenshot" multiple />
          </span>
          <ul id="softScreenshotPreview" class="screenshot-preview clearfix">
            <?php if(is_array($contentArray['pictures'])): foreach($contentArray['pictures'] as $key=>$imgPath): ?><li>
                <img src="<?php echo ($imgPath); ?>" />
                <a title="移除" data-value="<?php echo ($imgPath); ?>" href="javascript:void(0)" class="cancel-btn btn btn-danger">
                  <i class="icon-remove-circle"></i>
                </a>
              </li><?php endforeach; endif; ?>
          </ul>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="softPrice">价格(分)</label>
        <div class="controls">
          <input type="number" name="price" id="softPrice" value="<?php echo ($contentArray['price']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="softCategory">分类</label>
        <div class="controls">
          <select data-type="soft" name="category" id="softCategory" multiple style="height: 33px;" data-value="<?php echo ($contentArray['categories']); ?>">
          </select>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="softDesc">描述信息</label>
        <div class="controls">
          <textarea name="description" id="softDesc" style="width: 400px; height: 100px;" ><?php echo ($contentArray['description']); ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <div class="controls">
          <button type="submit" class="btn btn-primary"><i class="icon-save"></i> 保存</button>
        </div>
      </div>
    </fieldset>
  </form>
</div>

          <?php elseif($type == 'game'): ?>
            <div class="divform">
  <form class="form-horizontal" action="__APP__/Content/updatePost"
    method="post" id="addGame" enctype="multipart/form-data">
    <input type="hidden" name="contentUuid" id="gameUUID" value="<?php echo ($contentArray['contentUuid']); ?>" />
    <input type="hidden" name="deletedPics" />
    <input type="hidden" name="type" value="game" />
    <fieldset>
      <legend>填写游戏信息</legend>
      <div class="control-group">
        <label class="control-label" for="gameName">游戏名称</label>
        <div class="controls">
          <input type="text" name="name" id="gameName" data-auto="true" value="<?php echo ($contentArray['name']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="gameFile">游戏文件</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-folder-close"></i>
            <span id="gameFileName"><?php echo ($contentArray['name']); ?>.apk</span>
            <input id="gameFile" type="file" name="gameFile" title="<?php echo ($contentArray['name']); ?>.apk, 点击重新选择" />
          </span>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="gameScreenshot">游戏截图</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-picture"></i>
            <span>选择截图图片(jpg, jpeg, png)...</span>
            <input id="gameScreenshot" type="file" name="gameScreenshot" multiple >
          </span>
          <ul id="gameScreenshotPreview" class="screenshot-preview clearfix">
            <?php if(is_array($contentArray['pictures'])): foreach($contentArray['pictures'] as $key=>$imgPath): ?><li>
                <img src="<?php echo ($imgPath); ?>" />
                <a title="移除" href="javascript:void(0)" class="cancel-btn btn btn-danger">
                  <i class="icon-remove-circle"></i>
                </a>
              </li><?php endforeach; endif; ?>
          </ul>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="gamePrice">价格(分)</label>
        <div class="controls">
          <input type="number" name="price" id="gamePrice" value="<?php echo ($contentArray['price']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="gameCategory">分类</label>
        <div class="controls">
          <select data-type="game" name="category" id="gameCategory" multiple style="height: 33px;" data-value="<?php echo ($contentArray['categories']); ?>">
          </select>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="gameDesc">描述信息</label>
        <div class="controls">
          <textarea name="description" id="gameDesc" style="width: 400px; height: 100px;" ><?php echo ($contentArray['description']); ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <div class="controls">
          <button type="submit" class="btn btn-primary"><i class="icon-save"></i> 保存</button>
        </div>
      </div>
    </fieldset>
  </form>
</div>

          <?php elseif($type == 'video'): ?>
            <div class="divform">
  <form class="form-horizontal" action="__APP__/Content/updatePost" method="post" id="addVideo">
    <input type="hidden" name="contentUuid" id="videoUUID" value="<?php echo ($contentArray['contentUuid']); ?>" />
    <input type="hidden" name="deletedPics" />
    <input type="hidden" name="type" value="video" />
    <fieldset>
      <legend>填写视频信息</legend>
      <div class="control-group">
        <label class="control-label" for="videoName">视频名称</label>
        <div class="controls">
          <input type="text" name="nane" id="videoName" value="<?php echo ($contentArray['name']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoFile">视频文件</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-film"></i>
            <span id="videoFileName"><?php echo ($contentArray['name']); ?></span>
            <input type="file" name="videoFile" id="videoFile" title="<?php echo ($contentArray['name']); ?>, 点击重新选择" />
          </span>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoCover">视频封面</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-picture"></i>
            <span id="videoCoverName">选择视频封面(jpg, jpeg, png)...</span>
            <input type="file" name="videoCover" id="videoCover" />
          </span>
          <div id="videoCoverPreview" class="cover-preview">
            <img src="<?php echo ($contentArray['cover']); ?>" />
          </div>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoScreenshot">视频截图</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-picture"></i>
            <span id="videoScreenshotName">选择视频截图(jpg, jpeg, png)...</span>
            <input type="file" name="videoScreenshot" id="videoScreenshot" multiple />
          </span>
          <ul id="videoScreenshotPreview" class="screenshot-preview clearfix">
            <?php if(is_array($contentArray['pictures'])): foreach($contentArray['pictures'] as $key=>$imgPath): ?><li>
                <img src="<?php echo ($imgPath); ?>" />
                <a title="移除" href="javascript:void(0)" class="cancel-btn btn btn-danger">
                  <i class="icon-remove-circle"></i>
                </a>
              </li><?php endforeach; endif; ?>
          </ul>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoDesc">年份</label>
        <div class="controls">
          <select name="year" id="videoYear" data-value="<?php echo ($contentArray['year']); ?>"></select>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoDirector">导演</label>
        <div class="controls">
          <input type="text" name="director" id="videoDirector" value="<?php echo ($contentArray['director']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoActor">主演</label>
        <div class="controls">
          <input type="text" name="actors" id="videoActor" value="<?php echo ($contentArray['actors']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoPrice">价格(分)</label>
        <div class="controls">
          <input type="number" name="price" id="videoPrice" value="<?php echo ($contentArray['price']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoCategory">分类</label>
        <div class="controls">
          <select data-type="video" name="category" id="videoCategory" multiple style="height: 33px;" data-value="<?php echo ($contentArray['categories']); ?>">
          </select>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="videoDesc">描述信息</label>
        <div class="controls">
          <textarea name="description" id="videoDesc" style="width: 400px; height: 100px;" >
            <?php echo ($contentArray['description']); ?>
          </textarea>
        </div>
      </div>
      <div class="control-group">
        <div class="controls">
          <button type="submit" class="btn btn-primary"><i class="icon-save"></i> 保存</button>
        </div>
      </div>
    </fieldset>
  </form>
</div>

          <?php elseif($type == 'music'): ?>
            <div class="divform">
  <form class="form-horizontal" action="__APP__/Content/updatePost" method="post" id="addMusic">
    <input type="hidden" name="contentUuid" id="musicUUID" value="<?php echo ($contentArray['contentUuid']); ?>" />
    <input type="hidden" name="deletedPics" />
    <input type="hidden" name="type" value="music" />
    <fieldset>
      <legend>填写歌曲信息</legend>
      <div class="control-group">
        <label class="control-label" for="musicName">歌曲名称</label>
        <div class="controls">
          <input type="text" name="name" id="musicName" data-auto="true" value="<?php echo ($contentArray['name']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicFile">歌曲文件</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-music"></i>
            <span id="musicFileName"><?php echo ($contentArray['name']); ?></span>
            <input type="file" name="musicFile" id="musicFile" title="<?php echo ($contentArray['name']); ?>, 点击重新选择" />
          </span>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicCover">歌曲封面</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-picture"></i>
            <span id="musicCoverName">选择音乐封面(jpg, jpeg, png)...</span>
            <input type="file" name="musicCover" id="musicCover" />
          </span>
          <div id="musicCoverPreview" class="cover-preview">
            <img src="<?php echo ($contentArray['cover']); ?>" />
          </div>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicDesc">年份</label>
        <div class="controls">
          <select name="year" id="musicYear" data-value="<?php echo ($contentArray['year']); ?>"></select>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicSinger">歌手</label>
        <div class="controls">
          <input type="text" name="singer" id="musicSinger" value="<?php echo ($contentArray['singer']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicLyricist">作词家</label>
        <div class="controls">
          <input type="text" name="lyricist" id="musicLyricist" value="<?php echo ($contentArray['lyricist']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicComposer">作曲家</label>
        <div class="controls">
          <input type="text" name="composer" id="musicComposer" value="<?php echo ($contentArray['composer']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicPrice">价格(分)</label>
        <div class="controls">
          <input type="number" name="price" id="musicPrice" value="<?php echo ($contentArray['price']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="musicCategory">分类</label>
        <div class="controls">
          <select data-type="music" name="category" id="musicCategory" multiple style="height: 33px;" data-value="<?php echo ($contentArray['categories']); ?>">
          </select>
        </div>
      </div>
      <div class="control-group">
        <div class="controls">
          <button type="submit" class="btn btn-primary"><i class="icon-save"></i> 保存</button>
        </div>
      </div>
    </fieldset>
  </form>
</div>

          <?php elseif($type == 'picture'): ?>
            <div class="divform">
  <form class="form-horizontal" action="__APP__/Content/updatePost" method="post" id="addPicture">
    <input type="hidden" name="contentUuid" id="pictureUUID" value="<?php echo ($contentArray['contentUuid']); ?>" />
    <input type="hidden" name="deletedPics" />
    <input type="hidden" name="type" value="picture" />
    <fieldset>
      <legend>填写图片信息</legend>
      <!-- <div class="control-group">
        <label class="control-label" for="pictureName">图片名称</label>
        <div class="controls">
          <input type="text" name="pictureName" id="pictureName" data-auto="true" />
        </div>
      </div> -->
      <div class="control-group">
        <label class="control-label" for="pictureFile">图片文件</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-picture"></i>
            <span id="pictureFileName">选择图片文件(jpg, jpeg, png)...</span>
            <input type="file" name="pictureFile" id="pictureFile" />
          </span>
          <div class="cover-preview">
            <img src="<?php echo ($contentArray['filePath']); ?>" />
          </div>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="picturePrice">价格(分)</label>
        <div class="controls">
          <input type="number" name="price" id="picturePrice" value="<?php echo ($contentArray['price']); ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="pictureCategory">分类</label>
        <div class="controls">
          <select data-type="picture" name="category" id="pictureCategory" multiple style="height: 33px;" data-value="<?php echo ($contentArray['categories']); ?>">
          </select>
        </div>
      </div>
      <div class="control-group">
        <div class="controls">
          <button type="submit" class="btn btn-primary"><i class="icon-save"></i> 保存</button>
        </div>
      </div>
    </fieldset>
  </form>
</div><?php endif; ?>
        </div>
      </div>
    </div>
  </div>

    </div>
  </div>

  <!--end-main-container-part-->

  <!--Footer-part-->

  <div class="row-fluid">
    <div id="footer" class="span12">
      <div>2013 &copy; 文腾通信科技. </div>
      <div>服务热线:021-53332301 Email:service@wenteng.com 文腾通信科技 沪ICP备12015xx号</div>
    </div>
  </div>

  <div class="modal hide fade" id="help-modal">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h3>
        <i class="icon-question-sign"></i>
        <span>帮助</span>
      </h3>
    </div>
    <div class="modal-body">
    </div>
    <div class="modal-footer">
      <a href="#" class="btn btn-primary" data-dismiss="modal">我知道了</a>
    </div>
  </div>

  <!--end-Footer-part-->

  <script src="__VENDOR__/jquery/jquery.js"></script>
  <script src="__VENDOR__/matrix/matrix.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-tooltip.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-typeahead.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-button.js"></script>
  <script src="__VENDOR__/Gritter/js/jquery.gritter.custom.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-modal.js"></script>
  <script src="__VENDOR__/bootstrap/js/bootstrap-modalmanager.js"></script>
  <!--[if lte IE 8]>
  <script src="__VENDOR__/repond/respond.js"></script>
  <![endif]-->
  <script type="text/javascript">
    var ROOT = '__APP__';
    $(function () {
      $('.help a').on('click', function () {
        $.get('/help.html', function (html) {
          $('#help-modal .modal-body').html(html);
          $('#help-modal').modal('show');
        });
      });
    });
  </script>
  
  <script src="__SCRIPT__/common/common.js"></script>
  <script src="__VENDOR__/jquery.tools/src/tabs/tabs.js"></script>
  <script src="__VENDOR__/jquery.tools/src/tabs/tabs.slideshow.js"></script>
  <script>
    var isUpdate = true;
    var g_categories = JSON.parse('<?php echo ($categories); ?>'||'{}');
  </script>
  <script src="__VENDOR__/fileupload/js/vendor/jquery.ui.widget.js"></script>
  <script src="__VENDOR__/fileupload/js/vendor/canvas-to-blob.min.js"></script>
  <script src="__VENDOR__/fileupload/js/vendor/load-image.min.js"></script>
  <script src="__VENDOR__/fileupload/js/jquery.fileupload.js"></script>
  <script src="__VENDOR__/fileupload/js/jquery.fileupload-process.js"></script>
  <script src="__VENDOR__/fileupload/js/jquery.fileupload-image.js"></script>
  <!-- <script src="__VENDOR__/fileupload/js/jquery.fileupload-ui.js"></script> -->
  <script src="__VENDOR__/fileupload/js/jquery.fileupload-validate.js"></script>
  <script src="__VENDOR__/select2/select2.js"></script>
  <!-- <script src="__VENDOR__/jquery.maskedinput/jquery.maskedinput.js"></script> -->
  <!-- <script src="__VENDOR__/jszip/jszip.js"></script> -->
  <script src="__SCRIPT__/Content/add.js"></script>

</body>
</html>