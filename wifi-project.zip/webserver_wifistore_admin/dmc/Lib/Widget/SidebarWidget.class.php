<?php

/**
 * Sidebar short summary.
 *
 * Sidebar description.
 *
 * @version 1.0
 * @author Hank
 */
class SidebarWidget extends Widget
{
    public function render($data) {
        $curr = MODULE_NAME . '/' . ACTION_NAME;
        $data =array(
            "curr" => $curr,
            "menus" => array (
                "submenu_1" => array(
                    "text" => "内容管理",
                    "icon" => "icon-mobile-phone",
                    "menus" => array(
                        "Content/ListPage" => array("内容列表", "icon-mobile-phone"),
                        "Content/AddPage" => array("新增内容", "icon-mobile-phone"),
                        //"Content/Edit" => array("修改内容", "icon-mobile-phone"),
                        // "Content/Import" => array("批量导入内容包", ""),
                        "Content/ExportPage" => array("导出更新包", ""),
                        "OTA/taskPage" => array("更新包管理", "")
                    )
                ),
                "submenu_2" => array(
                    "text" => "数据统计",
                    "icon" => "icon-inbox",
                    "menus" => array(
                      "Statistics/Downloads" => array("内容下载统计", 'icon-list'),
                      "Statistics/Buys" => array("内容购买统计", 'icon-list')
                    )
                ),
                "submenu_3" => array(
                    "text" => "权限管理",
                    "icon" => "icon-shield",
                    "menus" => array(
                        "User/user_manager" => array("用户管理", ""),
                        "UserGroup/userGroup_manager" => array("用户组管理", ""),
                        "Project/project_mgr" => array("项目分配", "")
                    )
                )
            )
        );
        $currItem = $data['menus'][$curr];
        if (!$currItem) {
            foreach ($data['menus'] as $action => $menu)
            {
                if ($menu['menus']) {
                    $currItem = $menu['menus'][$curr];
                    if ($currItem) {
                        break;
                    }
                }
            }
        }
        $data['currItem'] = $currItem;
        return $this->renderFile('Sidebar', $data);
    }
}
