<?php

/**
 * DistributionAction short summary.
 *
 * DistributionAction description.
 *
 * @version 1.0
 * @author Hank
 */
class DistributionAction extends AuthAction
{
    public function index() {
        include_once(ROOT . "/controller/getResponse.php");
        $this->hobbyForDistrict = getFileContent(ROOT . '/data/AreaFavor1_hobby_of_province.json');
        
        $this->breadcrumb = array(
            array(
                'href' => U('Index/index'),
                'title' => '',
                'icon' => 'icon-home',
                'desc' => '首页'
            ),
            array(
                'href' => '#',
                'title' => '',
                'icon' => 'icon-globe',
                'desc' => '地域分布'
            )
        );
        $this->display();
    }

    public function getDistribution($month, $catId) {
        include_once(ROOT . "/controller/getResponse.php");
        if ($catId == '1') {
            $fileName = 'RegionalDistribution2_' . (9 - $month) . '.json';
        } else {
            $fileName = 'RegionalDistribution1_' . (9 - $month) . '.json';
        }
        $fileName = ROOT . '/data/' . $fileName;
        $this->show(getFileContent($fileName));
    }
}
