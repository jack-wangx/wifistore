<?php

/**
 * DeviceAction short summary.
 *
 * DeviceAction description.
 *
 * @version 1.0
 * @author Hank
 */
class DeviceAction extends AuthAction
{
    public function index() {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"设备管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"",
                "desc"=>"设备排名统计"
            )
        );
        $this->display();
    }

    public function getpro($pageNum, $type, $pv='', $dv='') {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $page = intval($pageNum);
        $projectvalue=$pv;
        $devicevalue=$dv;
        
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
            return;
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $proInfo=getShowInfoOfPro($type,$page,$axoValueArray);
            
            echo json_encode($proInfo);
        }
    }
    
    public function getall($pv='', $dv='') {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $is_admin=isAdmin($groupId,$sp);
        $projectvalue=$pv;
        $devicevalue=$dv;
        
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
            return;
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $proInfo=getShowInfo($axoValueArray);
            
            echo json_encode($proInfo);
        }
    }

    public function serviceProvider() {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"设备管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"运营商设备分布"
            )
        );
        $this->display();
    }
    
    public function getSPData($type, $name, $pv=null, $dv=null) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $is_admin=isAdmin($groupId,$sp);
        $projectvalue=$pv;
        $devicevalue=$dv;

        if(empty($type)||empty($name)){
            echo json_encode(array('status'=>9999));
            return;
        }
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
            return;
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $proInfo=getShowInfoForSPData($axoValueArray,$type,$name);
            
            echo json_encode($proInfo);
        }
    }
    
    public function simDistribution() {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"设备管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"双卡设备分布"
            )
        );
        $this->display();
    }

    public function getSimDist($type, $name, $pv=null, $dv=null) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $is_admin=isAdmin($groupId,$sp);
        $projectvalue=$pv;
        $devicevalue=$dv;

        if(empty($type)||empty($name)){
            echo json_encode(array('status'=>9999));
            return;
        }
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
            return;
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $proInfo=getShowInfoForSimDist($axoValueArray,$type,$name);
            
            echo json_encode($proInfo);
        }
    }
}


function getShowInfoOfPro($type,$page,$axoValueArray){
    if($type==0){

    }elseif ($type==1) {
        $sql_sim=" simCount>0 and ";
    }elseif ($type==2) {
        $sql_sim=" simCount=0 and ";
    }else{

    }
    $axo_values_sql = '"'.implode('","', $axoValueArray).'"';
    $sql_get_count="select province,count(*) as total from UserInfo u left join province p on u.provinceId=p.provinceId where".$sql_sim." axo_value in (". $axo_values_sql . ')  group by province order by total desc';
    
    $result_count=mysql_query($sql_get_count);
    $totals = mysql_num_rows($result_count);

    $pageSize = 4; //每页显示数
    $totalPage = ceil($totals/$pageSize); //总页数

    $startPage = $page*$pageSize;
    $arr['totals'] = $totals;
    $arr['pageSize'] = $pageSize;
    $arr['totalPage'] = $totalPage;

    $sql_get_info_by_page="select province,count(*) as total from UserInfo u left join province p on u.provinceId=p.provinceId where ".$sql_sim."axo_value in (". $axo_values_sql . ") group by province order by total desc limit $startPage,$pageSize";
    $result_category=mysql_query($sql_get_info_by_page);
    
    if(mysql_num_rows($result_category)>0){
        $i=0;
        $arr['status']=1000;
        while($row=mysql_fetch_array($result_category)){
            $i=$i+1;
            $arr['list'][] = array(
               'i'=>$i,
                'province' => $row['province'],
               'total' => $row['total'],
            );
        }
    }else{
        $arr['status']=1002;
    }
    return $arr;
}

function getShowInfo($axoValueArray){
    $axo_values_sql = '"'.implode('","', $axoValueArray).'"';
    $sql_count="SELECT count(id) as total FROM UserInfo where axo_value in (". $axo_values_sql . ')';
    
    $result_count = mysql_query($sql_count);
    $row_count=mysql_fetch_array($result_count);
    if($row_count['total'] > 0){
        $totaldevice=$row_count['total'];
    }else{
        
        $arr['countall'][] = array(
                'totaldevice' => $row_count['total'],
                'project' => count($axoValueArray),
                'totalnosim' => '0',
                'totalyessim' => '0'
            );
        return $arr;
    }
    $arr['countall'][] = array(
                'totaldevice' => $totaldevice,
                'project' => count($axoValueArray),
                'totalnosim' => getCountBySim(false,$axo_values_sql),
                'totalyessim' => getCountBySim(true,$axo_values_sql)
            );
    return $arr;

}

function getShowInfoForSPData($axoValueArray,$type,$name){
    $axo_values_sql = '"'.implode('","', $axoValueArray).'"';
    $sql_select_device_count="select count(si.id)count from sim_info si inner join UserInfo ui on si.userId=ui.userId where network_perator!='' and (ui.sim1_iccid=si.sim_iccid or ui.sim2_iccid=si.sim_iccid) and ui.axo_value  in (". $axo_values_sql . ')' ;
    $sql_select_count_by_catagory="select network_perator,count(si.id)count from sim_info si inner join UserInfo ui on si.userId=ui.userId 
										where network_perator!='' and (ui.sim1_iccid=si.sim_iccid or ui.sim2_iccid=si.sim_iccid)  and ui.axo_value in (". $axo_values_sql . ') group by network_perator';
    
    $result_count=mysql_query($sql_select_device_count);
    $row_count=mysql_fetch_array($result_count);
    if($row_count['count']>0){
        $arr['status']=1000;
        $count=$row_count['count'];
        $arr['count']=$count;

        $result_count_by_category=mysql_query($sql_select_count_by_catagory);
        $num=mysql_num_rows($result_count_by_category);
        if($num>0){
            while($row=mysql_fetch_array($result_count_by_category)){
                $arr_unit['data'][]=array(
                        'name'=>$row['network_perator'],
                        'y'=>round($row['count']/$count*100, 1)
                    );
            }
            $arr_unit['type']=$type;
            $arr_unit['name']=$name;
            $arr['bean']=$arr_unit;
        }else{
            $arr['status']=2001;
        }
        
    }else{
        $arr['status']=2001;
    }

    return $arr;
}

function getShowInfoForSimDist($axoValueArray,$type,$name){
    $axo_values_sql = '"'.implode('","', $axoValueArray).'"';
    $sql_select_device_count="select count(id) count from UserInfo where axo_value in (". $axo_values_sql . ')';
    $sql_select_count_by_catagory="select simCount,count(id) count from UserInfo where axo_value in (". $axo_values_sql . ')  group by simCount';
    
    $result_count=mysql_query($sql_select_device_count);
    $row_count=mysql_fetch_array($result_count);
    if($row_count['count']>0){
        $arr['status']=1000;
        $count=$row_count['count'];
        $arr['count']=$count;

        $result_count_by_category=mysql_query($sql_select_count_by_catagory);
        $num=mysql_num_rows($result_count_by_category);
        if($num>0){
            while($row=mysql_fetch_array($result_count_by_category)){
                $arr_unit['data'][]=array(
                        'name'=>$row['simCount'],
                        'y'=>round($row['count']/$count*100, 1)
                    );
            }
            $arr_unit['type']=$type;
            $arr_unit['name']=$name;
            $arr['bean']=$arr_unit;
        }else{
            $arr['status']=2001;
        }
        
    }else{
        $arr['status']=2001;
    }

    return $arr;
}

function getCountBySim($isHave,$axo_values_sql){
    
    if($isHave){
        $simstr=" simCount>0 ";
    }else{
        $simstr=" simCount=0 ";	
    }
    $sql_count_by_sim="select count(*) as total from UserInfo u left join province p on u.provinceId=p.provinceId 
						where". $simstr." and axo_value in (". $axo_values_sql . ') order by total desc';
    
    $result_count = mysql_query($sql_count_by_sim);
    $row_count=mysql_fetch_array($result_count);
    return $row_count['total'];
}
