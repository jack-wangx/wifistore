<?php

/**
 * AppManagerAction short summary.
 *
 * AppManagerAction description.
 *
 * @version 1.0
 * @author Hank
 */
class AppManagerAction extends AuthAction
{
    public function app_total() {
        $this->breadcrumb  = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"icon-inbox",
                "desc"=>"应用管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"",
                "desc"=>"应用信息排名"
            )
        );
        $this->display();
    }

    public function getUsedTime($pv='', $dv='', $pageNum='0') {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');

        $groupId=$_SESSION['groupId'];
        $sp = $_SESSION['solutionProvider'];
        $page = intval($pageNum);
        if(empty($page)){
            $page=0;
        }
        $is_admin=isAdmin($groupId,$sp);

        $projectvalue = $pv;
        $devicevalue = $dv;

        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);

        } elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        } else {
            echo json_encode(array('status'=>9999));
            return;
        }

        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
            return;
        } else {
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $appInfos=getAppByAxoValues($axoValueArray,$page);
            echo json_encode($appInfos);
        }
    }

    public function getUsedCount($pv='', $dv='', $pageNum='0') {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');

        $groupId=$_SESSION['groupId'];
        $sp = $_SESSION['solutionProvider'];
        $page = intval($pageNum);
        if(empty($page)){
            $page=0;
        }
        $is_admin=isAdmin($groupId,$sp);
        $projectvalue = $pv;
        $devicevalue = $dv;
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);

        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }

        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
            return;
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $appCountInfo=getAppCountInfoByAxoValues($axoValueArray,$page);

            echo json_encode($appCountInfo);
        }
    }

    public function getActivaction($pv='', $dv='', $pageNum='0') {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');

        $groupId=$_SESSION['groupId'];
        $sp = $_SESSION['solutionProvider'];
        $page = intval($pageNum);
        if(empty($page)){
            $page=0;
        }
        $is_admin=isAdmin($groupId,$sp);
        $projectvalue = $pv;
        $devicevalue = $dv;
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);

        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }

        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $appActivaction=getAppActivactionInfoByAxoValues($axoValueArray,$page);

            echo json_encode($appActivaction);
        }
    }

    public function app_single() {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>"",
                "title"=>"",
                "icon"=>"icon-inbox",
                "desc"=>"应用管理"
            ),
            array(
                "href"=>"",
                "title"=>"",
                "icon"=>"",
                "desc"=>"单个应用统计信息"
            )
        );

        $this->display();
    }

    public function getSingle($title='', $device='', $project='') {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');

        $groupId=$_SESSION['groupId'];
        $sp = $_SESSION['solutionProvider'];
        $projectvalue=$project;
        $devicevalue=$device;
        $keys = $title;

        if(!$projectvalue || $projectvalue==-1){
            $projectvalue=0;
        }
        if(!$devicevalue ||  $devicevalue==-1){
            $devicevalue=0;
        }
        $is_admin=isAdmin($groupId,$sp);
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);

        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            return json_encode(array('status'=>9999));
        }

        if(empty($axoDetailArray)){
            return json_encode(array('status'=>1002));
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            mysql_query("set names utf8");
            $axo_values_sql = '"'.implode('","', $axoValueArray).'"';
            $sql="select appPagesname from APPUsageDetails a left join UserInfo u on a.userID=u.userId where u.solutionProviders='$sp' and issystemApp =  0  and (lower(appName) like lower('%$keys%') or lower(appPagesname)=lower('$keys')) and u.axo_value in ($axo_values_sql) group by appPagesname";
            $result=mysql_query($sql) or die("select failed:".mysql_error());;
            $count=mysql_num_rows($result);
            if($count==1){
                $row=mysql_fetch_array($result);
                $searchvalue=$row['appPagesname'];
                $appcountsql="SELECT appName,appPagesname,usedTime,usedCount, a.provinceId, SUM(usedCount) AS count, SUM( usedTime ) AS time, count(1) installCount FROM APPUsageDetails a left join UserInfo u on a.userID=u.userId where u.axo_value in ($axo_values_sql) and lower(appPagesname)=lower('$searchvalue') and issystemApp =  0 GROUP BY appPagesname ORDER BY count DESC";
                $arr['appcountsql'] = $appcountsql;
                $querycount=mysql_query($appcountsql);
                //$appall=$row['installCount'];
                $row=mysql_fetch_array($querycount);
                $totaltime=$row['time'];//usedTime
                $hour =$totaltime/(60*60*1000);
                $minitue=($totaltime%(60*60*1000))/(60*1000);
                $second=(($totaltime%(60*60*1000))%(60*1000))/1000;
                $totaltime=floor($hour)."时".floor($minitue)."分".floor($second)."秒";
                $arr['appDetail'][] = array(
                     'appName' => $row['appName'],
                    'appPagesname' => $row['appPagesname'],
                    'usedCount' => $row['count'],//usedCount
                    'usedTime' => $totaltime,
                    'appallcount' => $row['installCount'] * 13//$appall,
                 );
                $arr['status'] = 1000;
                echo json_encode($arr);
                return;
            }
            if($count > 1){
                //$i=0;
                while($row=mysql_fetch_array($result)){
                    $searchvalue=$row['appPagesname'];
                    $sql_by_search="SELECT appName,appPagesname,usedTime,usedCount, a.provinceId, SUM(usedCount) AS count, SUM( usedTime ) AS time FROM APPUsageDetails a left join UserInfo u on a.userID=u.userId where u.axo_value in ($axo_values_sql) and lower(appPagesname)='$searchvalue' and issystemApp =  0 GROUP BY appPagesname ORDER BY count DESC";
                    $query_by_search=mysql_query($sql_by_search);
                    $rows=mysql_fetch_array($query_by_search);
                    $arr['appList'][] = array(
                         'appName' => $rows['appName'],
                        'appPagesname' => $rows['appPagesname']
                     );
                    //$i++;
                }
                $arr['sql_by_search'] = "sql_by_search=".$sql_by_search;
                $arr['appDetail'] = null;
                $arr['status'] = 1000;
                echo json_encode($arr);
                return;
            }else{
                $arr['status'] = 2001;
                echo json_encode($arr);
                return;
            }
        }
    }

    public function task_list($action='list') {
        header("Content-Type: text/html; charset=utf-8");
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>"",
                "title"=>"",
                "icon"=>"icon-inbox",
                "desc"=>"应用管理"
            ),
            array(
                "href"=>"",
                "title"=>"",
                "icon"=>"",
                "desc"=>"应用任务管理"
            )
        );

        if ($action == 'list') {
            $this->display();
        } else if ($action == 'add') {
            $this->timestamp = time();
            $this->token = md5('unique_salt' . $timestamp);
            $this->display('AppManager:add_task');
        }
    }

    public function getTask($taskValue=null, $pv=null,  $dv=null) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');

        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $is_admin=isAdmin($groupId,$sp);
        $tasktype=$taskValue;
        $projectvalue=$pv;
        $devicevalue=$dv;

        if($is_admin==0){
            $axoDetailArray=getAppTaskInfo('admin',$groupId,$sp,$projectvalue,$devicevalue);
        } elseif ($is_admin==1) {
            $axoDetailArray=getAppTaskInfo('user',$groupId,$sp,$projectvalue,$devicevalue);
            // echo json_encode($axoDetailArray);
        } else {
            return json_encode(array('status'=>2001));
        }
        if(empty($axoDetailArray)){
            return json_encode(array('status'=>2001));
        } else {
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');

            if (!empty($axoValueArray)){
                $appTaskInfo=getAppTaskByAxoValues($axoValueArray,$tasktype);
            }
            echo json_encode($appTaskInfo);
        }
    }


    public function updateTask($appInfos=null, $taskInfo=null) {
        include_once(ROOT . '/controller/conn.php');
        if(empty($taskInfo) && empty($appInfos)){
            echo json_encode(array('status'=>1000));
        }
        if(!empty($taskInfo)){
            $remark=$taskInfo['remark'];
            $taskuuid=$taskInfo['taskuuid'];
            if(empty($taskuuid)){
                echo json_encode(array('status'=>9999));
                return;
            }else{
                $sql_update_task="update assignmentList set remark='$remark' where uuid='$taskuuid'";
                mysql_query($sql_update_task);
            }
        }

        if(!empty($appInfos)){
            foreach ($appInfos as $appInfo) {
                $appuuid=$appInfo['appuuid'];
                $description=$appInfo['description'];
                if(empty($appuuid)){
                    echo json_encode(array('status'=>9999));
                    return;
                }else{
                    $sql_update_task="update appPush set description='$description' where apkuuid='$appuuid'";
                    mysql_query($sql_update_task);
                }
            }
        }
        echo json_encode(array('status'=>1000));

    }

    public function delTask($taskuuid) {
        include_once(ROOT . '/controller/conn.php');
        if(empty($taskuuid)){
            echo json_encode(array('status'=>1002));
        }else{
            $sql_delete_task="update assignmentList set useFlag=1 where uuid='$taskuuid'";
            mysql_query($sql_delete_task);
            echo json_encode(array('status'=>1000));
        }
    }

    public function setPushStatus($taskuniqueId, $appStatusnum) {
        include_once(ROOT . '/controller/conn.php');
        $arr['appStatusnum'] = $appStatusnum;
        //$page = intval($_POST['pageNum']);
        if ($appStatusnum == 1) {
            //todo 正常逻辑为status=0
            $sqltype="set status=-1";
        }
        if($appStatusnum == -1){
            $sqltype="set status=1";
        }else{
            $arr['affected'] = '-1';
        }

        $strsql="update assignmentList $sqltype WHERE uuid='$taskuniqueId'";
        //$sql = $strsql;
        //$arr['sql'] = $sql;
        $result=mysql_query($strsql);
        $totals = mysql_affected_rows();//总记录数
        if($totals > 0){

            $arr['affected'] = '0';
        }else{
            $arr['affected'] = '-1';
        }

        echo json_encode($arr);
    }
}

function getAppByAxoValues($axoValues,$page){
    $axo_values_sql = '"'.implode('","', $axoValues).'"';
    $sql_select_app="SELECT appName, appPagesname, SUM( usedTime ) AS count FROM APPUsageDetails a inner join UserInfo u on a.userID=u.userId where u.axo_value in (". $axo_values_sql . ") GROUP BY appPagesname ORDER BY count DESC";

    $count_result=mysql_query($sql_select_app);
    $totals = mysql_num_rows($count_result);//总记录数
    $pageSize = 10; //每页显示数
    $totalPage = ceil($totals/$pageSize); //总页数
    $startPage = $page*$pageSize;
    $appInfo['totals'] = $totals;
    $appInfo['pageSize'] = $pageSize;
    $appInfo['totalPage'] = $totalPage;

    $sql_select_app_limit="SELECT appName, appPagesname, cast(SUM( usedTime ) as char(100)) AS count FROM APPUsageDetails a inner join UserInfo u on a.userID=u.userId where u.axo_value in (". $axo_values_sql . ") GROUP BY appPagesname ORDER BY sum(usedTime) DESC limit $startPage,$pageSize";

    $apps = mysql_query($sql_select_app_limit);

    $appInfo['status']=1002;
    while($row=mysql_fetch_array($apps)){
        $appInfo['status']=1000;
        $appInfo['list'][]= array(
            'rank'=>++$startPage,
            'appName' => $row['appName'],
            'total' => ms2time($row['count'])
            );
    }
    return $appInfo;
}

function ms2time($ms) {
    $seconds = gmp_div($ms, 1000);
    $str = ":" . sprintf("%02d", gmp_mod($seconds, 60));//"%02d" 格式化为整数，2位，不足2位，左边补0


    $minutes = gmp_div($seconds, 60);
    $str = ":" . sprintf("%02d", gmp_mod($minutes, 60)) . $str;
    $hours = gmp_div($minutes, 60);
    $str = gmp_strval($hours) . $str;
    return $str;
}

function getAppCountInfoByAxoValues($axoValues,$page){
    $axo_values_sql = '"'.implode('","', $axoValues).'"';
    $sql_select_app="SELECT SUM( usedCount ) AS count FROM APPUsageDetails a inner join UserInfo u on a.userID=u.userId where u.axo_value in (". $axo_values_sql . ") GROUP BY appPagesname ORDER BY count DESC";
    $count_result=mysql_query($sql_select_app);
    $totals = mysql_num_rows($count_result);//总记录数
    $pageSize = 10; //每页显示数
    $totalPage = ceil($totals/$pageSize); //总页数
    $startPage = $page*$pageSize;
    $appInfo['totals'] = $totals;
    $appInfo['pageSize'] = $pageSize;
    $appInfo['totalPage'] = $totalPage;

    $sql_select_app_limit = "SELECT appName,SUM( usedCount ) AS count FROM APPUsageDetails a inner join UserInfo u on a.userID=u.userId where u.axo_value in (". $axo_values_sql . ") GROUP BY appPagesname ORDER BY count DESC limit $startPage,$pageSize";

    $apps = mysql_query($sql_select_app_limit);

    $appInfo['status']=1002;
    while($row=mysql_fetch_array($apps)){
        $appInfo['status']=1000;
        $appInfo['list'][]= array(
            'rank'=>++$startPage,
            'appName' => $row['appName'],
            'total' => $row['count']
            );
    }
    return $appInfo;

}

function getAppActivactionInfoByAxoValues($axoValues,$page){
    $axo_values_sql = '"'.implode('","', $axoValues).'"';
    $sql_select_app="select appName, COUNT( * ) AS count FROM APPUsageDetails a inner join UserInfo u on a.userID=u.userId WHERE issystemApp =0 and usedCount>=1 and u.axo_value in (". $axo_values_sql . ") GROUP BY appPagesname";
    $count_result=mysql_query($sql_select_app);
    $totals = mysql_num_rows($count_result);//总记录数
    $pageSize = 10; //每页显示数
    $totalPage = ceil($totals/$pageSize); //总页数
    $startPage = $page*$pageSize;
    $appInfo['totals'] = $totals;
    $appInfo['pageSize'] = $pageSize;
    $appInfo['totalPage'] = $totalPage;

    $sql_select_app_limit="select appName, COUNT( * ) AS count FROM APPUsageDetails a inner join UserInfo u on a.userID=u.userId WHERE issystemApp =0 and usedCount>=1 and u.axo_value in (". $axo_values_sql . ") GROUP BY appPagesname ORDER BY count DESC limit $startPage,$pageSize";

    $apps = mysql_query($sql_select_app_limit);

    $appInfo['status']=1002;
    while($row=mysql_fetch_array($apps)){
        $appInfo['status']=1000;
        $appInfo['list'][]= array(
            'rank'=>++$startPage,
            'appName' => $row['appName'],
            'total' => $row['count'] * 13
            );
    }
    return $appInfo;

}

function getAppTaskInfo($type,$groupId,$sp,$project,$device){

    switch ($type) {
        case 'admin':
            $axoDetailArray=getAxoDetailsArrayBySp($sp,$device,$project);
            break;
        case 'user':
            $axoDetailArray=getAxoDetailsArray($groupId,$device,$project);
            break;
    }
    return $axoDetailArray;
}

function getAppTaskByAxoValues($axoValues,$tasktype){
    mysql_query("set names 'utf8'");
    $axo_values_sql = '"'.implode('","', $axoValues).'"';

    $sql_select_assignments="select agl.id,agl.uuid as taskuuid,agl.tasktype,agl.review,agl.createTime,tam.axo_value,agl.remark,agl.status from assignmentList agl inner join task_axo_map tam on agl.id=tam.assignmentId where agl.useFlag=0 and tam.axo_value in (".$axo_values_sql.") group by agl.id";
    if(isset($tasktype)){
        $sql_select_assignments="select agl.id,agl.uuid as taskuuid,agl.tasktype,agl.review,agl.createTime,tam.axo_value,agl.remark,agl.status  from assignmentList agl inner join task_axo_map tam on agl.id=tam.assignmentId where agl.useFlag=0 and tasktype=$tasktype and tam.axo_value in (".$axo_values_sql.") group by agl.id";
    }



    $assignment_result=mysql_query($sql_select_assignments);

    $taskList['status']=1002;

    while($assignment_row=mysql_fetch_array($assignment_result)){

        $taskList['status']=1000;

        $id=$assignment_row['id'];
        $taskuuid=$assignment_row['taskuuid'];
        $tasktype=$assignment_row['tasktype'];
        $review=$assignment_row['review'];
        $createTime=$assignment_row['createTime'];
        $remark=$assignment_row['remark'];
        $status=$assignment_row['status'];

        $sql_select_axo="select device,project from assignmentList agl inner join task_axo_map tam on agl.id=tam.assignmentId inner join long_custom_axo_details lcad on tam.axo_value = lcad.axo_value  where agl.id=$id group by device";
        $axo_result=mysql_query($sql_select_axo);
        $axoinfos=array();
        $projects="";
        while ($axo_row=mysql_fetch_array($axo_result)){
            $axoinfos['axoinfo'][]=array(
                'device'=> $axo_row['device'],
                'project'=> $axo_row['project'],
                );
            $projects=$projects.','.$axo_row['project'];
        }

        $sql_select_apps="select ap.appName,ap.apkuuid,ap.description,ap.picUrl from appPush ap inner join task_app_map tam on ap.id=tam.appId where assignmentId=$id";
        $app_result=mysql_query($sql_select_apps);
        $appInfos=array();
        $apps="";
        while($app_row=mysql_fetch_array($app_result)){
            $appName=$app_row['appName'];
            $apps=$apps.','.$appName;
            $apkuuid=$app_row['apkuuid'];
            $picUrl=$app_row['picUrl'];
            $description=$app_row['description'];
            $pushNum=0;
            $installNum=0;
            $successNum=0;
            $sql_select_app_feedback="select count(id)count,TYPE from TaskFeedback where TASK_UNIQUED='$apkuuid' group by TEYP";
            $feedbackResult=mysql_query($sql_select_app_feedback);
            while ( $feedback_row=mysql_fetch_array($feedbackResult)) {
                $type=$feedback_row['type'];
                switch ($type) {
                    case 1001:
                        $pushNum=$feedback_row['count'];
                        break;
                    case 1002:
                        $installNum=$feedback_row['count'];
                        break;
                    case 1003:
                        $successNum=$feedback_row['count'];
                        break;

                    default:
                        # code...
                        break;
                }
            }
            $successRate=round($successNum/$installNum*100, 2);

            $appInfos['appinfo'][]=array(
                'appName'=>$appName,
                'description'=>$description,
                'appuuid'=>$apkuuid,
                'picUrl'=>$picUrl,
                'pushNum'=>$pushNum,
                'installNum'=>$installNum,
                'successRate'=>$successRate
                );


        }



        $taskList['list'][]=array(
            'taskuuid'=>$taskuuid,
            'tasktype'=>$tasktype,
            'review'=>$review,
            'remark'=>$remark,
            'status'=>$status,
            'createTime'=>$createTime,
            'projects'=>$projects,
            'apps'=>$apps,
            'appinfos'=>$appInfos,
            'axoinfos'=>$axoinfos
            );

    }
    return $taskList;


}

