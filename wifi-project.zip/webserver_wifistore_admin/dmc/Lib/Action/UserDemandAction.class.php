<?php

/**
 * UserDemand short summary.
 *
 * UserDemand description.
 *
 * @version 1.0
 * @author Hank
 */
class UserDemandAction extends AuthAction
{
    public function index() {
        $this->hobbies = array(
            "游戏", "社交", "旅游", "音乐", "影视", "阅读", "教育", "商务", "购物", "数码",
            "金融", "体育", "动漫"
        );

        $this->hobbyMap = array(
            "阅读" => "icon-book",
            "社交" => "icon-facebook-sign",
            "音乐" => "icon-music",
            "购物" => "icon-shopping-cart",
            "游戏" => "icon-gamepad",
            "影视" => "icon-film",
            "旅游" => "icon-plane",
            "金融" => "icon-jpy",
            "数码" => "icon-camera",
            "商务" => "icon-suitcase",
            "教育" => "icon-edit-sign",
            "体育" => "icon-sport",
            "动漫" => "icon-cartoon"
        );

        $this->breadcrumb = array(
            array(
                'href' => U('Index/index'),
                'title' => '',
                'icon' => 'icon-home',
                'desc' => '首页'
            ),
            array(
                'href' => '#',
                'title' => '',
                'icon' => 'icon-list-alt',
                'desc' => '地域分布'
            )
        );

        $this->display();
    }

    public function getAppList($hobby) {
        include_once(ROOT . "/controller/getResponse.php");
        $contents=getFileContent(ROOT . '/data/hobby_apps.js');
        $contentsJson=json_decode($contents, true);
        echo(json_encode($contentsJson[$hobby]));
    }
}
