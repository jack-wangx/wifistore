<?php

/**
 * BaseAction short summary.
 *
 * BaseAction description.
 *
 * @version 1.0
 * @author wx
 */
class AuthAction extends Action
{
    public function _initialize(){
        header("Content-type: text/html; charset=utf-8");
        $code = 0;
        if(empty($_SESSION["solutionProvider"])){
			$code = 1002;
		} else {
            // $actionName=$this->getActionName();
			$code=$this->checkPermission();
		}
        if ($code == 1000) {
            return true;
        } else if ($code == 1001) {

            $this->redirect('Index/index');
        } else {
            $this->redirect('Account/login');
        }
    }

    private function checkPermission(){
        $actionName=$this->getActionName();
        $permissionActions=array('User','UserGroup');
        $contentActions=array('Content', 'OTA');
        $statisticsActions=array('');

        if(in_array($actionName, $permissionActions)){
            $allow = $_SESSION["permission"];

            if($allow===''){

                $code = 1002;
            }elseif ($allow==1) {
                $code = 1000;
            }else{
                $code = 1001;
            }
            return  $code;
        }

        if(in_array($actionName, $contentActions)){
            $allow = $_SESSION["content"];
            if($allow===''){
                $code = 1002;
            }elseif ($allow==1) {
                $code = 1000;
            }else{
                $code = 1001;
            }
            return  $code;
        }

        if(in_array($actionName, $statisticsActions)){
            $allow = $_SESSION["statistics"];
            if($allow===''){
                $code = 1002;
            }elseif ($allow==1) {
                $code = 1000;
            }else{
                $code = 1001;
            }
            return  $code;
        }
        return 1001;
    }

    protected function logFile($filename,$msg){
        //���ļ�
        $fd = fopen($filename,"a");
        //�����ļ�
        $str = "[".date("Y/m/d h:i:s",time())."]".$msg;
        //д���ַ���
        fwrite($fd, $str."\n");
        //�ر��ļ�
        fclose($fd);
    }
}
