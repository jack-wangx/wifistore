<?php

/**
 * FotaAction short summary.
 *
 * FotaAction description.
 *
 * @version 1.0
 * @author Hank
 */
class FotaAction extends AuthAction
{
    public function summary() {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"设备管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"",
                "desc"=>"版本概况"
            )
        );
        $this->display();
    }
    
    public function getVersionDistri($type, $name) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        
        if(empty($type)||empty($name)){
            echo json_encode(array('status'=>9999));
            return;
        }
        $is_admin=isAdmin($groupId,$sp);
        
        if($is_admin==0){
            $axoDetailArray=getAxoInfos('admin',$groupId,$sp,$projectvalue,$devicevalue);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoInfos('user',$groupId,$sp,$projectvalue,$devicevalue);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
            return;
        }else{
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');
            $proInfo=getShowInfoByAxoValues($axoValueArray,$type,$name);

            echo json_encode($proInfo);
        }
    }
    
    public function getVersionDistriByAxo($axoValue, $type, $name) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        if(empty($type)||empty($name)||empty($axoValue)){
            echo json_encode(array('status'=>9999));
            return;
        }
        
        $verArr=getShowInfoByAxo($axoValue,$type,$name);

        echo json_encode($verArr);
    }
    
    public function versionMgr($action="list") {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"设备管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"",
                "desc"=>"版本管理"
            )
        );
        if ($action=="list") {
            $this->display();
        } else if($action=="add") {
            $this->timestamp = time();
            $this->token = md5('unique_salt' . $timestamp);
            $this->display('Fota:version_add');
        }
    }

    public function getVersion($pv=null, $dv=null) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $projectvalue=$pv;
        $devicevalue=$dv;
        $is_admin=isAdmin($groupId,$sp);
        
        if($is_admin==0){
            
            $axoDetailArray=getAxoListInfo('admin',$groupId,$sp,$projectvalue,$devicevalue);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoListInfo('user',$groupId,$sp,$projectvalue,$devicevalue);
            // echo json_encode($axoDetailArray);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        
        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
        }else{
            // $deviceArray=getSingleElementArray($axoDetailArray,'device');
            // $projectArray=getSingleElementArray($axoDetailArray,'project');
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');

            if(!empty($axoValueArray)){
                $appTasks=getRomByAxoValues($axoValueArray);
            }
            
            echo json_encode($appTasks);
        }
    }
    
    public function delVersion($axo_value, $versionCode) {
        include_once(ROOT . '/controller/conn.php');
        
        $this->logFile(log,$axo_value.';;;;'.$versionCode);
        if(empty($axo_value)||empty($versionCode)){
            echo json_encode(array('status'=>9999));
            return;
        }else{
            $sql_select_ota_by_rominfo="select filename from otainfo where axo_value='$axo_value' and (fromVersionCode='$versionCode' or toVersionCode='$versionCode') ";
            $this->logFile(log,$sql_select_ota_by_rominfo);
            $ota_result=mysql_query($sql_select_ota_by_rominfo);
            if(mysql_num_rows($ota_result)>0){
                echo json_encode(array('status'=>4001));
            }else{
                $sql_update_rom="update  rominfo set delflag=0 where axo_value='$axo_value' and versionCode='$versionCode'";
                $this->logFile(log,$sql_update_rom);
                mysql_query($sql_update_rom);
                echo json_encode(array('status'=>1000));
            }
        }
    }
    
    public function ota_manager($action="list") {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"设备管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"",
                "desc"=>"OTA管理"
            )
        );
        if ($action == "list") {
            $this->display();
        } else if ($action == "add") {
            $this->display("Fota/ota_add");
        }
    }

    public function getOtaList($pv=null, $dv=null) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $is_admin=isAdmin($groupId,$sp);
        $projectvalue = $pv;
        $devicevalue = $dv;
        
        include_once(ROOT . '/dmc/Lib/Action/Fota/processcreat.php');
        if($is_admin==0){
            
            $axoDetailArray=getAxoListInfo('admin',$groupId,$sp,$projectvalue,$devicevalue);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoListInfo('user',$groupId,$sp,$projectvalue,$devicevalue);
            // echo json_encode($axoDetailArray);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        
        if(empty($axoDetailArray)){
            echo json_encode(array('status'=>1002));
        }else{
            // $deviceArray=getSingleElementArray($axoDetailArray,'device');
            // $projectArray=getSingleElementArray($axoDetailArray,'project');
            $axoValueArray=getSingleElementArray($axoDetailArray,'value');

            if(!empty($axoValueArray)){
                $otainfos=getOtaByAxoValues($axoValueArray);
            }
            echo json_encode($otainfos);
        }
    }
    
    public function getOtaListOfAxo() {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        $is_admin=isAdmin($groupId,$sp);
        if($is_admin==0){
            
            $axoDetailArray=getAxoListInfo('admin',$groupId,$sp,NULL,NULL);
            
        }elseif ($is_admin==1) {
            $axoDetailArray=getAxoListInfo('user',$groupId,$sp,NULL,NULL);
            // echo json_encode($axoDetailArray);
        }else{
            echo json_encode(array('status'=>9999));
            return;
        }
        echo json_encode($axoDetailArray);
    }
    
    public function editOta($Packges, $status, $code) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/util/axo_util.php');
        $names = $Packges;
        
        if($status == -1 || $status == 1){
            $str="set ispush=0";
            $strsql="update otainfo $str
		WHERE uuid = '$names'";
            $sql = $strsql;
            $result=mysql_query($strsql);
            $totals = mysql_affected_rows();//总记录数
            if($totals > 0){
                $arr['affected'] = '0';
            }else{
                $arr['affected'] = '-1';
            }

        }elseif ($status == 0 || $status == 2) {
            $strsql_push="select * from otainfo where fromVersioncode='$code' and ispush=-1";
            $countpush=mysql_num_rows(mysql_query($strsql_push));

            $strsql_push="select * from otainfo where fromVersioncode='$code' and ispush=1";
            $countprocess=mysql_num_rows(mysql_query($strsql_push));
            if($countpush >0 || $countprocess >0){
                $arr['affected'] = '-2';
            }else{ 
                $str="set ispush=1";
                
                $strsql="update otainfo $str
			WHERE uuid = '$names'";
                $sql = $strsql;
                $result=mysql_query($strsql);
                $totals = mysql_affected_rows();//总记录数
                if($totals > 0){
                    $arr['affected'] = '0';
                }else{
                    $arr['affected'] = '-1';
                }			
            }
        }
        echo json_encode($arr);
    }
    
    public function delOta($uuid) {
        include_once(ROOT . '/controller/conn.php');

        if(empty($uuid)){
            echo json_encode(array('status'=>9999));

        }else{
            $sql_update="update otainfo set useFlag=1 where uuid='$uuid'";
            mysql_query($sql_update);
            echo json_encode(array('status'=>1000));
        }
    }

    public function getRom($projectname, $devicemodel) {
        include_once(ROOT . '/controller/conn.php');
        $sp = $_SESSION['solutionProvider'];
        $groupId=$_SESSION['groupId'];
        
        if(empty($devicemodel)|| empty($projectname)){
            echo json_encode(array('status'=>2001));
            return;
        }
        
        $strsql="SELECT rf.axo_value as al,device,versionCode,rompackgesname,md5value FROM  rominfo rf  left join long_custom_axo_details ld on rf.axo_value=ld.axo_value
					WHERE delflag=1 and solution_provider='$sp' and device='$devicemodel' and project='$projectname' ORDER BY uploadtime DESC ";
        $sql= $strsql;
        $result = mysql_query($strsql);
        $romlist=array();
        $romlist['status']=1000;
        while($row=mysql_fetch_array($result)){
            $romlist['list'][] = array(
            'versionCode' => $row['versionCode'],
                'axo_value' => $row['al'],//yvan add 2013-05-18
                'md5' =>$row['md5value'],
            'rompackgesname' => $row['rompackgesname']
            );
        }
        
        echo json_encode($romlist);
    }
    
    public function createOta($postonename, $posttargetname, $postonenamever, 
        $posttargetnamever, $axo_value, $description) {
        include_once(ROOT . '/controller/conn.php');
        include_once(ROOT . '/controller/include/config.cache.inc.php');

        $basename = $postonename;
        $targetname=$posttargetname;
        $fromVersioncode=$postonenamever;
        $toVersionCode=$posttargetnamever;
        $uploadtime=date("Y-m-d h:i:s");
        $timestamp=time();
        $str="select `device`,`solution_provider` from long_custom_axo_details where axo_value='$axo_value'";
        $result=mysql_query($str);
        $row=mysql_fetch_array($result);
        $vendor=$row['solution_provider'];
        $device=$row['device'];
        if($fromVersioncode == $toVersionCode){
            echo "<script>alert('error-code 113');</script><script>history.go(-1)</script>";
        }else{
            $creat='export CURR='.$otaPath.' && export FING='.$timestamp.' && export VENDOR='.$vendor.' && export DEVICE='.$dervice.' && export VERSIONSOURCE='.$versionsouce.' && $CURR/createota  '.$rom_path.$basename.' '.$rom_path.$targetname;
            //echo $creat."<br>";
            exec($creat." > /dev/null &");
            //pclose(popen($creat,'r'));
            $strsql="insert into otainfo (axo_value,fromVersioncode,toVersionCode,versionMark,uploadtime,creatstatus,uuid) values ('$axo_value','$fromVersioncode','$toVersionCode','$description','$uploadtime',-1,'$timestamp')";
            $result=mysql_query($strsql) or die("insert otainfo failed:".mysql_error());
            if($result){
                $this->redirect("Fota/ota_manager");
            }
        }
    }
}

function getRomByAxoValues($axoValues){
    $axo_values_sql = '"'.implode('","', $axoValues).'"';
    
    $sql_select_rom="select romurl,md5value,rompackgesname,versionRemark,device, project, versionCode, uploadtime,ri.axo_value
	FROM  rominfo ri inner join long_custom_axo_details lcad on ri.axo_value=lcad.axo_value where delflag=1 and ri.axo_value in (". $axo_values_sql . ')';
    
    
    $result=mysql_query($sql_select_rom);
    if(mysql_num_rows($result)>0){
        $roms['status']=1000;
        while($row=mysql_fetch_array($result)){
            $versionCode=$row['versionCode'];
            $axoValue=$row['axo_value'];
            $sql_select_ota_by_rominfo="select filename from otainfo where axo_value='$axoValue' and (fromVersionCode='$versionCode' or toVersionCode='$versionCode') ";
            // echo $sql_select_ota_by_rominfo;
            $ota_result=mysql_query($sql_select_ota_by_rominfo);
            $otaArray=array();
            if(mysql_num_rows($ota_result)>0){
                while ($ota=mysql_fetch_array($ota_result)) {
                    $otaArray[]=$ota['filename'];
                }
            }
            
            $roms['list'][] =array(
                'axo_value' => $axoValue,
                'fileSize' => filesize($row['romurl']),
                'rompackgesname' => $row['rompackgesname'],
                'md5value' => $row['md5value'],
                'versionRemark' => $row['versionRemark'],
                'devicemodel' => $row['device'],
                'projectname' => $row['project'],
                'versionCode' => $versionCode,
                'uploadtime' => $row['uploadtime'],
                'otaInfo' => $otaArray
                );
        }
    }else{
        $roms['status']=1002;
    }

    
    return $roms;
}

function getShowInfoByAxoValues($axoValueArray,$type,$name){
    $axo_values_sql = '"'.implode('","', $axoValueArray).'"';
    $sql_device_count="select count(id) count from UserInfo where axo_value in (". $axo_values_sql . ')' ;
    $sql_select_count_by_project="select count(id) count ,ui.axo_value,lcad.project from UserInfo ui inner join long_custom_axo_details 
								lcad on ui.axo_value=lcad.axo_value where ui.axo_value in(". $axo_values_sql . ') group by ui.axo_value';
    
    $result_count=mysql_query($sql_device_count);
    $row_count=mysql_fetch_array($result_count);
    if($row_count['count']>0){
        $arr['status']=1000;
        $count=$row_count['count'];
        $arr['count']=$count;

        $result_count_by_category=mysql_query($sql_select_count_by_project);
        $num=mysql_num_rows($result_count_by_category);
        if($num>0){
            while($row=mysql_fetch_array($result_count_by_category)){
                $arr['axo_project'][$row['project']]=$row['axo_value'];
                
                $arr_unit['data'][]=array(
                        'name'=>$row['project'],
                        'y'=>round($row['count']/$count*100, 1)
                    );
            }
            $arr_unit['type']=$type;
            $arr_unit['name']=$name;
            $arr['bean']=$arr_unit;
        }else{
            $arr['status']=2001;
        }
        
    }else{
        $arr['status']=2001;
    }

    return $arr;
}

function getShowInfoByAxo($axo_value,$type,$name){
    
    $sql_device_count="select count(id) count from UserInfo where axo_value ='$axo_value'" ;
    $sql_select_count_by_project="select count(cuvi.id) count,currentVersion from currentUserVerInfo cuvi inner join UserInfo ui on 
									cuvi.userId=ui.userId where cuvi.useFlag=1 and ui.axo_value='$axo_value' group by currentVersion";
    
    $result_count=mysql_query($sql_device_count);
    $row_count=mysql_fetch_array($result_count);
    if($row_count['count']>0){
        $arr['status']=1000;
        $count=$row_count['count'];
        $arr['count']=$count;

        $result_count_by_category=mysql_query($sql_select_count_by_project);
        $num=mysql_num_rows($result_count_by_category);
        if($num>0){
            
            while($row=mysql_fetch_array($result_count_by_category)){
                
                $arr_unit['data'][]=array(
                        'name'=>$row['currentVersion'],
                        'y'=>round($row['count']/$count*100,1)
                    );
            }
            $arr_unit['type']=$type;
            $arr_unit['name']=$name;
            $arr['bean']=$arr_unit;
        }else{
            $arr['status']=2001;
        }
        
    }else{
        $arr['status']=2001;
    }

    return $arr;
}

function getAxoListInfo($type,$groupId,$sp,$project,$device){
    switch ($type) {
        case 'admin':
            $axoDetailArray=getAxoDetailsArrayBySp($sp,$device,$project);
            break;
        case 'user':
            $axoDetailArray=getAxoDetailsArray($groupId,$device,$project);
            break;
        
        default:
            # code...
            break;
    }

    return $axoDetailArray;
}

function getOtaByAxoValues($axoValues){

    
    $axo_values_sql = '"'.implode('","', $axoValues).'"';
    
    $sql_select_ota="select oif.axo_value,uuid,md5value,filename,versionMark,device,errormessage,project,fromVersioncode, toVersionCode, uploadtime, downloadurl, md5value, ispush,creatstatus
	FROM  otainfo oif inner join long_custom_axo_details lcad on oif.axo_value=lcad.axo_value where  useFlag=0 and oif.axo_value in (". $axo_values_sql . ')';
    
    
    $result=mysql_query($sql_select_ota);
    if(mysql_num_rows($result)>0){
        $otas['status']=1000;
        while($row=mysql_fetch_array($result)){
            $f=$row['fromVersioncode'];
            $t=$row['toVersionCode'];
            $axoValue=$row['axo_value'];
            $uuid=$row['uuid'];
            $versionCode=$f."-".$t;

            $sql_select_count="select count(id) count from UserInfo where axo_value ='$axoValue' and sysVersionCode='$t' ";
            $sql_select_ota_count="select count(id) count from (select ui.axo_value,oui.currentVersion,oui.preVersion from otaUpgradeInfo oui inner join 
										UserInfo ui on oui.userId=ui.userId) ota_user  inner join otainfo on ota_user.axo_value=otainfo.axo_value and 
										ota_user.currentVersion=otainfo.fromVersioncode and ota_user.preVersion=otainfo.toVersionCode 
										where otainfo.creatstatus!=2 and uuid='$uuid'";
            $sql_select_ota_success_count="select count(id) count from (select ui.axo_value,oui.currentVersion,oui.preVersion,oui.useFlag from otaUpgradeInfo oui 
												inner join UserInfo ui on oui.userId=ui.userId) ota_user  inner join otainfo on ota_user.axo_value=otainfo.axo_value 
												and ota_user.currentVersion=otainfo.fromVersioncode and ota_user.preVersion=otainfo.toVersionCode 
												where otainfo.creatstatus!=2 and ota_user.useFlag=1 and uuid='$uuid'";

            $result_count=mysql_query($sql_select_count);
            $otaArray=array();
            if(mysql_num_rows($result_count)>0){
                $countRow=mysql_fetch_array($result_count);
                $count=$countRow['count'];
                if($count>0){
                    $result_ota_count=mysql_query($sql_select_ota_count);
                    $countotaRow=mysql_fetch_array($result_ota_count);
                    $countOta=$countotaRow['count'];

                    $result_ota_success=mysql_query($sql_select_ota_success_count);
                    $rowotasuccessRow=mysql_fetch_array($result_ota_success);
                    $countOtaSuccess=$rowotasuccessRow['count'];

                    $otaArray['upgradeRate']=round($countOta/$count*100,2);
                    $otaArray['upgradeSuccessRate']=round($countOtaSuccess/$countOta*100,2);
                    $otaArray['upgradeSuccessCount']=$countOtaSuccess;
                }else{
                    $otaArray['upgradeRate']=0;
                    $otaArray['upgradeSuccessRate']=0;
                    $otaArray['upgradeSuccessCount']=0;
                }
            }

            $otas['list'][]=array(
                
                'filename' => $row['filename'],
                'uuid' => $uuid,
                'code' => $f,
                'md5value' => $row['md5value'],
                'versionMark' => $row['versionMark'],
                'errormessage' => $row['errormessage'],
                'devicemodel' => $row['device'],
                'projectname' => $row['project'],
                'versionCode' => $versionCode,
                'uploadtime' => $row['uploadtime'],
                'downloadurl' => $row['downloadurl'],
                'md5value' => $row['md5value'],
               
                'create' => $row['creatstatus'],
                
                'ispush' => $row['ispush'],
                'otaUpgradeInfo' => $otaArray
            );
        }
    }else{
        $otas['status']=1002;
    }
    
    return $otas;
}
