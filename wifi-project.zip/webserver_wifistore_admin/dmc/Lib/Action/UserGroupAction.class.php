<?php

/**
 * AuthMgrAction short summary.
 *
 * AuthMgrAction description.
 *
 * @version 1.0
 * @author Hank
 */
class UserGroupAction extends AuthAction
{
    public function userGroup_manager($action="list", $groupId=null) {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"权限管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"",
                "desc"=>"用户组管理"
            )
        );
        if ($action == "list") {
            $this->solutionProvider = $_SESSION['solutionProvider'];
            $this->display();
        } else if ($action == "add") {
            $this->title="添加新用户组";
            $this->display("UserGroup/userGroup_edit");
        } else if ($action == "edit") {
            $this->action = "edit";
            $this->groupId = $groupId;
            $this->title="修改用户组";
            $this->display("UserGroup/userGroup_edit");
        } else if ($action == "auth") {
            $this->groupId = $groupId;
            $this->display("UserGroup/userGroup_auth");
        }
    }
    
    public function getUserGroup($type, $functions=null) {
        include_once(ROOT . '/controller/conn.php');
        require_once(ROOT . "/controller/gacl/admin/gacl_admin.inc.php");
        include_once(ROOT . '/controller/util/formatString.php');

        $solution_provider=$_SESSION['solutionProvider'];
        $group_parent_name=$solution_provider.'_user';
        $sql_search_group_id="select id from long_aro_groups where name='$group_parent_name'";
        
        $result=mysql_query($sql_search_group_id);
        
        if(mysql_num_rows($result)>0){
            $rows=mysql_fetch_array($result);
            $group_parent_id=$rows['id'];
        }else{
            return false;
        }

        if(strcasecmp($functions,'add')==0||strcasecmp($functions,'edit')==0){
            $groupData=$gacl_api->get_group_data($group_parent_id,"ARO");
            if(count($groupData)>0){
                $objects=getObjectRow($group_parent_id);

                
                $arr['groups'][0] = array(
                     'groupId'  => $groupData[0],
                     'groupParentId'=>$groupData[1],
                     'groupParentName'=>getGroupNameById($groupData[1]),
                     'groupValue' => $groupData[2],
                    'groupName' => $groupData[3],
                    'objectsNum'=> $objects
                    );
            }
        }

        switch ($type) {
            case 'all':
                $group_children_ids=$gacl_api->get_group_children($group_parent_id, 'ARO', 'RECURSE');
                break;
            case 'one':
                
                $group_children_ids=$gacl_api->get_group_children($group_parent_id, 'ARO', 'NO_RECURSE');
                break;
            
            default:
                # code...
                break;
        }

        for($i = 0;$i<count($group_children_ids);$i++){
            $children_id=$group_children_ids[$i];
            $groupData=$gacl_api->get_group_data($children_id,"ARO");

            $objects=getObjectRow($children_id,$solution_provider);
            // if($objects == 0){ 						
            // $sql_search_group_id="select count(*) count from spUser where groupId=$children_id"; 						
            // $result=mysql_query($sql_get_count_by_group_id); 						
            // 	if(mysql_num_rows($result)>0){ 							
            // 	$rows=mysql_fetch_array($result); 							
            // 	$objects=$rows['count']; 						
            // 	} 					
            // }
            if (strcasecmp($functions,'edit')==0) {
                $group_id=$_POST['groupId'];
                if($group_id==$groupData[0]){
                    continue;
                }
            }
            
            $arr['groups'][$i+1] = array(
                 'groupId'  => $groupData[0],
                 'groupParentId'=>$groupData[1],
                 'groupParentName'=>getGroupNameById($groupData[1]),
                 'groupValue' => $groupData[2],
                'groupName' => $groupData[3],
                'objectsNum'=>$objects
                );
        }
        
        echo json_encode($arr);
    }
    
    public function getSingleGroup($groupId) {
        include_once(ROOT . '/controller/conn.php');
        
        $group_id = $groupId;
        if(empty($group_id)){
            echo json_encode(array('status'  => 9999));
            return;
        }
        $sql_select_groupinfo="select parent_id,name from long_aro_groups where id=$group_id";
        $result=mysql_query($sql_select_groupinfo);
        if(count($result)>0){
            $rows=mysql_fetch_array($result);
            echo json_encode(array(
                'status'  => 1000,
                'parent_id' => $rows['parent_id'],
                'name' => $rows['name']
                ));
        }else{
            echo json_encode(array('status'  => 1002));
        }

    }

    public function delGroup($groupId) {
        include_once(ROOT . '/controller/conn.php');
        require_once(ROOT . "/controller/gacl/admin/gacl_admin.inc.php");
        
        if(empty($groupId)){
            echo json_encode(array('status'  => 9999));
            return;
        }
        
        $sql_query_user="select count(*) count from spUser where groupId='$groupId'";
        $result=mysql_query($sql_query_user);
        $rows=mysql_fetch_array($result);
        $count=$rows['count'];
        $group_children_ids=$gacl_api->get_group_children($groupId, 'ARO', 'NO_RECURSE');
        //$count=mysql_num_rows($result);
        if($count > 0||count($group_children_ids)>0){
            $arr['status'] = 1001;
            echo json_encode($arr);
        }else{
            $result=$gacl_api->del_group($groupId, FALSE, 'ARO');
            if($result){
                echo json_encode(array('status'  => 1000));
            }else{
                echo json_encode(array('status'  => 9999));
            }
            
        }
        
    }

    public function addGroup($group_parent_id, $group_name) {
        include_once(ROOT . '/controller/conn.php');
        require_once(ROOT . "/controller/gacl/admin/gacl_admin.inc.php");
        include_once(ROOT . '/controller/util/formatString.php');

        if(empty($group_name) || empty($group_parent_id)){
            echo json_encode(array('status'  => 2001));
            return;
        }
        if(!strJudgement($group_name)){
            echo json_encode(array('status'  => 2002));
            return;
        }
        // $group_name=$_SESSION['solutionProvider'].'_'.$group_name;
        $sql_select_group="select name from long_aro_groups where name='$group_name'";
        $result=mysql_query($sql_select_group);
        $num=mysql_num_rows($result);
        if($num>1){
            echo  json_encode(array('status'  => 9999));
            return;
        }elseif ($num==1) {
            echo  json_encode(array('status'  => 2003));
            return;
        }else{
            $status = internal_addGroup($gacl_api,$group_name,$group_parent_id);
            
            switch ($status) {
                case 'have':
                    echo  json_encode(array('status'  => 2003));
                    break;
                case 'false':
                    echo  json_encode(array('status'  => 9999));
                    break;
                
                default:
                    echo  json_encode(array('status'  => 1000));
                    # code...
                    break;
            }
        }
    }
    
    public function updateGroup($name, $group_id) {
        include_once(ROOT . '/controller/conn.php');
        require_once(ROOT . "/controller/gacl/admin/gacl_admin.inc.php");
        include_once(ROOT . '/controller/util/formatString.php');
        if(empty($group_id)){
            echo  json_encode(array('status'  => 9999));
            return;
        }
        if(empty($name)){
            echo json_encode(array('status' => 2001));
            return;
        }elseif (!strJudgement($name)) {
            echo json_encode(array('status' => 2002));
            return;
        }
        $sql_select_group="select name from long_aro_groups where name='$name'";
        $result=mysql_query($sql_select_group);
        $num=mysql_num_rows($result);
        if($num>1){
            echo  json_encode(array('status'  => 9999));
        }elseif ($num==1) {
            echo  json_encode(array('status'  => 2003));
        }else{
            $status=$gacl_api->edit_group($group_id, NULL, $name, NULL, $group_type='ARO');
            if($status){
                echo  json_encode(array('status'  => 1000));
            }else{
                echo  json_encode(array('status'  => 1001));
            }
        }
    }

    public function getPermission($group_id) {
        include_once(ROOT . '/controller/conn.php');
        require_once(ROOT . "/controller/gacl/admin/gacl_admin.inc.php");
        include_once(ROOT . '/controller/util/formatString.php');
        include_once(ROOT . '/dmc/Lib/Action/UserGroup/aco_edit.php');
        
        $solutionProvider=$_SESSION['solutionProvider'];
        $group_parent_id=$gacl_api->get_group_parent_id($group_id,'ARO');
        $group_parent_data=$gacl_api->get_group_data($group_parent_id,'ARO');
        if(empty($group_parent_data)){
            return false;
        }else{
            $inherit_group=array('name'=>$group_parent_data[3],'group_id'=>$group_parent_data[0]);
        }
        if(strcasecmp($group_parent_data[3], $solutionProvider.'_admin')==0){
            $group_admin_name=$solutionProvider.'_admin';
        }else{
            $group_admin_name=$solutionProvider.'_user';
        }
        
        $group_admin_id=getGroupId($group_admin_name);
        //logFile('error_log',$group_admin_id);

        $ownlist=getAcoList($group_id,null);
        $inheritlist=getAcoList($group_parent_id,null);
        $availablelist=getAcoList($group_admin_id,getFilterAcoIds($group_id));

        $responseArray['inheritgroup']=$inherit_group;
        $responseArray['inheritlist']=$inheritlist;
        $responseArray['ownlist']=$ownlist;
        $responseArray['availablelist']=$availablelist;

        echo json_encode($responseArray);
    }
    
    public function updatePermission($group_id, $groups) {
        include_once(ROOT . '/controller/conn.php');
        
        $aco_update_list=$groups;

        if(empty($aco_update_list) || count($aco_update_list)<1){
            echo json_encode(array('status'  => 9999));	
        }else{
            
            for ($i=0;$i<count($aco_update_list);$i++) {
                $group=$aco_update_list[$i];

                $aco_value=$group['value'];
                $allow=$group['allow'];
                // logFile(error.log, $aco_value);
                
                $sql_search_aco_list="select long_aco.id aco_id ,long_acl.id acl_id ,long_acl.allow from long_aco_map  
						inner join long_aro_groups_map on 
						long_aro_groups_map.acl_id=long_aco_map.acl_id inner join long_aco  
						on long_aco_map.value= long_aco.value and 
						long_aco_map.section_value=long_aco.section_value 
						inner join long_acl on long_aco_map.acl_id=long_acl.id 
						where group_id=$group_id and long_aco.value='$aco_value'";
                
                $result=mysql_query($sql_search_aco_list);
                $count=mysql_num_rows($result);
                
                if($count==1){
                    
                    $rows=mysql_fetch_array($result);
                    $mAllow=$rows['allow'];
                    //logFile(error.log, $mAllow.'&&'.$allow);
                    if($allow==$mAllow){
                        
                        $status=true;
                        continue;
                    }else{
                        
                        $status=updateAclByGroupIdAndAcoValue($group_id,$aco_value,$rows['aco_id'],$rows['acl_id'],$allow);
                    }
                }else if($count==0){
                    $status=addAclByGroupIdAndAcoValue($group_id,$aco_value,$allow);	
                }else{
                    $status = false;
                }
                if(!$status)break;
            }

            if($status){
                echo json_encode(array('status'  => 1000));			
            }else{
                echo json_encode(array('status'  => 9999));		
            }

        }
    }
}


function getObjectRow($group_id,$solution_provider){
    $sql_get_count_by_group_id = "select count(*) count from spUser where groupId=$group_id and solutionProvider='$solution_provider'";
    // logFile(error_log,$sql_get_count_by_group_id);
    $result=mysql_query($sql_get_count_by_group_id);
    if(mysql_num_rows($result)>0){
        $rows=mysql_fetch_array($result);
        return $rows['count'];
    }else{
        return 0;
    }
}

function getGroupNameById($group_id){
    $sql_select_groupName="select name from long_aro_groups where id=$group_id";
    $result=mysql_query($sql_select_groupName);
    if(mysql_num_rows($result)>0){
        $rows=mysql_fetch_array($result);;
        return $rows['name'];
    }else{
        return 'default';
    }
}

function internal_addGroup($gacl_api,$group_name,$group_parent_id){

    $sql_search_group_name="select id from long_aro_groups where name='$group_name'";
    $result=mysql_query($sql_search_group_name);
    $count=mysql_num_rows($result);
    // echo $count;
    // $count=mysql_num_fields();
    if($count>0){
        return 'have';
    }else{
        $value=create_guid();

        $result=$gacl_api->add_group($value, $group_name, $group_parent_id, 'ARO');
        
        return $result;
    }
}

function create_guid(){
    $charid=strtoupper(md5(uniqid(mt_rand(),true)));
    $hyphen = chr(45);
    $uuid = chr(123).substr($charid, 0,8).$hyphen.substr($charid, 8, 4).$hyphen
            .substr($charid, 12, 4).$hyphen.substr($charid, 16, 4).$hyphen
            .substr($charid, 20, 12).chr(125);
    return $uuid;
}

function getGroupId($group_name){
    $sql_get_group_name="select id from long_aro_groups where name='$group_name'";
    $result=mysql_query($sql_get_group_name);
    if(mysql_num_rows($result)>0){
        $rows=mysql_fetch_array($result);
        return $rows['id'];
    }else{
        return null;
    }
}

function updateAclByGroupIdAndAcoValue($group_id,$aco_value,$aco_id,$acl_id,$allow){

    $sql_select_acoNum_by_aclId='select count(acl_id) acoSum from long_aco_map where acl_id='.$acl_id;
    
    $result=mysql_query($sql_select_acoNum_by_aclId);
    if(mysql_num_rows($result)>0){
        $rows=mysql_fetch_array($result);
        $aco_sum=$rows['acoSum'];
        
        if($aco_sum==1){
            $sql_update_acl='update long_acl set allow='.$allow .' where id='.$acl_id;
            //logFile(error.log, $sql_update_acl);
            mysql_query($sql_update_acl);
            return true;
        }else if($aco_sum>1){
            $new_acl_id=getAclId();
            $sql_insert_acl="insert into long_acl(id,section_value,allow,enabled,updated_date) values(".$acl_id.",'".$section_value."',".$allow.',1,'.time().')';
            $sql_update_aco_map="update  long_aco_map set acl_id=".$new_acl_id." where value='".$aco_value."'";
            //logFile(error.log, 'sql_update_aco_map'.$sql_update_aco_map);
            $sql_insert_aro_group_map='insert into long_aro_groups_map(acl_id,group_id) values('.$acl_id.','.$group_id.')';

            mysql_query('BEGIN');

            mysql_query($sql_insert_acl);
            mysql_query($sql_update_aco_map);
            mysql_query($sql_insert_aro_group_map);
            if(mysql_errno()){
                //add   failed;
                mysql_query('ROLLBACK');
                return false;

            }else{
                //add  success
                mysql_query('COMMIT');
                return true;
            }
        }else{
            return false;
        }
        
    }
}

function getAclId(){
    $sql_select_acl_id='select id from long_acl_seq order by id desc limit 1';
    $result=mysql_query($sql_select_acl_id);
    while ($rows=mysql_fetch_array($result)) {
        $id=$rows['id']+1;
        $sql_insert_acl_seq='update long_acl_seq set id='.$id;
        //logFile(error.log, $sql_insert_acl_seq);
        mysql_query($sql_insert_acl_seq);
        return $id;
    }
    return 10;
}

function addAclByGroupIdAndAcoValue($group_id,$aco_value,$allow){

    
    $aco_section_value=getSectionValue($aco_value);
    
    if(empty($aco_section_value)){
        return false;
    }

    $acl_id=getAclId();
    //logFile(error.log, 'acl_id'.$acl_id);
    $section_value='user';
    $sql_insert_acl="insert into long_acl(id,section_value,allow,enabled,updated_date) values(".$acl_id.",'".$section_value."',".$allow.',1,'.time().')';
    //logFile(error.log, 'sql_insert_acl'.$sql_insert_acl);
    $sql_insert_aco_map="insert into long_aco_map(acl_id,section_value,value) values (".$acl_id.",'".$aco_section_value."','".$aco_value."')";
    //logFile(error.log, 'sql_insert_aco_map'.$sql_insert_aco_map);
    $sql_insert_aro_group_map='insert into long_aro_groups_map(acl_id,group_id) values('.$acl_id.','.$group_id.')';
    //logFile(error.log, 'sql_insert_aro_group_map'.$sql_insert_aro_group_map);

    mysql_query('BEGIN');

    mysql_query($sql_insert_acl);
    mysql_query($sql_insert_aco_map);
    mysql_query($sql_insert_aro_group_map);
    if(mysql_errno()){
        //add   failed;
        mysql_query('ROLLBACK');
        return false;

    }else{
        //add  success
        mysql_query('COMMIT');
        return true;
    }

}

function getSectionValue($aco_value){
    $sql_select_aco_section_value="select section_value from long_aco where value='$aco_value'";
    $result=mysql_query($sql_select_aco_section_value);
    while ($rows=mysql_fetch_array($result)) {
        return $rows['section_value'];
    }
    return null;
}
