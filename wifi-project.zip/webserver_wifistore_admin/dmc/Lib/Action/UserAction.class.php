<?php

/**
 * UserAction short summary.
 *
 * UserAction description.
 *
 * @version 1.0
 * @author Hank
 */
class UserAction extends AuthAction{

    public function registerAccount($apId,$account,$password){
        include_once(ROOT . '/controller/conn.php');
    }

//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
//
    private function register($apId,$userName,$password){

        $query="select * from user_yinni where userName='$userName'";

        try {
            $result=mysql_query($query);
            if(mysql_num_rows($result)>0){
                $response['status']=1002;
            }else{
                $userId=$this->create_uuid();
                $insert=printf("insert into user_yinni (userId,userName,pwd,apId) values(%s,%s,%s,%s)",$userId,$userName,$password,$apId);
                mysql_query($insert);
                $response['status']=1000;
            }
        } catch (Exception $e) {

            $response['status']=1001;

        }
        return $response;
    }

    private function create_uuid($prefix = ""){    //可以指定前缀

        $str = md5(uniqid(mt_rand(), true));

        $uuid  = substr($str,0,8) . '-';

        $uuid .= substr($str,8,4) . '-';

        $uuid .= substr($str,12,4) . '-';

        $uuid .= substr($str,16,4) . '-';

        $uuid .= substr($str,20,12);

        return $prefix . $uuid;

    }
}
?>
