#!/bin/bash
args=$#
last=${!args}
echo $@ > /tmp/2.txt
php $@ &
# php "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "${10}" > /tmp/t &
ps -ef | grep $last | grep -v grep | awk '{print $2}'
