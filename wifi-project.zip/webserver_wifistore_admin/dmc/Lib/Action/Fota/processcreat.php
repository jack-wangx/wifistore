<?php
	include_once(ROOT . '/controller/include/config.cache.inc.php');
	$countsql="select * from otainfo where creatstatus = -1";
	$result=mysql_query($countsql);
	$count= mysql_num_rows($result);
	$m=fopen("/home/www/html/sysv2/script/ota/.running","w");
	fwrite($m,$count);
	fclose($m);
	
	$strsql="SELECT uuid
	FROM  otainfo of 
	left join long_custom_axo_details ld on of.axo_value=ld.axo_value
	WHERE solution_provider='$sp' 
	ORDER BY uploadtime DESC ";
	$sql= $strsql;
	$query = mysql_query($strsql);
	$totals = mysql_num_rows($query);//总记录数
	if($totals == 0){
		
	}else{
		while($row=mysql_fetch_array($query)){
			$unidvalue=$row['uuid'];
			$uuidvalue=$unidvalue;
			//通过系统路径取得当前的OTA的目录下所有文件
			$dir = $file_path."/ota/";  // 文件夹的名称
			
			$dirname="-".$unidvalue;
			
			if (is_dir($dir)){
			    if ($dh = opendir($dir)){
			        while (($file = readdir($dh)) !== false){
			            $otaarr[]=$file;
			        }

			        closedir($dh);
			    }
			    //print_r($arr);echo $dirname;
			    //再找到文件夹名称
			    foreach($otaarr as $key=>$value)
				{
					  $pos =strstr($value, $dirname);
					  if($pos){
						   $filename=$value;
					  }
				 }

				 //通过查找找到OTA的MD5文件
				 $otaflodername=$filename;
				 $dir = $file_path."/ota/$filename";
				 
				 if (is_dir($dir)){
				    if ($dh = opendir($dir)){
				        while (($file = readdir($dh)) !== false){
				           
				            $otaarr[]=$file;
				            //print_r($otaarr);
				        }

				        closedir($dh);
				    }
				    $dirname=".md5";
				    foreach($otaarr as $key=>$value){
						  $pos =strstr($value, $dirname);
						  if($pos){
							   $filename=$value;
							  
						  }
					}
				}
				//获取生成返回信息
				$returnvalue=$dir."/return";
				//echo $returnvalue;
				$returnvalue=file_get_contents($returnvalue);
				$result=explode("\n",$returnvalue);

				//解析文件内容获取OTA下载地址
				$otapath=$dir."/".$filename;//echo $otapath;
				$swap=explode("/sysv2/",$otapath);
				$swapot=$swap[1];
				$swapot=explode(".md5",$swapot);

				//获取OTA下载地址
				$downloadurl=$cfg_basehost."/".$swapot[0];

				$original=$basepath."/".$swapot[0];
				$filesize=sizecount(filesize($original));
				
				$swapfilename=explode($otaflodername."/",$swapot[0]);
				$filename=$swapfilename[1];
				
				//获取MD5值存入数据库
				$md5value=trim(str_replace(array("\r\n", "\r", "\n"),"",file_get_contents($otapath)));
				$uploadtime=date("Y-m-d h:m:s");
				
				$uuid=$md5value.$uuidvalue;
				if($result[0] == "success"){
					$creatstatus="0";
					$message=$result[1];
					$code=explode(":",$message);

				}elseif ($result[0] == "wsuccess") {
					$creatstatus="1";
					$message=$result[1];
					$code=explode(":",$message);
				}elseif ($result[0] == "failure") {
					$creatstatus="2";
					$message=$result[1];
					$code=explode(":",$message);
				}
				
				$sql="UPDATE  otainfo SET md5value='$md5value',downloadurl='$downloadurl',filename='$filename',errormessage='$code[0]',creatstatus=$creatstatus,errormessage='$message',uuid='$uuid',filesize='$filesize' where uuid='$uuidvalue' and creatstatus = -1";
				//echo $sql;				
				mysql_query($sql);

			}
		}
	}
function changeFileSize($filesize) 
{ 
    if($filesize >= 1073741824) 
    { 
        $filesize = round($filesize / 1073741824  ,2) . ' GiB'; 
    } elseif($filesize >= 1048576) 
    { 
        $filesize = round($filesize / 1048576 ,2) . ' MiB'; 
    } elseif($filesize >= 1024) 
    { 
        $filesize = round($filesize / 1024, 2) . ' KiB'; 
    } else 
    { 
        $filesize = $filesize . ' Bytes'; 
    } 
    return $filesize; 
}
?>
