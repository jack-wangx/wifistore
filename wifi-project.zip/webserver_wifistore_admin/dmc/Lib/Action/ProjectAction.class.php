<?php

/**
 * ProjectAction short summary.
 *
 * ProjectAction description.
 *
 * @version 1.0
 * @author Hank
 */
class ProjectAction extends AuthAction
{
    public function project_mgr($action="list", $projectValue=null) {
        $this->breadcrumb = array(
            array(
                "href"=>U("Index/index"),
                "title"=>"",
                "icon"=>"icon-home",
                "desc"=>"Home"
            ),
            array(
                "href"=>'#',
                "title"=>"",
                "icon"=>"icon-mobile-phone",
                "desc"=>"权限管理"
            ),
            array(
                "href"=>"#",
                "title"=>"",
                "icon"=>"",
                "desc"=>"项目分配"
            )
        );
        
        if ($action == "list") {
            $this->display();
        } else if ($action == "add") {
            $this->action = $action;
            $this->title = "添加新项目";
            $this->display("Project/project_edit");
        } else if ($action == 'edit') {
            $this->action = $action;
            $this->title = "修改项目";
            $this->projectValue = $projectValue;
            $this->display("Project/project_edit");
        }
    }

    public function showProject($axo_value) {
        include_once(ROOT . '/controller/conn.php');
        
        if(empty($axo_value)){
            echo  json_encode(array('status'  => 9999));
            
        }else{
            $sql_query_axo_id="select id from long_axo where value='$axo_value'";
            $result=mysql_query($sql_query_axo_id);
            if(mysql_num_rows($result)==1){
                $sql_update_axo="update long_axo set hidden=0 where value='$axo_value'";
                mysql_query($sql_update_axo);
                if(mysql_errno()){
                    echo  json_encode(array('status'  => 9999));
                }else{
                    echo  json_encode(array('status'  => 1000));
                }
                
                
            }elseif(mysql_num_rows($result)>1){
                echo  json_encode(array('status'  => 9999));
            }else{
                echo  json_encode(array('status'  => 1002));
            }
        }
    }
    
    public function hideProject($axo_value) {
        include_once(ROOT . '/controller/conn.php');
        
        if(empty($axo_value)){
            echo  json_encode(array('status'  => 9999));
            
        }else{
            $sql_query_axo_id="select id from long_axo where value='$axo_value'";
            $result=mysql_query($sql_query_axo_id);
            if(mysql_num_rows($result)==1){
                $sql_update_axo="update long_axo set hidden=1 where value='$axo_value'";
                mysql_query($sql_update_axo);
                if(mysql_errno()){
                    echo  json_encode(array('status'  => 9999));
                }else{
                    echo  json_encode(array('status'  => 1000));
                }
                
                
            }elseif(mysql_num_rows($result)>1){
                echo  json_encode(array('status'  => 9999));
            }else{
                echo  json_encode(array('status'  => 1002));
            }
        }
    }
    
    public function getProjects($type=null, $axo_value=null) {
        include_once(ROOT . '/controller/conn.php');
        mysql_query("set character set default");
        $sp=$_SESSION["solutionProvider"];
        
        if(strcasecmp($type,'one')==0){
            $axo_value=$_POST['axo_value'];
            $sql_select_axo="SELECT id,axo_value,device,project,hidden FROM long_custom_axo_details a INNER JOIN long_axo b ON a.axo_value = b.value where solution_provider='$sp' and axo_value='$axo_value'";
        }else{
            $sql_select_axo="SELECT id,axo_value,device,project,hidden FROM long_custom_axo_details a INNER JOIN long_axo b ON a.axo_value = b.value where solution_provider='$sp'";
        }
        
        $result=mysql_query($sql_select_axo);
        $responseArray=array();
        
        $responseArray['flag']=mysql_num_rows($result);
        $n=0;
        while($rows=mysql_fetch_array($result)){
            $axo_id=$rows['id'];
            $device=$rows['device'];
            $project=$rows['project'];
            $aro_list['device']=$device;
            $aro_list['project']=$project;
            $aro_list['hidden']=$rows['hidden'];
            $aro_list['axo_value']=$rows['axo_value'];
            $sql_select_axo_aro_group="select name,aro_group_id from long_custom_aro_group_axo_map c inner join long_aro_groups d on c.aro_group_id=d.id where axo_id=$axo_id";
            //logFile('errorlog',$sql_select_axo_aro_group);
            $results=mysql_query($sql_select_axo_aro_group);
            $i=0;
            $aro_list['aro_group']=null;
            while($rows=mysql_fetch_array($results)){
                $aro_list['aro_group'][$i]=array('name'  => $rows['name'],
                                 'aro_group_id' => $rows['aro_group_id']
                                );
                $i++;
            }
            $responseArray['axo_details'][$n]= $aro_list;
            $n++;
        }
        echo json_encode($responseArray);
    }

    public function updateProject($axo_value, $groupList, $devicename, $projectname) {
        include_once(ROOT . '/controller/conn.php');

        $group_list = $groupList;
        if(empty($axo_value)){
            echo json_encode(array('status' => 9999));
        }
        if( empty($group_list)){
            echo  json_encode(array('status'  => 9999));
            return;
        }
        // $axo_value='qwertyui';
        // $group_list=array(28,31);
        $sql_query_axo_id="select id from long_axo where value='$axo_value'";
        $result=mysql_query($sql_query_axo_id);
        if(mysql_num_rows($result)==1){
            $rows=mysql_fetch_array($result);
            $axo_id=$rows['id'];
            $sql_delete_map="delete from long_custom_aro_group_axo_map where axo_id=$axo_id";
            mysql_query('BEGIN');
            
            mysql_query($sql_delete_map);
            if(mysql_errno()){

                //add new user failed;
                

                mysql_query('ROLLBACK');
                echo  json_encode(array('status'  => 9999));
                return;

            }else{
                
                mysql_query('COMMIT');
                while (list($keys,$value) = each($group_list)) {
                    
                    $aro_group_id = $value['id'];

                    $sql_insert_aro_group_axo_map="insert into long_custom_aro_group_axo_map(aro_group_id,axo_id) values ($aro_group_id,$axo_id)";
                    
                    mysql_query('BEGIN');

                    mysql_query($sql_insert_aro_group_axo_map);
                    
                    if(mysql_errno()){

                        //add new user failed;
                        
                        mysql_query('ROLLBACK');
                        echo  json_encode(array('status'  => 9999));
                        return;

                    }else{
                        mysql_query('COMMIT');
                    }
                }
                // $sql_update_axo_details="update long_custom_axo_details set device='$device', project='$project' where axo_value='$axo_value'";
                
                // mysql_query($sql_update_axo_details);
                echo  json_encode(array('status'  => 1000));
            }
        }else{
            echo  json_encode(array('status'  => 1002));
        }
    }
    
    public function addProject($groupList, $devicename, $projectname) {
        include_once(ROOT . '/controller/conn.php');
        require_once(ROOT . "/controller/gacl/admin/gacl_admin.inc.php");

        $device_model=$devicename;
        $project=$projectname;
        $group_list=$groupList;
        $axo_section_name=$_SESSION["solutionProvider"];
        //$axo_section_name="chengkai";
        
        if(empty($device_model)||empty($project)||empty($group_list)){
            echo  json_encode(array('status'  => 2001));
        }else{
            if(empty($axo_section_name)){
                echo json_encode(array('status'  => 9999));
                return;
            }
            if(projectJudgement($axo_section_name,$project)){
                echo json_encode(array('status'  => 2002));
                return;
            }

            $axo_name=$axo_section_name.'_'.$device_model.'_'.$project;

            $sql_seach_axo_by_name="select id from long_axo where name='$axo_name'";

            $result=mysql_query($sql_seach_axo_by_name);
            if(mysql_num_rows($result)==1){
                $arr['status'] = 2003;
                echo json_encode($arr);
                return;
                //$rows=mysql_fetch_array($result);
                //$axo_id=$rows['id'];
            }else if(mysql_num_rows($result)==0){
                $sql_select_axo_section_by_name="select value from long_axo_sections where name ='$axo_section_name'";
                $result=mysql_query($sql_select_axo_section_by_name);
                if(mysql_num_rows($result)==1){
                    $rows=mysql_fetch_array($result);
                    $axo_section_value=$rows['value'];
                }else if(mysql_num_rows($result)==0){
                    $axo_section_value=create_guid();
                    $status=$gacl_api->add_object_section($axo_section_name, $axo_section_value, 0, 0,'AXO');
                    if($status!=false){
                        $axo_section_id=$status;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
                $axo_value=create_guid();
                $status=$gacl_api->add_object($axo_section_value, $axo_name, $axo_value, 0, 0, 'AXO');
                $success=addAxoDetails($axo_section_name,$axo_value,$device_model,$project);
                if($status!=false && $success){
                    $axo_id=$status;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
            while (list($keys,$value) = each($group_list)) {
                
                $groupId = $value['id'];
                //list($group_name,$group_value)=$value;
                
                $sql_insert_aro_group_axo_map="insert into long_custom_aro_group_axo_map(aro_group_id,axo_id) values ($groupId,$axo_id)";

                mysql_query('BEGIN');

                mysql_query($sql_insert_aro_group_axo_map);
                
                if(mysql_errno()){
                    //add new user failed;
                    mysql_query('ROLLBACK');
                    $arr['status'] = 9999;
                    echo json_encode($arr);
                    return;
                }else{
                    mysql_query('COMMIT');
                }

            }
            $arr['status'] = 1000;
            echo json_encode($arr);
            
        }
    }
}

function projectJudgement($axo_section_name,$project){
    $sql_query_project="select device from long_custom_axo_details where solution_provider='$axo_section_name' and project='$project'";

    $result=mysql_query($sql_query_project);

    if(mysql_num_rows($result)>0){
        return true;
    }else{
        return false;
    }
}

function create_guid(){
    $charid=strtoupper(md5(uniqid(mt_rand(),true)));
    $hyphen = chr(45);
    $uuid = chr(123).substr($charid, 0,8).$hyphen.substr($charid, 8, 4).$hyphen
            .substr($charid, 12, 4).$hyphen.substr($charid, 16, 4).$hyphen
            .substr($charid, 20, 12).chr(125);
    return $uuid;
}

function addAxoDetails($solutionProvider,$axo_value,$device_model,$project){
    $sql_insert_long_custom_axo_details="insert into long_custom_axo_details(axo_value,device,project,solution_provider)values('$axo_value','$device_model','$project','$solutionProvider')";
    
    mysql_query('BEGIN');

    mysql_query($sql_insert_long_custom_axo_details);
    
    if(mysql_errno()){

        //add new user failed;
        
        mysql_query('ROLLBACK');
        return false;

    }else{
        //add new user success
        
        mysql_query('COMMIT');
        return true;
    }
}

