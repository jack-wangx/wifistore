<?php

class ContentAction extends AuthAction{

	/*
	<param name="type" type="string">内容的类型, 应用/游戏/壁纸/音乐/视频</param>

	*/
	public function listPage($type=null){
		if ($type == null) {
			$type = 'soft';
		}
		$this->type=$type;
		$this->display("Content:listPage");
	}

	public function getList($type, $startIndex=0, $pageSize=10, $sortField=null/*null*/, $filterWords=null/*null*/){
		if(empty($type) ){
			$this->errorMessage='param null';
			$response['status']=1001;
		}else{

			include_once(ROOT . '/controller/conn.php');
			switch ($type) {
				case 'game':
					$response=$this->getAppList($type, $startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/);

					break;
				case 'video':
					$response=$this->getVideoList($type, $startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/);

					break;
				case 'music':
					$response=$this->getMusicList($type, $startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/);

					break;
				case 'picture':
					$response=$this->getPicList($type, $startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/);

					break;
				case 'soft':
					$response=$this->getAppList($type, $startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/);

					break;

				default:
					# code...
					break;
			}
		}

		echo json_encode($response);
		// $this->display();

	}

	public function category($categoryId){

		if(empty($categoryId)){
			$this->errorMessage='param null';
		}else{
			include_once(ROOT . '/controller/conn.php');
			$queryCategory="select categoryId,categoryName from category where parentId='$categoryId'";
			try{
				$result=mysql_query($queryCategory) ;
		        	$count=mysql_num_rows($result);
		        	if($count>0){
		        		while($row=mysql_fetch_array($result)){
		        			$categoryArray[]=array(
	        					'id' => $row['categoryId'],
	        					'name' => $row['categoryName']
	        				);
		        		}
		        	}
		        	echo(json_encode($categoryArray));
			}catch(Exception $e){
				throw new Exception("query App exception sql error:".$queryCategory);
				$this->errorMessage='query App exception sql error:'.$queryCategory;
			}
		}
	}

	public function delete($contentUuid){

		if(empty($contentUuid)){
			$this->status=1001;
			$this->errorMessage='param null';
		}else{
			include_once(ROOT . '/controller/conn.php');
			$deleteContent="update content set flag=2 where contentUuid='$contentUuid'";

			try{
				$result=mysql_query($deleteContent) ;
	        		$this->status=1000;
			}catch(Exception $e){
				$this->status=1001;
				throw new Exception("delete content exception sql error:".$deleteContent);
				$this->errorMessage='delete content exception sql error:'.$deleteContent;
			}
		}

		$this->display();
	}

	public function addPage($type=null){

		if(empty($type)){
			$this->errorMessage='param null';
		}else{
			$this->type=$type;

		}
		include_once(ROOT . '/controller/conn.php');

		$categories=$this->getBaseCategories();
		if(!empty($categories)){
			$this->categories=json_encode($categories);
			$this->status=1000;
		}else{
			$this->categories=null;
			$this->status=1001;
		}


		$this->display('Content:addPage');
	}

	public function update($contentUuid,$type){
		//检索出内容，带上type一起回传到模板
		$contentUuid=trim($contentUuid);
		$type=trim($type);
		if(empty($contentUuid) or empty($type)){
			$this->errorMessage='param null';
		}else{
			include_once(ROOT . '/controller/conn.php');

			$categories=$this->getBaseCategories();
			if(!empty($categories)){
				$this->categories=json_encode($categories);
				$this->status=1000;
			}else{
				$this->categories=null;
				$this->status=1001;
			}
			$this->type=$type;
			switch ($type) {
					case 'game':
						$this->contentArray=$this->queryApp($contentUuid,$type);
						break;
					case 'video':
						$this->contentArray=$this->queryVideo($contentUuid);
						break;
					case 'music':
						$this->contentArray=$this->queryMusic($contentUuid);
						break;
					case 'picture':
						$this->contentArray=$this->queryPic($contentUuid);;
						break;
					case 'soft':
						$this->contentArray=$this->queryApp($contentUuid,$type);
						break;

					default:
						$this->contentArray=null;
						break;
				}
		}

		// echo json_encode($this->contentArray);
		$this->display();
	}

	public function updatePost($contentUuid,$type,$data,$delPics=null,$categoryIds=null){

		if(empty($contentUuid) or empty($type) or empty($data)){
			$this->errorMessage='param null';
		}else{
			include_once(ROOT . '/controller/conn.php');
			switch ($type) {
				case 'game':

					if(!empty($delPics)){


						try {
							$selectPicsSql="select picsUrl from app where contentUuid='$contentUuid'";
							$results=mysql_query($selectPicsSql);
							while ($row=mysql_fetch_array($results)) {

								if(!empty($row['picsUrl'])){
									$pics=explode(",",$row['picsUrl']);

									for ($i=0; $i <count($delPics) ; $i++) {
										if(in_array($delPics[$i],$pics)){
											unset($pics[array_search($delPics[$i],$pics)]);
										}
									}
									if(count($pics)>0){
										$picsUrl= implode(",",$pics);
										$data['picsUrl']=$picsUrl;
									}else{
										$data['picsUrl']='';
									}

								}
							}


						} catch (Exception $e) {
							$status=1001;
							return;
						}
					}
					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;
				case 'video':
					if(!empty($delPics)){
						$selectPicsSql="select picsUrl from video where contentUuid='$contentUuid'";
						try {
							$result=mysql_query($selectPicsSql);
							$row=mysql_fetch_array($result);
							while ($row=mysql_fetch_array($results)) {
								if(!empty($row['picsUrl'])){
									$pics=explode(",",$row['picsUrl']);
									for ($i=0; $i <count($delPics) ; $i++) {
										unset($pics[array_search($delPics[$i],$pics)]);
									}
									$picsUrl= implode(",",$pics);
									$data['picsUrl']=$picsUrl;
								}
							}

						} catch (Exception $e) {

						}
					}
					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;
				case 'music':
					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;
				case 'picture':
					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;
				case 'soft':
					if(!empty($delPics)){
						$selectPicsSql="select picsUrl from app where contentUuid='$contentUuid'";
						try {
							$result=mysql_query($selectPicsSql);
							while ($row=mysql_fetch_array($results)) {
								$row=mysql_fetch_array($result);
								if(!empty($row['picsUrl'])){
									$pics=explode(",",$row['picsUrl']);
									for ($i=0; $i <count($delPics) ; $i++) {
										unset($pics[array_search($delPics[$i],$pics)]);
									}
									$picsUrl= implode(",",$pics);
									$data['picsUrl']=$picsUrl;
								}
							}

						} catch (Exception $e) {

						}
					}
					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;

				default:
					# code...
					break;
			}

			if(!empty($categoryIds)){
				$status=$this->updateContentCategorys($contentUuid,$categoryIds);
			}

		}

		echo json_encode(array('status'=>$status));
	}

	/*
		上传内容主体，apk，MP4，MP3,图片精选
		并且写入数据库
	*/
	public function uploadMain($type){

		session_start();

		if(empty($type)){
			$errorMessage='param null';
			$status=1001;
		}else if ($_FILES["file"]["error"] > 0){
			$errorMessage='file upload error';
			$status=1002;
	    }else{
			include_once(ROOT . '/controller/conn.php');
			$contentUuid=ContentAction::create_uuid();
			$fileArr=$_FILES["file"];
			$name=str_replace( " ", "",$fileArr['name']);
			$tmpName=$fileArr['tmp_name'];
			$size=$fileArr['size'];
			switch ($type) {
				case 'game':
					$folderPath='/upload/'.$type.'/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					$apkInfo=$this->apkUpload($fileArr,$folderPath,$filePath);

					$data=array(
							'name'=>$apkInfo['lable'],
							'size'=>$size,
							'price'=>0,
							'filePath'=>$fileName,
							'iconUrl'=>$apkInfo['icon'],
							'description'=>'',
							'tag'=>'',
							'author'=>$_SESSION['uniqueId'],
							'packageName'=>$apkInfo['packageName'],
							'versionCode'=>$apkInfo['version_code'],
							'versionName'=>$apkInfo['versionName'],
							'picsUrl'=>''
						);


					$status = $this->add($type,$data, $contentUuid);
					break;
				case 'video':
					$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					include_once(ROOT . '/dmc/Lib/Util/ApkUtil.class.php');
					$apkUtil=new ApkUtil();

					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);

					$data=array(
							'name'=>$name,
							'size'=>$size,
							'filePath'=>$fileName,
							'author'=>$_SESSION['uniqueId']
						);


					$status = $this->add($type,$data, $contentUuid);
					break;
				case 'music':

					$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					include_once(ROOT . '/dmc/Lib/Util/ApkUtil.class.php');
					$apkUtil=new ApkUtil();

					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);

					$data=array(
							'name'=>$name,
							'size'=>$size,
							'filePath'=>$fileName,
							'author'=>$_SESSION['uniqueId']
						);


					$status = $this->add($type,$data, $contentUuid);

					break;
				case 'picture':

					$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					include_once(ROOT . '/dmc/Lib/Util/ApkUtil.class.php');
					$apkUtil=new ApkUtil();

					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);
					$iconUrl=time().'.jpg';

					$dst_storePath=$folderPath.'/'.$iconUrl;

					$this->imageZoom($filePath,$dst_storePath);

					$data=array(
							'name'=>$name,
							'size'=>$size,
							'filePath'=>$fileName,
							'author'=>$_SESSION['uniqueId'],
							'iconUrl'=>$iconUrl
						);
					$status = $this->add($type,$data, $contentUuid);

					break;
				case 'soft':
					$folderPath='/upload/'.$type.'/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;

					$apkInfo=$this->apkUpload($fileArr,$folderPath,$filePath);

					$data=array(
							'name'=>$apkInfo['lable'],
							'size'=>$size,
							'price'=>0,
							'filePath'=>$fileName,
							'iconUrl'=>$apkInfo['icon'],
							'description'=>'',
							'tag'=>'',
							'author'=>$_SESSION['uniqueId'],
							'packageName'=>$apkInfo['packageName'],
							'versionCode'=>$apkInfo['version_code'],
							'versionName'=>$apkInfo['versionName'],
							'picsUrl'=>''
						);


					$status = $this->add($type,$data, $contentUuid);
					break;
				default:
					break;
			}
		}
		echo json_encode(array(
				'type' =>$type,
				'status'=>$status,
				'errorMessage'=>$errorMessage,
				'uuid'=> $contentUuid
			));

	}

	/*
		上传修改的内容主体，apk，MP4，MP3
	*/
	public function uploadForUpdate($type,$contentUuid){

		session_start();

		if(empty($type) or empty($contentUuid)){
			$errorMessage='param null';
			$status=1001;
		}else if ($_FILES["file"]["error"] > 0){
			$errorMessage='file upload error';
			$status=1002;
	    }else{
			include_once(ROOT . '/controller/conn.php');

			$fileArr=$_FILES["file"];
			$name=str_replace( " ", "",$fileArr['name']);
			$tmpName=$fileArr['tmp_name'];
			$size=$fileArr['size'];
			switch ($type) {
				case 'game':
					$folderPath='/upload/game/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					$apkInfo=$this->apkUpload($fileArr,$folderPath,$filePath);

					$data=array(
							'name'=>$apkInfo['lable'],
							'size'=>$size,
							'filePath'=>$fileName,
							'iconUrl'=>$apkInfo['icon'],
							'author'=>$_SESSION['uniqueId'],
							'packageName'=>$apkInfo['packageName'],
							'versionCode'=>$apkInfo['version_code'],
							'versionName'=>$apkInfo['versionName'],

						);


					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;
				case 'video':
					$folderPath=ROOT .'/upload/video/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					include_once(ROOT . '/dmc/Lib/Util/ApkUtil.class.php');
					$apkUtil=new ApkUtil();

					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);

					$data=array(

							'size'=>$size,
							'filePath'=>$fileName,
							'author'=>$_SESSION['uniqueId']
						);


					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;
				case 'music':

					$folderPath=ROOT .'/upload/music/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					include_once(ROOT . '/dmc/Lib/Util/ApkUtil.class.php');
					$apkUtil=new ApkUtil();

					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);

					$data=array(

							'size'=>$size,
							'filePath'=>$fileName,
							'author'=>$_SESSION['uniqueId']
						);


					$status=$this->commonUpdate($type,$contentUuid, $data);

					break;
				case 'picture':

					$folderPath=ROOT .'/upload/picture/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					include_once(ROOT . '/dmc/Lib/Util/ApkUtil.class.php');
					$apkUtil=new ApkUtil();

					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);

					$data=array(

							'size'=>$size,
							'filePath'=>$fileName,
							'author'=>$_SESSION['uniqueId']
						);


					$status=$this->commonUpdate($type,$contentUuid, $data);

					break;
				case 'soft':
					$folderPath=ROOT .'/upload/soft/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					$apkInfo=$this->apkUpload($fileArr,$folderPath,$filePath);

					$data=array(
							'name'=>$apkInfo['lable'],
							'size'=>$size,

							'filePath'=>$fileName,
							'iconUrl'=>$folderPath.$apkInfo['icon'],

							'author'=>$_SESSION['uniqueId'],
							'packageName'=>$apkInfo['packageName'],
							'versionCode'=>$apkInfo['version_code'],
							'versionName'=>$apkInfo['versionName'],

						);


					$status=$this->commonUpdate($type,$contentUuid, $data);
					break;
				default:
					break;
			}
		}
		echo json_encode(array(
				'type' =>$type,
				'status'=>$status,
				'errorMessage'=>$errorMessage
			));
	}

	/*
		上传内容附属文件，icon，cover,screenshot
	*/
	public function upload($type,$inputName,$contentUuid){

		session_start();

		if(empty($type) or empty($contentUuid) or empty($inputName)){
			$errorMessage='param null';
			$status=1001;
		}else if ($_FILES["file"]["error"] > 0){
			$errorMessage='file upload error';
			$status=1002;
	    }else{

	    	include_once(ROOT . '/controller/conn.php');
		include_once(ROOT .'/dmc/Lib/Util/ApkUtil.class.php');
		$fileArr=$_FILES["file"];
		$name=str_replace( " ", "",$fileArr['name']);
		$tmpName=$fileArr['tmp_name'];
		$size=$fileArr['size'];

		$apkUtil=new ApkUtil();
	    	switch ($type) {
	    		case 'game':
	    			/*
	    				inputName:screenshot

	    			*/

	    			if($inputName=='screenshot'){

	    				$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid.'/pics';
						$fileName=time().'_'.$name;
						$filePath=$folderPath.'/'.$fileName;


						$apkUtil->mkdirs($folderPath);

						move_uploaded_file($tmpName,$filePath);




						$status=$this->addPic('app',$contentUuid, $fileName);
	    			}
	    			break;
	    		case 'video':
	    			/*
	    				inputName:
	    					screenshot
							cover
	    			*/

				if($inputName=='screenshot'){
	    					$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid.'/pics';
						$fileName=time().'_'.$name;
						$filePath=$folderPath.'/'.$fileName;

						$apkUtil->mkdirs($folderPath);

						move_uploaded_file($tmpName,$filePath);

						$status=$this->addPic('video',$contentUuid, $fileName);
	    			}else{
	    					$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid;
						$fileName=time().'_'.$name;
						$filePath=$folderPath.'/'.$fileName;
						$apkUtil->mkdirs($folderPath);

						move_uploaded_file($tmpName,$filePath);
						$iconUrl=time().'.jpg';
						$dst_storePath=$folderPath.'/'.$iconUrl;

						$this->imageZoom($filePath,$dst_storePath);

						$this->addIconUrl($contentUuid,$iconUrl);

						$status=$this->addCover('video',$contentUuid, $fileName);
	    			}
	    			break;
	    		case 'music':
	    			/*
	    				inputName:

							cover
	    			*/

					$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid;
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;
					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);

					$iconUrl=time().'.jpg';
					$dst_storePath=$folderPath.'/'.$iconUrl;

					$this->imageZoom($filePath,$dst_storePath);

					$this->addIconUrl($contentUuid,$iconUrl);

					$status=$this->addCover('music',$contentUuid, $fileName);
	    			break;
	    		case 'picture':
	    			# code...
	    			break;
	    		case 'soft':
	    			/*
	    				inputName:screenshot

	    			*/
    				if($inputName=='screenshot'){
    				$folderPath=ROOT .'/upload/'.$type.'/'.$contentUuid.'/pics';
					$fileName=time().'_'.$name;
					$filePath=$folderPath.'/'.$fileName;


					$apkUtil->mkdirs($folderPath);

					move_uploaded_file($tmpName,$filePath);




					$status=$this->addPic('app',$contentUuid, $fileName);
	    			}
	    			break;

	    		default:
	    			# code...
	    			break;
	    	}
	    }

	    echo json_encode(array(
				'type' =>$type,
				'status'=>$status,
				'errorMessage'=>$errorMessage
			));

	}



	public function exportPage($startDate=null, $endDate=null){


		$this->startDate=$startDate==null?date('Y-m-d H:i:s'):$startDate;
		$this->endDate=$endDate==null?date('Y-m-d H:i:s'):$endDate;

		$this->display("Content:exportPage");

	}

	public function exportList($startDate, $endDate,$startIndex=0,$pageSize=10,$sort/*null*/){

		if(empty($startDate) or empty($endDate) ){

			$response['status']=1001;
		}else{
			include_once(ROOT . '/controller/conn.php');
			$response=$this-> getCommonList($startDate, $endDate,$startIndex,$pageSize,$sort);
		}
		echo json_encode($response);

	}

	public function makeOTA($startDate,$endDate){

		if(empty($startDate) or empty($endDate)){
			$response['status']=1001;
			$response['errMsg']='param is null';
		}else{
			$uuid = ContentAction::create_uuid();
			include_once(ROOT . '/controller/conn.php');
			$sql=sprintf("insert into ota_record(uuid,beginTime,endTime,author)values('%s','%s','%s','%s')",$uuid,$startDate,$endDate,$_SESSION['uniqueId']);
			try {
				mysql_query($sql);
				$pid = ContentAction::makeOTAZip($uuid, $startDate, $endDate);

				$sql=sprintf("update ota_record set pid=%s where uuid='%s'", $pid,$uuid);
				mysql_query($sql);

				$response['status']=1000;
				$response['pid']=$pid;
			} catch (Exception $e) {
				$response['status']=1001;
			}
		}

		echo json_encode($response);


	}

	public static function makeOTAZip($uuid, $startDate, $endDate) {

		$filePath=ROOT.'/dmc/Lib/Util/ExportToolScript.php';
		$ota_path=ROOT.'/ota/'.$uuid.'/';
		$root_path=ROOT.'/upload/';
		ContentAction::mkdirs($ota_path, false);


		// $command=sprintf("php -q %s %s %s '%s' '%s' '%s' >/dev/null &",$filePath,$ota_path,$root_path,$startDate,$endDate,$uuid);
		// $command=sprintf("php -q %s %s %s '%s' '%s' '%s' ",$filePath,$ota_path,$root_path,$startDate,$endDate,$uuid);
		// echo $command;
		//
		$shellFile=ROOT.'/dmc/Lib/Action/makeZip.sh';

		$ota_path = str_replace(' ', '|', $ota_path);
		$root_path = str_replace(' ', '|', $root_path);
		$startDate = str_replace(' ', '|', $startDate);
		$endDate = str_replace(' ', '|', $endDate);
		$file = popen(sprintf("/bin/bash $shellFile %s %s %s '%s' '%s' '%s'",
				$filePath,$ota_path,$root_path,$startDate,$endDate,$uuid), 'r');
		$pid = trim(fgets($file));

		pclose($file);

		return $pid;
	}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	static function mkdirs($path, $lastoneisfile = false, $rights = 0755) {

		    if (trim ( $path ) == '')
		    return;

		    if (! $lastoneisfile && substr ( $path, - 1 ) != '/') {
		        $path = $path . "/";
		    }
		    if (is_dir ( $path )) {
		        return true;
		    } //found it!
		    $path = str_replace ( "\\", "/", $path );
		    $path = preg_replace ( '/\/+/i', '/', $path );
		    $pathes = explode ( '/', $path );
		    $cnt = count ( $pathes ) - 1;
		    $dir = current ( $pathes ) . "/";
		    if (! is_dir ( $dir . "/" )) {
		        mkdir ( $dir );
		    }
		    for($i = 0; $i < $cnt; $i ++) {
		        if (! is_dir ( $dir . "/" )) {
		            @mkdir ( $dir );
		            @chmod ( $dir, $rights );
		        }
		        $dir .= next ( $pathes ) . "/";
		    }
		}


	private function getBaseCategories(){

		$queryBaseCategory="select categoryName,categoryId from category where parentId is null";

		try {

			$result=mysql_query($queryBaseCategory);

			while ($row=mysql_fetch_array($result)){

				$categories[$row['categoryName']]=$row['categoryId'];

			}

			return $categories;

		} catch (Exception $e) {
			//throw new Exception("query base categories sql error:".$queryBaseCategory);
			return null;
		}

	}

	private function updateContentCategorys($contentUuid,$categoryIds){

		try {
			$updateTime=date('Y-m-d H:i:s');
			$contentUpdateTimeSql="update content set updateTime='$updateTime' where contentUuid='$contentUuid'";
			mysql_query($contentUpdateTimeSql);
			$deleteContentCateSql="delete from content_categorys where contentUuid='$contentUuid'";
			mysql_query($deleteContentCateSql);
			for ($i=0; $i <count($categoryIds) ; $i++) {
				$categoryId=$categoryIds[$i];
				$addContentCateSql="insert into content_categorys (categoryId,contentUuid) values('$categoryId','$contentUuid')";
				mysql_query($addContentCateSql);
			}
			return 1000;
		} catch (Exception $e) {
			return 2001;
		}
	}

	private function addIconUrl($contentUuid,$iconUrl){
		try {
			$updateIconSql="update content set iconUrl='$iconUrl' where contentUuid='$contentUuid'";

			mysql_query($updateIconSql);
			return 1000;
		} catch (Exception $e) {
			throw new Exception("addPic sql error:".$updateIconSql);
			return 1003;
		}
	}

	private function addCover($tableName,$contentUuid, $fileName){

		try {
			$updateCoverSql="update $tableName set cover='$fileName' where contentUuid='$contentUuid'";

			mysql_query($updateCoverSql);
			return 1000;
		} catch (Exception $e) {
			throw new Exception("addPic sql error:".$tableName.'->'.$updateCoverSql);
			return 1003;
		}
	}

	private function addPic($tableName,$contentUuid, $fileName){
		$queryPicsSql="select picsUrl from $tableName where contentUuid='$contentUuid'";

		try {
			$result=mysql_query($queryPicsSql);
			$row=mysql_fetch_array($result);
			$picsUrl=$row['picsUrl'];
			if (empty($picsUrl)) {
				$picsUrl=$fileName;
			}else{
				$picsUrl=$picsUrl.','.$fileName;
			}
			$updatePicsUrl="update $tableName set picsUrl='$picsUrl' where contentUuid='$contentUuid'";

			mysql_query($updatePicsUrl);
			return 1000;
		} catch (Exception $e) {
			throw new Exception("addPic sql error:".$tableName.'->'.$updatePicsUrl);
			return 1003;
		}
	}

	private function commonUpdate($type,$contentUuid, $data){

		if(empty( $type) or empty($data) or empty($contentUuid)){
			$status=1002;
		}else{
			include_once(ROOT . '/controller/conn.php');
			$status=$this->updateContent($contentUuid,$data);
			if($status=1000){
				switch ($type) {
					case 'game':
							$status=$this->updateApp($contentUuid,$data);
							break;
						case 'video':
							$status=$this->updateVideo($contentUuid,$data);
							break;
						case 'music':
							$status=$this->updateMusic($contentUuid,$data);
							break;
						case 'picture':
							$status=$this->updatePic($contentUuid,$data);;
							break;
						case 'soft':
							$status=$this->updateApp($contentUuid,$data);
							break;

						default:
							$status=9999;
							break;
				}
			}

		}

		return $status;
	}

	private function updateContent($contentUuid,$data){

		$tableParam=array('name','price','description','filePath','size','iconUrl','tag');
		session_start();

		$author=$_SESSION['uniqueId'];
		// to be deleted

		$updateTime=date('Y-m-d H:i:s');
		$flag=1;

		$updateContentSql="update content set updateTime='$updateTime',flag=$flag ";

		while(list($key,$value) = each($data)){

			if(in_array($key,$tableParam) ){

				if($key=='price' or $key=='size'){
					$updateContentSql=$updateContentSql.','.$key.'='.$value;
				}else{
					$updateContentSql=$updateContentSql.','.$key."='".$value."'";
				}

			}


		}

		$updateContentSql=$updateContentSql." where contentUuid='$contentUuid'";



		try {

			mysql_query($updateContentSql);

			return 1000;

		} catch (Exception $e) {

			return 1001;

			throw new Exception("updateContent sql error:".$updateContentSql);

		}

	}

	private function updateApp($contentUuid,$data){

		$tableParam=array('packageName','versionCode','versionName','picsUrl');




		$updateAppSql="update app set contentUuid='$contentUuid' ";

		while(list($key,$value) = each($data)){

			if(in_array($key,$tableParam) ){

				if($key=='versionCode'){
					$updateAppSql=$updateAppSql.','.$key.'='.$value;
				}else{
					$updateAppSql=$updateAppSql.','.$key."='".$value."'";
				}

			}


		}

		$updateAppSql=$updateAppSql." where contentUuid='$contentUuid'";



		try {

			mysql_query($updateAppSql);

			return 1000;

		} catch (Exception $e) {

			return 1001;

			throw new Exception("updateContent sql error:".$updateContentSql);

		}


	}

	private function updateVideo($contentUuid,$data){

		$tableParam=array('year','director','actors','picsUrl','cover');

		$updateSql="update video set contentUuid='$contentUuid' ";

		while(list($key,$value) = each($data)){

			if(in_array($key,$tableParam) ){

				if($key=='year'){
					$updateSql=$updateSql.','.$key.'='.$value;
				}else{
					$updateSql=$updateSql.','.$key."='".$value."'";
				}

			}
		}

		$updateSql=$updateSql." where contentUuid='$contentUuid'";
		try {

			mysql_query($updateSql);

			return 1000;

		} catch (Exception $e) {

			return 1001;

			throw new Exception("updateContent sql error:".$updateContentSql);

		}

	}

	private function updateMusic($contentUuid,$data){

		$tableParam=array('year','singer','lyricist','composer','cover');

		$updateSql="update music set contentUuid='$contentUuid' ";

		while(list($key,$value) = each($data)){

			if(in_array($key,$tableParam) ){

				if($key=='year'){
					$updateSql=$updateSql.','.$key.'='.$value;
				}else{
					$updateSql=$updateSql.','.$key."='".$value."'";
				}

			}
		}

		$updateSql=$updateSql." where contentUuid='$contentUuid'";
		try {

			mysql_query($updateSql);

			return 1000;

		} catch (Exception $e) {

			return 1001;

			throw new Exception("updateContent sql error:".$updateContentSql);

		}
	}

	private function updatePic($contentUuid,$data){



	}

	private function queryApp($contentUuid,$type='soft'){

		$queryAppSql="select name,size,price,filePath,iconUrl,description,createTime,tag,content.contentUuid as contentUuid,packageName,versionCode,versionName,picsUrl
		 				from content left join app on content.contentUuid=app.contentUuid where flag!=2 and content.contentUuid='$contentUuid'";

		$appContent=null;
		try {
			$result=mysql_query($queryAppSql);

			$count=mysql_num_rows($result);

			if($count>1){

				throw new Exception("content repeat:".$contentUuid);
			}
			$categories=$this->getContentCategories($contentUuid);
			while ($row=mysql_fetch_array($result)) {

				$pics=explode(",",$row['picsUrl']);
				for ($i=0; $i <count($pics) ; $i++) {
					$pics[$i]='/upload/'.$type.'/'.$contentUuid.'/pics/'.$pics[$i];
				}

				$appContent=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/'.$type.'/'.$contentUuid.'/'.$row['filePath'],
						'iconUrl'=>'/upload/'.$type.'/'.$contentUuid.'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'tag'=>$row['tag'],

						'contentUuid'=>$row['contentUuid'],
						'packageName'=>$row['packageName'],
						'versionCode'=>$row['versionCode'],
						'versionName'=>$row['versionName'],
						'pictures'=>$pics,
						'categories'=>$categories
					);
			}

		} catch (Exception $e) {
			throw new Exception("queryApp error".$queryAppSql);

		}

		return $appContent;
	}

	private function getContentCategories($contentUuid){
		if(empty($contentUuid)){
			return null;
		}
		try {
			$sql="select categoryId from content_categorys where contentUuid='$contentUuid'";

			$result=mysql_query($sql);
			if(count($result)>0){
				while ($row=mysql_fetch_array($result)) {
					$contentCategories[]=$row['categoryId'];
				}
				$categories=implode(",", $contentCategories);
				return $categories;
			}else{
				return '';
			}
		} catch (Exception $e) {
			return '';
		}


	}

	private function queryVideo($contentUuid){

		$queryVideoSql="select name,size,price,filePath,iconUrl,description,createTime,tag,content.contentUuid,year,director,actors,picsUrl,cover
		 				from content left join video on content.contentUuid=video.contentUuid where flag!=2 and content.contentUuid='$contentUuid'";
		$videoContent=null;
		try {
			$result=mysql_query($queryVideoSql);

			$count=mysql_num_rows($result);

			if($count>1){

				throw new Exception("content repeat:".$contentUuid);
			}

			$categories=$this->getContentCategories($contentUuid);

			while ($row=mysql_fetch_array($result)) {

				$pics=explode(",",$row['picsUrl']);
				for ($i=0; $i <count($pics) ; $i++) {
					$pics[$i]='/upload/video/'.$contentUuid.'/pics/'.$pics[$i];
				}
				$videoContent=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/video/'.$contentUuid.'/'.$row['filePath'],
						'iconUrl'=>'/upload/video/'.$contentUuid.'/'.$row['iconUrl'],
						'cover'=>'/upload/video/'.$contentUuid.'/'.$row['cover'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'tag'=>$row['tag'],

						'contentUuid'=>$row['contentUuid'],
						'year'=>$row['year'],
						'director'=>$row['director'],
						'actors'=>$row['actors'],
						'pictures'=>$pics,
						'categories'=>$categories
					);
			}

		} catch (Exception $e) {
			throw new Exception("queryVideo error".$queryVideoSql);

		}
		return $videoContent;

	}

	private function queryMusic($contentUuid){

		$queryMusicSql="select name,size,price,filePath,iconUrl,description,createTime,tag,content.contentUuid,year,singer,lyricist,composer,cover
		 				from content left join music b on content.contentUuid=b.contentUuid where flag!=2 and content.contentUuid='$contentUuid'";
		$musicContent=null;
		try {
			$result=mysql_query($queryMusicSql);

			$count=mysql_num_rows($result);

			if($count>1){

				throw new Exception("content repeat:".$contentUuid);
			}

			$categories=$this->getContentCategories($contentUuid);

			while ($row=mysql_fetch_array($result)) {
				$musicContent=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/music/'.$contentUuid.'/'.$row['filePath'],
						'iconUrl'=>'/upload/music/'.$contentUuid.'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'tag'=>$row['tag'],

						'contentUuid'=>$row['contentUuid'],
						'year'=>$row['year'],
						'singer'=>$row['singer'],
						'lyricist'=>$row['lyricist'],
						'composer'=>$row['composer'],
						'cover'=>'/upload/music/'.$contentUuid.'/'.$row['cover'],
						'categories'=>$categories
					);
			}

		} catch (Exception $e) {
			throw new Exception("queryMusic error".$queryMusicSql);

		}
		return $musicContent;
	}

	private function queryPic($contentUuid){

		$queryPicSql="select name,size,price,filePath,iconUrl,description,createTime,tag,content.contentUuid from content where flag!=2 and contentUuid='$contentUuid'";
		$picContent=null;
		try {
			$result=mysql_query($queryPicSql);

			$count=mysql_num_rows($result);

			if($count>1){

				throw new Exception("content repeat:".$contentUuid);
			}
			$categories=$this->getContentCategories($contentUuid);

			while ($row=mysql_fetch_array($result)) {
				$picContent=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/picture/'.$contentUuid.'/'.$row['filePath'],
						'iconUrl'=>'/upload/picture/'.$contentUuid.'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'tag'=>$row['tag'],

						'contentUuid'=>$row['contentUuid'],
						'categories'=>$categories
					);
			}

		} catch (Exception $e) {
			throw new Exception("queryPic error".$queryPicSql);

		}
		return $picContent;

	}

	private function add($type, $data, $contentUuid){

		if(empty($type) or empty($data)){
			$status=1002;
		}else{
			include_once(ROOT . '/controller/conn.php');
			$status=$this->addContent($data,$contentUuid);//////????????/
			if($status==1000){
				switch ($type) {
					case 'game':
						$status=$this->addApp($data,$contentUuid);
						break;
					case 'video':
						$status=$this->addVideo($data,$contentUuid);
						break;
					case 'music':
						$status=$this->addMusic($data,$contentUuid);
						break;
					case 'picture':
						$status=1000;
						break;
					case 'soft':
						$status=$this->addApp($data,$contentUuid);
						break;

					default:
						$status=1001;
						break;
				}
			}

		}

		return $status;

	}

	private function addContent($data,$contentUuid){

		$name=$data['name']==null?'':$data['name'];
		$size=$data['size']==null?'':$data['size'];
		$price=$data['price']==null?0:$data['price'];
		$filePath=$data['filePath']==null?'':$data['filePath'];
		$iconUrl=$data['iconUrl']==null?'':$data['iconUrl'];
		$description=$data['description']==null?'':$data['description'];
		$tag=$data['tag']==null?'':$data['tag'];
		$author=$data['author']==null?'':$data['author'];
		//todo remove


		$addContentSql="insert into content (name,size,price,filePath,iconUrl,description,tag,author,contentUuid )
						values('$name',$size,$price,'$filePath','$iconUrl','$description','$tag','$author','$contentUuid')";

		try {
			mysql_query($addContentSql);
			return 1000;
		} catch (Exception $e) {
			throw new Exception("addContent sql error:".$addContentSql);
			return 1001;
		}
	}



	private function addApp($data,$contentUuid){



		/*
			把内容写入数据库
		*/
		$packageName=$data['packageName'];
		$versionCode=$data['versionCode'];
		$versionName=$data['versionName'];
		$picsUrl=$data['picsUrl'];

		$addAppSql="insert into app (contentUuid,packageName,versionCode,versionName,picsUrl )
						values('$contentUuid','$packageName',$versionCode,'$versionName','$picsUrl')";

		try {
			mysql_query($addAppSql);
			return 1000;
		} catch (Exception $e) {
			throw new Exception("addApp:sql error".$addAppSql);
			return 1001;
		}

	}

	private function addVideo($data,$contentUuid){

		$year=$data['year']==null?0:$data['year'];
		$director=$data['director']==null?'':$data['director'];
		$actors=$data['actors']==null?'':$data['actors'];

		$addVideoSql="insert into video (contentUuid,year,director,actors) values('$contentUuid',$year,'$director','$actors')";

		try {
			mysql_query($addVideoSql);
			return 1000;
		} catch (Exception $e) {
			throw new Exception("addVideo:sql error".$addVideoSql);
			return 1001;
		}

	}



	private function addMusic($data,$contentUuid){

		$singer=$data['singer']==null?'':$data['singer'];
		$year=$data['year']==null?0:$data['year'];
		$lyricist=$data['lyricist']==null?'':$data['lyricist'];
		$composer=$data['composer']==null?'':$data['composer'];
		$cover=$data['cover']==null?'':$data['cover'];

		$addMusicSql="insert into music (contentUuid,singer,year,lyricist,composer,cover)
						values('$contentUuid','$singer',$year,'$lyricist','$composer','$cover')";
		try {
			mysql_query($addMusicSql);
			return 1000;
		} catch (Exception $e) {
			throw new Exception("addMusic:sql error".$addMusicSql);
			return 1001;
		}
	}

	private function apkUpload($fileArr,$folderPath,$filePath){
		include_once(ROOT . '/dmc/Lib/Util/ApkUtil.class.php');
		$folderPath = ROOT . $folderPath;
		$filePath = ROOT . $filePath;
		$apkUtil=new ApkUtil();
		$name=str_replace( " ", "",$fileArr['name']);
		$tmpName=$fileArr['tmp_name'];
		$apkUtil->mkdirs($folderPath);
		move_uploaded_file($tmpName,$filePath);


		$apkInfo=$apkUtil->readApkInfoFromFile($filePath,true,$folderPath);
		return $apkInfo;

	}

	private function getBaseCategoryByName($categoryName){

		$sql="select categoryId from category where  parentId is null and categoryName='$categoryName'";
		try {
			$result=mysql_query($sql);
			$row=mysql_fetch_array($result);
			return $row['categoryId'];
		} catch (Exception $e) {

			return null;
		}
	}

	private function getAppList($type, $startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/){
		$getCategoryId=$this->getBaseCategoryByName($type);
		$countSql="select count(*) total from content inner join content_categorys cc on content.contentUuid=cc.contentUuid inner join app on content.contentUuid=app.contentUuid where categoryId='$getCategoryId' ";
		$querySql="select content.contentUuid,name,size,price,filePath,iconUrl,description,author,content.createTime,packageName,versionCode,versionName,picsUrl,flag from content inner join content_categorys cc on content.contentUuid=cc.contentUuid inner join app on content.contentUuid=app.contentUuid where cc.categoryId='$getCategoryId'";
		if(!empty($filterWords)){
			$querySql=$querySql." and name like '%$filterWords%'";
		}
		if(!empty($sortField)){
			$querySql=$querySql." order by '$sortField'";
		}
		$querySql=$querySql.'limit '.$startIndex.','.$pageSize;
		try {
			$resultForAll=mysql_query($countSql);

			$rowCount=mysql_fetch_array($resultForAll);
			$response['total']=$rowCount['total'];
			$result=mysql_query($querySql);
			// echo $querySql;

			while ($row=mysql_fetch_array($result)) {

				$pics=explode(",",$row['picsUrl']);
				for ($i=0; $i <count($pics) ; $i++) {
					$pics[$i]='/upload/'.$type.'/'.$row['contentUuid'].'/pics/'.$pics[$i];
				}

				$response['data'][]=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['filePath'],
						'iconUrl' =>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'contentUuid'=>$row['contentUuid'],
						'packageName'=>$row['packageName'],
						'versionCode'=>$row['versionCode'],
						'versionName'=>$row['versionName'],
						'pictures'=>$pics,
						'flag'=>$row['flag']
					);
			}
			$response['status']=1000;
			return $response;
		} catch (Exception $e) {
			$response['status']=1001;
			throw new Exception("query App exception sql error:".$queryApp);
			return $response;
		}


	}

	private function getVideoList($type,$startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/){
		$getCategoryId=$this->getBaseCategoryByName($type);
		$countSql="select count(*) total from content inner join content_categorys cc on content.contentUuid=cc.contentUuid inner join video on content.contentUuid=video.contentUuid where categoryId='$getCategoryId'";
		$querySql="select content.contentUuid,name,size,price,filePath,iconUrl,description,author,content.createTime,year,director,actors,picsUrl,cover,flag from content inner join content_categorys cc on content.contentUuid=cc.contentUuid inner join video on content.contentUuid=video.contentUuid where cc.categoryId='$getCategoryId'";
		if(!empty($filterWords)){
			$querySql=$querySql." and name like '%$filterWords%'";
		}
		if(!empty($sortField)){
			$querySql=$querySql." order by $sortField ";
		}
		$querySql=$querySql."limit $startIndex,$pageSize";
		try {
			$resultForAll=mysql_query($countSql);

			$rowCount=mysql_fetch_array($resultForAll);
			$response['total']=$rowCount['total'];

			$result=mysql_query($querySql);

			while ($row=mysql_fetch_array($result)) {

				$pics=explode(",",$row['picsUrl']);
				for ($i=0; $i <count($pics) ; $i++) {
					$pics[$i]='/upload/'.$type.'/'.$row['contentUuid'].'/pics/'.$pics[$i];
				}

				$response['data'][]=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['filePath'],
						'iconUrl' =>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'contentUuid'=>$row['contentUuid'],
						'year'=>$row['year'],
						'director'=>$row['director'],
						'actors'=>$row['actors'],
						'pictures'=>$pics,
						'cover'=>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['cover'],
						'flag'=>$row['flag']
					);
			}
			$response['status']=1000;
			return $response;
		} catch (Exception $e) {
			$response['status']=1001;
			throw new Exception("query App exception sql error:".$queryApp);
			return $response;
		}

	}
	private function getMusicList( $type,$startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/){
		$getCategoryId=$this->getBaseCategoryByName($type);
		$countSql="select count(*) total from content inner join content_categorys cc on content.contentUuid=cc.contentUuid inner join music on content.contentUuid=music.contentUuid where categoryId='$getCategoryId'";
		$querySql="select content.contentUuid,name,size,price,filePath,iconUrl,description,author,content.createTime,year,singer,lyricist,composer,cover,flag from content inner join content_categorys cc on content.contentUuid=cc.contentUuid inner join music on content.contentUuid=music.contentUuid where cc.categoryId='$getCategoryId'";
		if(!empty($filterWords)){
			$querySql=$querySql." and name like '%$filterWords%'";
		}
		if(!empty($sortField)){
			$querySql=$querySql." order by $sortField ";
		}
		$querySql=$querySql."limit $startIndex,$pageSize";
		try {
			$resultForAll=mysql_query($countSql);

			$rowCount=mysql_fetch_array($resultForAll);
			$response['total']=$rowCount['total'];

			$result=mysql_query($querySql);

			while ($row=mysql_fetch_array($result)) {

				$response['data'][]=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['filePath'],
						'iconUrl' =>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'contentUuid'=>$row['contentUuid'],
						'year'=>$row['year'],
						'singer'=>$row['singer'],
						'lyricist'=>$row['lyricist'],
						'composer'=>$row['composer'],
						'cover'=>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['cover'],
						'flag'=>$row['flag']
					);
			}
			$response['status']=1000;
			return $response;
		} catch (Exception $e) {
			$response['status']=1001;
			throw new Exception("query App exception sql error:".$queryApp);
			return $response;
		}

	}

	private function getPicList($type, $startIndex, $pageSize, $sortField/*null*/, $filterWords/*null*/){
		$getCategoryId=$this->getBaseCategoryByName($type);
		$countSql="select count(*) total from content inner join content_categorys cc on content.contentUuid=cc.contentUuid where categoryId='$getCategoryId'";
		$querySql="select content.contentUuid,name,size,price,filePath,iconUrl,description,author,content.createTime,flag from content inner join content_categorys cc on content.contentUuid=cc.contentUuid where cc.categoryId='$getCategoryId'";
		if(!empty($filterWords)){
			$querySql=$querySql." and name like '%$filterWords%'";
		}
		if(!empty($sortField)){
			$querySql=$querySql." order by $sortField ";
		}
		$querySql=$querySql."limit $startIndex,$pageSize";
		try {
			$resultForAll=mysql_query($countSql);

			$rowCount=mysql_fetch_array($resultForAll);
			$response['total']=$rowCount['total'];

			$result=mysql_query($querySql);

			while ($row=mysql_fetch_array($result)) {



				$response['data'][]=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'filePath'=>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['filePath'],
						'iconUrl' =>'/upload/'.$type.'/'.$row['contentUuid'].'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'contentUuid'=>$row['contentUuid'],
						'flag'=>$row['flag']
					);
			}
			$response['status']=1000;
			return $response;
		} catch (Exception $e) {
			$response['status']=1001;
			throw new Exception("query App exception sql error:".$queryApp);
			return $response;
		}

	}
	private function getCommonList($startDate,$endDate, $startIndex, $pageSize, $sort/*null*/ ){

		$queryCountSql="select count(*) total
					from content a
					inner join content_categorys b on a.contentUuid=b.contentUuid
					inner join category c on b.categoryId=c.categoryId
					left join spUser d on a.author=d.uniqueId
					where c.parentId is null and updateTime between '$startDate' and '$endDate' ";

		$querySql="select d.userName, a.updateTime,a.contentUuid,name,size,price,filePath,iconUrl,description,author,a.createTime,flag,c.categoryName type
					from content a
					inner join content_categorys b on a.contentUuid=b.contentUuid
					inner join category c on b.categoryId=c.categoryId
					left join spUser d on a.author=d.uniqueId
					where c.parentId is null and updateTime between '$startDate' and '$endDate' ";


		if(!empty($sort)){
			$querySql=$querySql." order by $sort ";
		}
		$querySql=$querySql."limit $startIndex,$pageSize";
		try {

			$resultForAll=mysql_query($queryCountSql);
			$rowCount=mysql_fetch_array($resultForAll);
			$response['total']=$rowCount['total'];

			// echo $querySql;
			$result=mysql_query($querySql);

			while ($row=mysql_fetch_array($result)) {



				$response['data'][]=array(
						'name'=>$row['name'],
						'size'=>$row['size'],
						'price'=>$row['price'],
						'updateTime'=>$row['updateTime'],
						'iconUrl' =>'/upload/'.$row['type'].'/'.$row['contentUuid'].'/'.$row['iconUrl'],
						'description'=>$row['description'],
						'createTime'=>$row['createTime'],
						'contentUuid'=>$row['contentUuid'],
						'flag'=>$row['flag'],
						'type'=>$row['type'],
						'author'=>$row['userName']
					);
			}
			// echo json_encode($response['data']);
			$response['status']=1000;
			return $response;
		} catch (Exception $e) {
			$response['status']=1001;
			throw new Exception("query App exception sql error:".$queryApp);
			return $response;
		}

	}

	static private function create_uuid($prefix = ""){    //可以指定前缀

	    $str = md5(uniqid(mt_rand(), true));

	    $uuid  = substr($str,0,8) . '-';

	    $uuid .= substr($str,8,4) . '-';

	    $uuid .= substr($str,12,4) . '-';

	    $uuid .= substr($str,16,4) . '-';

	    $uuid .= substr($str,20,12);

	    return $prefix . $uuid;

	}

	public function imageZoom($background, $newfile,$width=48, $height=48 ) {

		// $background=ROOT .'/upload/video/2e919851-69dd-4955-518e-10b39f55ebe1/1393659380_1393309939_AEapocalypseearth.jpg';
		// $newfile=ROOT .'/test.jpg';
		// /upload/picture/9b5a9a50-23be-5da2-8dd1-4c1c18c31716/1393771234_1393301186_animal.jpg

		// echo $background;
		// echo $newfile;

		list($s_w, $s_h)=getimagesize($background);//获取原图片高度、宽度
		if ($width && ($s_w < $s_h)) {
			$width = ($height / $s_h) * $s_w;
		} else {
			$height = ($width / $s_w) * $s_h;
		}
		$new=imagecreatetruecolor($width, $height);
		$img=imagecreatefromjpeg($background);
		imagecopyresampled($new, $img, 0, 0, 0, 0, $width, $height, $s_w, $s_h);
		imagejpeg($new, $newfile);
		imagedestroy($new);
		imagedestroy($img);
	}




}
