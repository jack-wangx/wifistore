<?php


/**
 * Account short summary.
 *
 * Account description.
 *
 * @version 1.0
 * @author Hank
 */
class TestContentAction extends Action {
    public function login() {
        if ($this->isPost()) {
            $this->dologin();
        } else {
            $this->display();
        }
    }

    public function add() {
        $this->display();
    }

    public function update($contentUuid, $type) {
        $this->type = $type;
        $this->typeName = $this->getTypeName($type);
        $this->contentArray = array(
            'name'=>'车轮查违章',
            'size'=>1184000,
            'price'=>10,
            'filePath'=>$type=='picture' ? 'http://b.zol-img.com.cn/desk/bizhi/image/4/720x360/1386243711891.jpg' : 'http://apps.wandoujia.com/apps/cn.eclicks.wzsearch/download',
            'iconUrl'=>'http://img.wdjimg.com/mms/icon/v1/4/4e/3edf9d42129a36d3e8f53b3cdb4914e4_256_256.png',
            'description'=>'奔跑不止，车轮查违章携手豌豆荚为你加油！千元加油卡免费送！
参与方式：
在「豌豆荚」下载「车轮查违章」，打开应用点击「首页活动banner」进入活动页面，点击「抽奖」按钮进行抽奖即可。
奖品一览：
一等奖 1000元加油卡 （5张）
二等奖 500元加油卡 （5张）
三等奖 50元话费充值卡（50张）
活动时间：
2月21日-2月23日
（将于2月25日在活动页面和官方微博/微信公布获奖名单，活动结束5个工作日内发放奖品）
车轮查违章-违章查询（适用全国交通违章）是易点时空旗下的一款支持全国违章查询的工具，具备以下特点：
1．数据直接和交管局对接，可能是目前查询结果最新最准确，并有专人长期维护更新的一款违章查询类应用； 2．永久免费！ 3．覆盖全国300多个城市； 4．操作简单，上手容易； 5．支持异地查询，支持多辆车查询； 6．可以帮朋友查询，并将违章信息通过微信等方式发送给Ta； 7．输入车辆信息后，自动保存，下次不用再次输入，只需刷新即可查询。',
            'createTime'=>'2014-02-21',
            'tag'=>null,
            'content'=>'',
            'pictures' => split(',', 'http://img.wdjimg.com/mms/screenshot/5/0a/4cc1a5ca366f78c258389a680dd910a5_320_533.jpeg,http://img.wdjimg.com/mms/screenshot/7/3b/aa897b801e530403c54fe318bb0523b7_320_533.jpeg,http://img.wdjimg.com/mms/screenshot/3/91/1bc4c22c05c6b2156aa1884e90a35913_320_533.jpeg,http://img.wdjimg.com/mms/screenshot/6/74/d649d137db6255bca00beb15fc371746_320_533.jpeg,http://img.wdjimg.com/mms/screenshot/3/7d/83a966c217af8010bb016587e38c17d3_320_533.jpeg'),
            'contentUuid'=>$contentUuid,
            'categories'=>'book,finance',
            'packageName'=>'cn.eclicks.wzsearch',
            'versionCode'=>'3.9.2',
            'versionName'=>'3.9.2',
            'year'=> 2010,
            'director'=> '彼得·杰克逊',
            'actors'=> ' 伊恩·麦克莱恩 / 马丁·弗瑞曼 / 理查德·阿米蒂奇 / 本尼迪克特·康伯巴奇 / 奥兰多·布鲁姆 / 伊万杰琳·莉莉 / 李·佩斯 / 卢克·伊万斯 / 斯蒂芬·弗雷 / 肯·斯托特 / 詹姆斯·内斯比特 / 约翰·贝尔 / 马努·贝内特 / 杰德·布罗菲 / 亚当·布朗 / 约翰·凯伦 / 瑞安·盖奇 / 马克·哈德洛 / 彼得·汉布尔顿 / 斯蒂芬·亨特 / 威廉·基尔舍 / 西尔维斯特·迈可伊 / 格拉汉姆·麦克泰维什 / 迪恩·奥戈曼 / 米卡埃尔·佩斯布兰特 / 艾丹·特纳',
            'cover'=> 'http://upload.wikimedia.org/wikipedia/zh/thumb/9/9b/The_Hobbit_-_The_Desolation_of_Smaug_Teaser_Poster.jpg/220px-The_Hobbit_-_The_Desolation_of_Smaug_Teaser_Poster.jpg',
            'singer'=>'周杰伦',
            'lyricist'=>'方文山',
            'composer'=>'周杰伦'
        );

        $this->display('Content:update');
    }

    public function listPage($type=null) {
        $type = $type ? $type : 'soft';
        $this->type = $type;
        $this->typeName = $this->getTypeName($type);
        $this->display('Content:listPage');
    }

    public function getList() {
        echo('{"status": 1, "data": [{"uuid":"", "iconUrl": "xx", "name": "name", "package": "package", "versionCode": "versionCode", "versionName": "versionName", "category": "category", "price": "price", "status": 1}]}');
    }

    public function category($contentUuid=null) {
        echo('[{"id": "book", "name": "aaa"}, {"id": "finance", "name": "bbb"}]');
    }

    private function getTypeName($type) {
        $names = array(
            'soft' => '应用',
            'game' => '游戏',
            'video' => '视频',
            'music' => '音乐',
            'picture' => '图片'
        );
        return $names[$type];
    }

    public function upload($type,$inputName,$contentUuid) {
        echo(json_encode(array(
            '*files'=> $_FILES,
            '*inputName'=> $inputName,
            '*contentUuid'=> $contentUuid
        )));
    }

    public function uploadMain($type) {
        echo(json_encode(array(
            '*files'=> $_FILES,
            '*type'=> $type,
            'uuid'=> '0a14d489-9a16-11e3-b8f8-000c2943e406'
        )));
    }

    public function uploadForUpdate($type,$contentUuid){
        echo(json_encode(array(
            '*files'=> $_FILES,
            '*type'=> $type,
            '*contentUuid'=> $contentUuid
        )));
    }

    public function updatePost($contentUuid,$type,$data,$delPics=null,$categoryIds=null){
        echo($contentUuid);
        echo('<br />');
        echo($type);
        echo('<br />');
        echo(json_encode($data));
        echo('<br />');
        echo(json_encode($delPics));
        echo('<br />');
        echo(json_encode($categoryIds));
        echo('<br />');
    }

    public function exportPage($startDate=null, $endDate=null) {
        $this->startDate = '2014-01-03 12:00';
        $this->endDate = date("Y-m-d H:i");
        $this->display('Content:exportPage');
    }

    public function exportList($startDate, $endDate, $startIndex, $pageSize, $sort) {
        echo(json_encode(array(
            'total' => 10,
            'data' => array(
                array(
                    'type' => 'soft',
                    'iconUrl' => 'http://static.yingyonghui.com/icon/48/1506628.png',
                    'name' => '百度hao123上网导航',
                    'author' => 'xx',
                    'createTime' => '2014-02-01 12:00',
                    'updateTime' => '2014-02-01 12:00'
                ),
                array(
                    'type' => 'soft',
                    'iconUrl' => 'http://static.yingyonghui.com/icon/48/1564482.png',
                    'name' => '淘宝',
                    'author' => 'xx',
                    'createTime' => '2014-02-01 12:00',
                    'updateTime' => '2014-02-01 12:00'
                ),
                array(
                    'type' => 'soft',
                    'iconUrl' => 'http://static.yingyonghui.com/icon/48/1502443.png',
                    'name' => '天气通',
                    'author' => 'xx',
                    'createTime' => '2014-02-01 12:00',
                    'updateTime' => '2014-02-01 12:00'
                ),
                array(
                    'type' => 'game',
                    'iconUrl' => 'http://static.yingyonghui.com/icon/48/1561459.png',
                    'name' => '秦时明月',
                    'author' => 'xx',
                    'createTime' => '2014-02-01 12:00',
                    'updateTime' => '2014-02-01 12:00'
                ),
                array(
                    'type' => 'soft',
                    'iconUrl' => 'http://static.yingyonghui.com/icon/48/1569093.png',
                    'name' => '百度视频',
                    'author' => 'xx',
                    'createTime' => '2014-02-01 12:00',
                    'updateTime' => '2014-02-01 12:00'
                )
            )
        )));
    }

}
