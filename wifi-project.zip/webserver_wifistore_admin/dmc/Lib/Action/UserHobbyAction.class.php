<?php

/**
 * UserHobbyAction short summary.
 *
 * UserHobbyAction description.
 *
 * @version 1.0
 * @author Hank
 */
class UserHobbyAction extends AuthAction
{
    public function index() {
        include_once(ROOT . "/controller/getResponse.php");
        $userProperty = getFileContent('../data/UserProperty_hobby.json');
        $this->userProperty = $userProperty;

        $this->breadcrumb = array(
            array(
                'href' => U('Index/index'),
                'title' => '',
                'icon' => 'icon-home',
                'desc' => '首页'
            ),
            array(
                'href' => '#',
                'title' => '',
                'icon' => 'icon-user',
                'desc' => '用户属性'
            )
        );
        $this->display();
    }
}
