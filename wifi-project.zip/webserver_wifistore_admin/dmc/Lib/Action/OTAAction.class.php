<?php

class OTAAction extends Action{
    public function taskPage () {
        $this->display("OTA:taskPage");
    }

    public function cancelExport($uuid) {
        $task = $this->getOtaList($uuid);
        $this->stopTask($task);
    }


    public function getOtaList($startIndex=0,$pageSize=10,$sort/*null*/){
        include_once(ROOT . '/controller/conn.php');

        $querySql="select a.uuid,a.createTime,a.beginTime,a.endTime,a.status,a.fileName,b.userName from ota_record a,spUser b where a.author=b.uniqueId  ";
        if(!empty($sort)){
            $querySql=$querySql." order by $sort ";
        }
        $countSql = "select count(1) total from ota_record a,spUser b where a.author=b.uniqueId ";
        $querySql=$querySql."limit $startIndex,$pageSize";
        try {

            $result = mysql_query($countSql);
            $row = mysql_fetch_array($result);
            $response['total'] = $row['total'];

            $result=mysql_query($querySql);

            while ($row=mysql_fetch_array($result)) {



                $response['data'][]=array(
                        'uuid'=>$row['uuid'],
                        'createTime'=>$row['createTime'],
                        'beginTime'=>$row['beginTime'],
                        'endTime'=>$row['endTime'],
                        'status' =>$row['status'],
                        'filePath'=> '/ota/'.$row['uuid'].'/'.$row['fileName'],
                        'userName'=>$row['userName'],
                        'pid'=>$row['pid']
                    );
            }
            $response['status']=1000;
            echo(json_encode($response));
        } catch (Exception $e) {
            $response['status']=1001;
            throw new Exception("query ota_record exception sql error:".$querySql);
            echo(json_encode($response));
        }
    }

    public function rezip($uuid) {
        include_once(ROOT . '/controller/conn.php');
        $querySql="select a.uuid, a.beginTime,a.endTime,a.fileName from ota_record a where uuid='$uuid'";
        $result=mysql_query($querySql);
        $row = mysql_fetch_array($result);

        $startDate = $row['beginTime'];
        $endDate = $row['endTime'];
        $fileName = $row['fileName'];
        $uuid = $row['uuid'];

        if (OTAAction::removeOTAFile($fileName, $uuid) == TRUE) {
            $pid = ContentAction::makeOTAZip($uuid, $startDate, $endDate);
            $sql=sprintf("update ota_record set pid=%d where uuid='%s'", $pid,$uuid);
            mysql_query($sql);
            $response['status']=1000;
        } else {
            $response['status'] = 1001;
        }
        echo(json_encode($response));
    }

    public function cancelOTA($uuid) {
        include_once(ROOT . '/controller/conn.php');
        $querySql="select a.pid from ota_record a where uuid='$uuid'";
        $result = mysql_query($querySql);
        $row = mysql_fetch_array($result);
        $pid = $row['pid'];
        system("kill -9 $pid");

        try {
            $sql = "update ota_record set status=1002 where uuid='$uuid'";
            mysql_query($sql);
            $response['status']=1000;
        } catch (Exception $e) {
            $response['status']=1001;
        }
        echo(json_encode($response));
    }

    private static function removeOTAFile($fileName, $uuid) {
        $files = glob(ROOT . '/ota/' . $uuid . '/*');

        foreach($files as $file){
          if(is_file($file))
            unlink($file);
        }

        return TRUE;
    }
}
