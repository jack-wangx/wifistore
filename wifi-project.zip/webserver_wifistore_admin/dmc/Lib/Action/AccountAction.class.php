<?php


/**
 * Account short summary.
 *
 * Account description.
 *
 * @version 1.0
 * @author Hank
 */
class AccountAction extends Action {

    public function login() {




        if ($this->isPost()) {

            $this->dologin();
        } else {
            $this->display();
        }
    }



    private function dologin() {
        include_once(ROOT . "/controller/conn.php");
        include_once(ROOT . "/controller/permission/admin/aco_edit.php");
        include_once(ROOT . "/controller/gacl/admin/gacl_admin.inc.php");

        $lifeTime = 1 * 3600;
        session_set_cookie_params($lifeTime);
        $username= trim($_POST['username']);
        $password=md5(trim($_POST['password']));

        $solutionProvider = $_SERVER['HTTP_REFERER'];

        $solutionProvider = 'http://yinni.longfota.org/login';
        preg_match('@^(?:http://)?([^.]+)@i', $solutionProvider, $matches);
        $solutionProvider = $matches[1];

        $rs="select * from spUser where userName = '$username' and solutionProvider = '$solutionProvider'";

        $result=mysql_query($rs);
        if(count($result)==1){

            while ($row=mysql_fetch_array($result)) {

                if ($row["password"]==$password)
                {
                    $_SESSION["userName"] = $row["userName"];
                    $_SESSION["userId"] = $row["Id"];
                    $_SESSION["solutionProvider"] = $row["solutionProvider"];
                    $_SESSION["groupId"] = $row["groupId"];
                    $_SESSION["uniqueId"] = $row["uniqueId"];
                    $group_data=$gacl_api->get_group_data($row["groupId"],'ARO');

                    if(empty($group_data)){
                        return false;
                    }
                    $num=2;

                    if(strcasecmp($group_data[3], $row["solutionProvider"].'_admin')==0){
                        $group_admin_id=$row["groupId"];
                        $num=1;
                    }else{
                        $group_parent_id=$gacl_api->get_group_parent_id($row["groupId"],'ARO');

                        $group_parent_data=$gacl_api->get_group_data($group_parent_id,'ARO');

                        if(empty($group_parent_data)){
                            return false;
                        }
                        $group_admin_name=$row["solutionProvider"].'_user';

                        $group_admin_id=$this->getGroupId($group_admin_name);


                        if(strcasecmp($group_parent_data[3], $row["solutionProvider"].'_user')==0){
                            $num=2;

                        }else{
                            $num=3;

                        }
                    }

                    $_SESSION["content"]=0;
                    $_SESSION["statistics"]=0;
                    $_SESSION["permission"]=0;

                    for($i=0;$i<$num;$i++){

                        if($i==0){
                            $groupId=$group_admin_id;
                        }elseif($i==1){
                            if($num==2){
                                $groupId=$_SESSION["groupId"];
                            }
                            if($num==3){
                                $groupId=$group_parent_id;
                            }

                        }elseif ($i==2) {
                            $groupId=$_SESSION["groupId"];
                        }else{
                            return;
                        }

                        $acoList=getAcoList($groupId,null);

                        for($j=0;$j<count($acoList);$j++){
                            $acoArray=$acoList[$j];
                            $name=$acoArray['name'];
                            $allow=$acoArray['allow'];
                            $_SESSION[$name]=$allow;
                        }
                    }

                    echo  json_encode(array('status'  => 0));
                } else {
                    echo  json_encode(array('status'  => 1));
                }
            }

        }else {
            echo  json_encode(array('status'  => 2));
        }
    }

    private function getGroupId($group_name){
            $sql_get_group_name="select id from long_aro_groups where name='$group_name'";

            $result=mysql_query($sql_get_group_name);
            if(mysql_num_rows($result)>0){
                $rows=mysql_fetch_array($result);
                return $rows['id'];
            }else{
                return null;
            }
    }

    public function logout() {
        session_unset();
        session_destroy();
        $this->redirect("Account/login");
    }
}
