<?php
	class ApkUtil{

		 /**
	     *
	     * 需要exec支持
	     * @var $apk_file APK文件路径，可以是HTTP形式
	     * @var $get_icon 是否提取APK文件中的ICON图标,默认不提取
	     * @author admclub.com
	     */
	    public function readApkInfoFromFile($apk_file,$get_icon=flase,$folderPath){
	    	/*
				$aapt变量定义到设置文件中
	    	*/
	        $aapt = 'aapt';
	        if(substr($apk_file, 0,7)=='http://'){
	            $tmp_apk = "/tmp/".md5(microtime()).".apk";

	            exec('/usr/bin/wget '.$apk_file.' -O '.$tmp_apk." -t 1",$_out,$_return);

	            if(filesize($tmp_apk)>0){
	                $apk_file = $tmp_apk;
	            }
	        }

	       exec("{$aapt} d badging {$apk_file}",$out,$return);

	       if($return==0){
	            $str_out = implode("\n", $out);
	            $out = null;

	            #icon
	            if($get_icon){
	                $pattern_icon = "/icon='(.+)'/isU";
	                preg_match($pattern_icon, $str_out,$m);
	                $info['icon']= $m[1];
	                if($info['icon']){

	                    if($tmp_apk){
	                        $command = "unzip {$tmp_apk} {$info['icon']} -d $folderPath";
	                    }
	                    else{
	                        $command = "unzip {$apk_file} {$info['icon']} -d $folderPath";
	                    }
	                    // $this->mkdirs($folderPath.'/'.$info['icon'].'/../');
	                    exec($command);

	                }
	            }

	            #对外显示名称
	            $pattern_name = "/application: label='(.*)'/isU";
	            preg_match($pattern_name, $str_out,$m);
	            $info['lable']=$m[1];

	            #内部名称,软件唯一的
	            $pattern_sys_name = "/package: name='(.*)'/isU";
	            preg_match($pattern_sys_name, $str_out,$m);
	            $info['packageName']=$m[1];

	            #内部版本名称,用于检查升级
	            $pattern_version_code = "/versionCode='(.*)'/isU";
	            preg_match($pattern_version_code, $str_out,$m);
	            $info['version_code']=$m[1];

	            #对外显示的版本名称
	            $pattern_version = "/versionName='(.*)'/isU";
	            preg_match($pattern_version, $str_out,$m);
	            $info['versionName']=$m[1];

	            #系统
	            $pattern_sdk = "/sdkVersion:'(.*)'/isU";
	            preg_match($pattern_sdk, $str_out,$m);
	            $info['sdk_version']=$m[1];
	            if($info['sdk_version']){
	                $sdk_names = array(3=>"1.5",4=>"1.6",7=>"2.1",8=>"2.2",10=>'2.3.3',11=>"3.0",12=>"3.1",13=>"3.2",14=>"4.0");
	                if($sdk_names[$info['sdk_version']]){
	                    $info['os_req'] = "Android {$sdk_names[$info['sdk_version']]}";
	                }
	            }

	             #权限
	            $pattern_perm = "/uses-permission:'(.*)'/isU";
	            preg_match_all($pattern_perm, $str_out,$m);
	            if($m){
	                $cnt = count($m[1]);
	                for($i=0;$i<$cnt;$i++){
	                    $info['permissions'] .= $info['permissions']?"\n".$m[1][$i]:$m[1][$i];
	                }
	            }

	            #需要的功能(硬件支持)
	            $pattern_features = "/uses-feature:'(.*)'/isU";
	            preg_match_all($pattern_features, $str_out,$m);
	            if($m){
	                $cnt = count($m[1]);
	                for($i=0;$i<$cnt;$i++){
	                    $info['features'] .= $info['features']?"\n".$m[1][$i]:$m[1][$i];
	                }
	            }

	            $info['apk_info'] = $str_out;

	            if($tmp_apk){unlink($tmp_apk);}

	            return $info;
	        }

	        if($tmp_apk){unlink($tmp_apk);}
	    }

	    function mkdirs($path, $lastoneisfile = false, $rights = 0755) {

		    if (trim ( $path ) == '')
		    return;

		    if (! $lastoneisfile && substr ( $path, - 1 ) != '/') {
		        $path = $path . "/";
		    }
		    if (is_dir ( $path )) {
		        return true;
		    } //found it!
		    $path = str_replace ( "\\", "/", $path );
		    $path = preg_replace ( '/\/+/i', '/', $path );
		    $pathes = explode ( '/', $path );
		    $cnt = count ( $pathes ) - 1;
		    $dir = current ( $pathes ) . "/";
		    if (! is_dir ( $dir . "/" )) {
		        mkdir ( $dir );
		    }
		    for($i = 0; $i < $cnt; $i ++) {
		        if (! is_dir ( $dir . "/" )) {
		            @mkdir ( $dir );
		            @chmod ( $dir, $rights );
		        }
		        $dir .= next ( $pathes ) . "/";
		    }
		}

	}
