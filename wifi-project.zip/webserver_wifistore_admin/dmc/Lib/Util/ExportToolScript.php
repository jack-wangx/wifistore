<?php

    // $args=print_r($argv);
    // return;
    $ota_path=$argv[1];

    $root_path=$argv[2];// $root_path=ROOT.'/upload/';

    $startDate=str_replace('|', ' ', $argv[3]);
    $endDate=str_replace('|', ' ', $argv[4]);
    $uuid=$argv[5];

    if(empty($ota_path) or empty($root_path) or empty($startDate) or empty($endDate) or empty($uuid) ){
        echo 'param null';
        return;
    }


    $zip_name=time().'.zip';
    $zip_path=$ota_path.$zip_name;
    $sql_script_name=time().'_sqlite.sql';
    $shell_script_name=time().'_delete.sh';
    $sql_script=$ota_path.$sql_script_name;
    $shell_script=$ota_path.$shell_script_name;

    $tns=array("game",'soft','picture', "music", "video");

    $connConfig = $root_path . '../controller/conn.php';
    include_once($connConfig);
    // system("echo " . json_encode($conn) . " >> /tmp/log.txt");
    // $conn = @mysql_connect("192.168.7.217","root","99001122");
    // if (!$conn){
    //     echo 'faild';
    //     die("连接数据库失败：" . mysql_error());
    //     return;
    // }
    // mysql_select_db("wifi-store", $conn);
    // mysql_query("set names 'utf8'");

    $exportTool=new ExportTool($conn,$root_path,$ota_path,$tns,$zip_path,$sql_script,$shell_script);
    //首次更新
    $exportTool->updateDb($uuid,999,$zip_name);

    $shellStatus=$exportTool->write_shell_to_script($startDate,$endDate);
    $sqlStatus=$exportTool->write_sql_to_script($startDate,$endDate);

    if( $shellStatus && $sqlStatus){

        $arr=$exportTool->makeExportZip($startDate, $endDate,$sql_script_name,$shell_script_name);
        // $exportTool->makeScriptToZip($sql_script,$shell_script);

        $response['status']=$arr['status'];
        $response['errMsg']=$arr['errMsg'];
        $exportTool->updateDb($uuid,$response['status'],$zip_name);

    }else{
        $response['status']=1002;
        $response['errMsg']='mkzip error';
        $exportTool->updateDb($uuid,$response['status'],$zip_name);
    }

    class ExportTool{
        var $tns;//table names 数组
        var $root_path ;//资源路径 相当于upload文件夹的路径
        var $zip_path;//生成压缩包的全路径
        var $sql_script;//SQL语句的脚本存放地址
        var $shell_script ;//删除内容的脚本存放地址
        var $ota_path;

        var $conn;

        public function __construct($conn,$root_path,$ota_path,$tns,$zip_path,$sql_script,$shell_script){    //初始化对象，将初始化值放在括号内
            $this->tns=$tns;
            $this->root_path=$root_path;
            $this->zip_path=$zip_path;
            $this->sql_script=$sql_script;
            $this->shell_script=$shell_script;
            $this->conn=$conn;
            $this->ota_path=$ota_path;

        }

        public function updateDb($uuid,$status,$zip_name){
            $sql=sprintf('update ota_record set status=' . $status . ',fileName="' . $zip_name . '" where uuid="' . $uuid . '"');
            $result = mysql_query($sql, $this->conn);
        }

        public function makeScriptToZip($sql_script,$shell_script){
            $pwd = getcwd();
            $zipfile = new ZipArchive();
            if ( ($ret = $zipfile->open($this->zip_path, ZipArchive::CREATE)) != TRUE ) {
                chdir($pwd);
                $response['status']=1001;
                $response['errMsg']='cannot create zip file';

                return $response;
            }

            $zipfile->addFile($sql_script);

            $zipfile->addFile($shell_script);
            $zipfile->close();
            chdir($pwd);

        }

        public function makeExportZip($startDate, $endDate,$sql_script,$shell_script) {


            $pwd = getcwd();
            chdir($this->root_path);
            $zipfile = new ZipArchive();
            if ( ($ret = $zipfile->open($this->zip_path, ZipArchive::CREATE)) != TRUE ) {
                chdir($pwd);
                $response['status']=1001;
                $response['errMsg']='cannot create zip file';
                return $response;
            }


            foreach ($this->tns as $tn) {

                $sql = $this->get_insert_sql($tn, $startDate, $endDate);


                $records = $this->query($sql, $this->conn);

                $this->do_zip($tn, $records, $zipfile);
            }

            chdir($this->ota_path);

            $zipfile->addFile($sql_script);

            $zipfile->addFile($shell_script);

            $zipfile->close();
            chdir($pwd);
            return array('status'=>1000);
        }

        public function write_shell_to_script($start, $end) {

            $shell = $this->get_shell_script($start, $end);


            $file = fopen($this->shell_script, "w");

            if ( $file == null ) {
                return false;
            }
            else {
                fwrite($file, $shell . "\n");
                fclose($file);
                return true;
            }
        }

        public function write_sql_to_script($start, $end) {

            $all_sqls = $this->get_all_sqls($start, $end);



            $file = fopen($this->sql_script, "w");
            if ( $file == null ) {
                return false;
            }
            else {
                foreach ($all_sqls as $sql) {
                    fwrite($file, $sql . "\n");
                }
                fclose($file);
                return true;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        function get_all_sqls($start, $end) {
            // $apps = $this->select_match_app_record($start, $end);
            $games= $this->getAppRecordByType('game',$start,$end);
            $softs= $this->getAppRecordByType('soft',$start,$end);
            $musics = $this->select_match_music_record($start, $end);
            $videos = $this->select_match_video_record($start, $end);
            $pictures= $this ->getPictureRecords($start,$end);
            // echo count($games).';'.count($softs).';'.count($musics).';'.count($videos).';'.count($pictures);

            $content_categorys = $this->copy_content_categorys_table();
            $category = $this->copy_category_table();
            $all_sqls = array_merge($games,$softs, $musics, $videos,$pictures,$category, $content_categorys);
            return $all_sqls;
        }

        function get_shell_script($start, $end) {


            $script = "#!/bin/ash\n";
            foreach ($this->tns as $tn) {
                $sql = $this->get_delete_sql($tn, $start, $end);
                $records = $this->query($sql, $this->conn);
                $shell = $this->get_shell_command($records);
                $script .= $shell . "\n";
            }

            return $script;
        }

        function app_record_to_sql($record) {
            $sql = sprintf(" REPLACE INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updatetime, flag, contentUuid, packageName, versionCode, versionName, picsUrl) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', '%s', '%s', '%s') ;", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updatetime"], $record["flag"], $record["contentUuid"], $record["packageName"], $record["versionCode"], $record["versionName"], $record["picsUrl"]);
            return $sql;
        }

        function getAppRecordByType($type,$start,$end){

            $sql="select * from category where categoryName='$type'";
            $rows=$this->query($sql, $this->conn);
            // echo json_encode($rows[0]['categoryId']);
            $categoryId=$rows[0]['categoryId'];

            $sql = sprintf("select * from content a inner join app b on a.contentUuid=b.contentUuid inner join content_categorys c on a.contentUuid=c.contentUuid where c.categoryId='%s' and a.updatetime >='%s:00' and a.updatetime <= '%s:00'", $categoryId,$start, $end);
            // echo $sql.';';
            $records = $this->query($sql, $this->conn);
            $sqls = array();
            foreach ($records as $record) {
                $sqls[] = $this->app_record_to_sql($record);
            }

            return $sqls;
        }

        function getPictureRecords($start,$end){
            $sql="select * from category where categoryName='picture'";

            $rows=$this->query($sql, $this->conn);

            $categoryId=$rows[0]['categoryId'];

            $sql = sprintf("select * from content a inner join content_categorys c on a.contentUuid=c.contentUuid where c.categoryId='%s' and a.updatetime >='%s:00' and a.updatetime <= '%s:00'", $categoryId,$start, $end);
            // echo $sql;
            $records = $this->query($sql, $this->conn);
            $sqls = array();
            foreach ($records as $record) {
                $sqls[] = $this->app_record_to_sql($record);
            }

            return $sqls;
        }

        function select_match_app_record($start, $end) {

            $sql = sprintf("select * from content a inner join app b on a.contentUuid=b.contentUuid and a.updatetime >='%s:00' and a.updatetime <= '%s:00'", $start, $end);

            $records = $this->query($sql, $this->conn);
            $sqls = array();
            foreach ($records as $record) {
                $sqls[] = $this->app_record_to_sql($record);
            }

            return $sqls;
        }

        function video_record_to_sql($record) {
            $sql = sprintf(" REPLACE INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updateTime, flag, contentUuid, year, director, actors, picsUrl, cover) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', %d, '%s', '%s', '%s', '%s') ;", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updateTime"], $record["flag"], $record["contentUuid"], $record["year"], $record["director"], $record["actors"], $record["picsUrl"], $record["cover"]);
            return $sql;
        }

        function select_match_video_record($start, $end) {

            $sql = sprintf("select * from content a inner join video b on a.contentUuid=b.contentUuid and a.updatetime >='%s:00' and a.updatetime <= '%s:00'", $start, $end);

            $records = $this->query($sql, $this->conn);
            $sqls = array();
            foreach ($records as $record) {
                $sqls[] = $this->video_record_to_sql($record);
            }

            return $sqls;
        }

        function music_record_to_sql($record) {
            $sql = sprintf(" REPLACE INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updatetime, flag, contentUuid, singer, year, lyricist, composer, cover) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', %d, '%s', '%s', '%s') ;", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updatetime"], $record["flag"], $record["contentUuid"], $record["singer"], $record["year"], $record["lyricist"], $record["composer"], $record["cover"]);
            return $sql;
        }

        function select_match_music_record($start, $end) {

            $sql = sprintf("select * from content a inner join music b on a.contentUuid=b.contentUuid and a.updatetime >='%s:00' and a.updatetime <= '%s:00'", $start, $end);

            $records = $this->query($sql, $this->conn);
            $sqls = array();
            foreach ($records as $record) {
                $sqls[] = $this->music_record_to_sql($record);
            }

            return $sqls;
        }


        function content_record_to_sql($record) {

            $sql = sprintf("INSERT INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updatetime, flag, contentUuid) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s');", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updatetime"], $record["flag"], $record["contentUuid"]);

            return $sql;
        }

        function copy_content_table() {

            $sqls = array();

            $records = $this->query("select * from content", $this->conn);
            foreach ($records as $record) {
                $sqls[] = $this->content_record_to_sql($record);
            }

            return $sqls;
        }

        function content_categorys_record_to_sql($record) {
            $sql = sprintf("INSERT INTO content_categorys (categoryId, contentUuid) VALUES ('%s', '%s');", $record["categoryId"], $record["contentUuid"]);
            return $sql;
        }

        function category_record_to_sql($record){
            $sql = sprintf("INSERT INTO category (categoryId,categoryName,parentId) VALUES ('%s', '%s','%s');", $record["categoryId"], $record["categoryName"],$record["parentId"]);
            return $sql;
        }

        function copy_content_categorys_table() {

            $sqls = array();

            $records = $this->query("select * from content_categorys", $this->conn);

            foreach ($records as $record) {
                $sqls[] = $this->content_categorys_record_to_sql($record);
            }

            return $sqls;
        }

        function copy_category_table() {

            $sqls = array();

            $records = $this->query("select * from category", $this->conn);
            $sqls[]="delete from category;";
            foreach ($records as $record) {
                $sqls[] = $this->category_record_to_sql($record);
            }

            return $sqls;
        }

        function get_insert_sql($tn, $start, $end) {
            $sql="select * from category where categoryName='$tn'";
            $rows=$this->query($sql, $this->conn);

            $categoryId=$rows[0]['categoryId'];


            if($tn==='game' or $tn==='soft'){

                $sql=sprintf("select * from content a inner join app b on a.contentUuid=b.contentUuid inner join content_categorys c on a.contentUuid=c.contentUuid where c.categoryId='%s' and a.updateTime>='%s:00' and a.updatetime <= '%s:00' and a.flag <> 2",$categoryId,$start, $end);
            }else if($tn==='picture'){
                $sql=sprintf("select * from content a inner join content_categorys b on a.contentUuid=b.contentUuid where b.categoryId='%s' and a.updateTime>='%s:00' and a.updatetime <= '%s:00' and a.flag <> 2",$categoryId,$start, $end);
            }else{
                $sql=sprintf("select * from content a inner join %s b on a.contentUuid=b.contentUuid inner join content_categorys c on a.contentUuid=c.contentUuid where c.categoryId='%s' and a.updateTime>='%s:00' and a.updatetime <= '%s:00' and a.flag <> 2",$tn,$categoryId,$start, $end);

            }


            return $sql;
        }

        function get_delete_sql($tn) {
            $sql = sprintf("select * from content, %s where content.contentUuid = %s.contentUuid and content.flag <> 2", $tn, $tn);
            return $sql;
        }

        function get_shell_command($records) {
            $shell = null;
            foreach ($records as $record) {
                $shell = "rm -rf $1/" . $record["contentUuid"];
            }
            return $shell;
        }

        function connect($ip, $user, $passwd) {
            $conn = mysql_connect($ip, $user, $passwd);
            return $conn;
        }

        function select_db($db, $conn) {
            mysql_select_db($db, $conn);
        }

        function query($sql, $conn) {

            $ret = array();
            $result = mysql_query($sql, $conn);

            while ( ($row = mysql_fetch_array($result)) != null ) {
                $ret[] = $row;
            }
            return $ret;
        }

        function addFileToZip($path, $zip){
            $handler = opendir($path);

            while( ($filename = readdir($handler)) !== false ) {

                if( $filename != "." && $filename != ".." ) {
                    if( is_dir($path . "/" . $filename) ) {
                        //$filename = iconv("", "UTF-8", $filename);
                        $this->addFileToZip($path . "/" . $filename, $zip);
                    }
                    else {
                        $zip->addFile($path . "/" . $filename);
                    }
                }
            }
            @closedir($path);
        }

        function do_zip($tn, $records, $zipfile) {

            foreach ($records as $record) {

                $path = $tn .'/'. $record["contentUuid"];
                if ( is_dir($path) == FALSE ) {

                    continue;
                }
                $this->addFileToZip($path, $zipfile);
            }
        }
    }

