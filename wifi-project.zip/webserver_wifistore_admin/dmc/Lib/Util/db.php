<?php
$ip = "localhost";
$db = "wifi-store";
$user = "root";
$passwd = "99001122";
$tns = array("app", "music", "video");//table name
$root_path = "/home/crocodile/Desktop";//资源路径 相当于upload文件夹的路径
$zip_name = "/home/crocodile/Desktop/z.zip";//生成压缩包的全路径
$sql_script = "/home/crocodile/Desktop/sqlite.sql";
$shell_script = "/home/crocodile/Desktop/delete.sh";
test();
function test() {
  var_dump(get_all_sqls("0", "10000000"));
  var_dump(get_shell_script("0", "10000000"));
  write_sql_to_script("0", "1000000000000000000");
  write_shell_to_script("0", "1000000000000000000");
  echo 'sisksi';
}

function makeExportZip($startDate, $endDate) {
    global $ip, $user, $passwd, $db;
    $pwd = getcwd();
    chdir($root_path);
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        chdir($pwd);
        return "{status:0, errMsg: 'cannot not connect to mysql'}";
    }
    select_db($db, $conn);
    $zipfile = new ZipArchive();
    if ( $zipfile->open($zip_name, ZipArchive::OVERWRITE) != true ) {
        chdir($pwd);
        return "{status:0, errMsg: 'cannot create zip file'}";
    }
    foreach ($tns as $tn) {
        $sql = get_insert_sql($tn, $start, $end);
        $records = query($sql, $conn);
        do_zip($tn, $records, $zipfile);
    }
    $zipfile->close();
    mysql_close($conn);
    chdir($pwd);
    return "{status:1}";
}

function write_shell_to_script($start, $end) {
    global $shell_script;
    $shell = get_shell_script($start, $end);
    $file = fopen($shell_script, "w");
    if ( $file == null ) {
        return false;
    }
    else {
        fwrite($file, $shell . "\n");
        fclose($file);
        return true;
    }
}

function write_sql_to_script($start, $end) {
    global $sql_script;
    $all_sqls = get_all_sqls($start, $end);
    $file = fopen($sql_script, "w");
    if ( $file == null ) {
        return false;
    }
    else {
        foreach ($all_sqls as $sql) {
            fwrite($file, $sql . "\n");
        }
        fclose($file);
        return true;
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_all_sqls($start, $end) {
    $apps = select_match_app_record($start, $end);
    $musics = select_match_music_record($start, $end);
    $videos = select_match_video_record($start, $end);

    $content_categorys = copy_content_categorys_table();
    $category = copy_category_table();
    $all_sqls = array_merge($apps, $musics, $videos,$category, $content_categorys);
    return $all_sqls;
}

function get_shell_script($start, $end) {
    global $ip, $user, $passwd, $db, $tns;
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        return "{status:0, errMsg: 'cannot not connect to mysql'}";
    }
    select_db($db, $conn);
    $script = "#!/bin/ash\n";
    foreach ($tns as $tn) {
        $sql = get_delete_sql($tn, $start, $end);
        $records = query($sql, $conn);
        $shell = get_shell_command($records);
        $script .= $shell . "\n";
    }
    mysql_close($conn);
    return $script;
}

function app_record_to_sql($record) {
    $sql = sprintf(" REPLACE INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updateTime, flag, contentUuid, packageName, versionCode, versionName, picsUrl) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', '%s', '%s', '%s') ;", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updateTime"], $record["flag"], $record["contentUuid"], $record["packageName"], $record["versionCode"], $record["versionName"], $record["picsUrl"]);
    return $sql;
}

function select_match_app_record($start, $end) {
    global $ip, $user, $passwd, $db;
    $sql = sprintf("select * from content a inner join app b on a.contentUuid=b.contentUuid and a.updateTime >=UNIX_TIMESTAMP('%s:00') and a.updateTime <= UNIX_TIMESTAMP('%s:00')", $start, $end);
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        return "";
    }
    select_db($db, $conn);
    $records = query($sql, $conn);
    $sqls = array();
    foreach ($records as $record) {
        $sqls[] = app_record_to_sql($record);
    }
    mysql_close($conn);
    return $sqls;
}

function video_record_to_sql($record) {
    $sql = sprintf(" REPLACE INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updateTime, flag, contentUuid, year, director, actors, picsUrl, cover) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', %d, '%s', '%s', '%s', '%s') ;", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updateTime"], $record["flag"], $record["contentUuid"], $record["year"], $record["director"], $record["actors"], $record["picsUrl"], $record["cover"]);
    return $sql;
}

function select_match_video_record($start, $end) {
    global $ip, $user, $passwd, $db;
    $sql = sprintf("select * from content a inner join video b on a.contentUuid=b.contentUuid and a.updateTime >=UNIX_TIMESTAMP('%s:00') and a.updateTime <= UNIX_TIMESTAMP('%s:00')", $start, $end);
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        return "";
    }
    select_db($db, $conn);
    $records = query($sql, $conn);
    $sqls = array();
    foreach ($records as $record) {
        $sqls[] = video_record_to_sql($record);
    }
    mysql_close($conn);
    return $sqls;
}

function music_record_to_sql($record) {
    $sql = sprintf(" REPLACE INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updateTime, flag, contentUuid, singer, year, lyricist, composer, cover) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', %d, '%s', '%s', '%s') ;", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updateTime"], $record["flag"], $record["contentUuid"], $record["singer"], $record["year"], $record["lyricist"], $record["composer"], $record["cover"]);
    return $sql;
}

function select_match_music_record($start, $end) {
    global $ip, $user, $passwd, $db;
    $sql = sprintf("select * from content a inner join music b on a.contentUuid=b.contentUuid and a.updateTime >=UNIX_TIMESTAMP('%s:00') and a.updateTime <= UNIX_TIMESTAMP('%s:00')", $start, $end);
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        return "";
    }
    select_db($db, $conn);
    $records = query($sql, $conn);
    $sqls = array();
    foreach ($records as $record) {
        $sqls[] = music_record_to_sql($record);
    }
    mysql_close($conn);
    return $sqls;
}


function content_record_to_sql($record) {

    $sql = sprintf("INSERT INTO content (name, size, price, filePath, iconUrl, description, createtime, tag, author, updateTime, flag, contentUuid) VALUES ('%s', %d, %d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %d, '%s');", $record["name"], $record["size"], $record["price"], $record["filePath"], $record["iconUrl"], $record["description"], $record["createtime"], $record["tag"], $record["author"], $record["updateTime"], $record["flag"], $record["contentUuid"]);

    return $sql;
}

function copy_content_table() {
    global $ip, $user, $passwd, $db;
    $sqls = array();
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        return "";
    }
    select_db($db, $conn);
    $records = query("select * from content", $conn);
    foreach ($records as $record) {
        $sqls[] = content_record_to_sql($record);
    }
    mysql_close($conn);
    return $sqls;
}

function content_categorys_record_to_sql($record) {
    $sql = sprintf("INSERT INTO content_categorys (categoryId, contentUuid) VALUES ('%s', '%s');", $record["categoryId"], $record["contentUuid"]);
    return $sql;
}

function category_record_to_sql($record){
    $sql = sprintf("INSERT INTO category (categoryId,categoryName,parentId) VALUES ('%s', '%s','%s');", $record["categoryId"], $record["categoryName"],$record["parentId"]);
    return $sql;
}

function copy_content_categorys_table() {
    global $ip, $user, $passwd, $db;
    $sqls = array();
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        return "";
    }
    select_db($db, $conn);
    $records = query("select * from content_categorys", $conn);
    $sqls[]="delete from content_categorys;";
    foreach ($records as $record) {
        $sqls[] = content_categorys_record_to_sql($record);
    }
    mysql_close($conn);
    return $sqls;
}

function copy_category_table() {
    global $ip, $user, $passwd, $db;
    $sqls = array();
    $conn = connect($ip, $user, $passwd);
    if ( !$conn ) {
        return "";
    }
    select_db($db, $conn);
    $records = query("select * from category", $conn);
    $sqls[]="delete from category;";
    foreach ($records as $record) {
        $sqls[] = category_record_to_sql($record);
    }
    mysql_close($conn);
    return $sqls;
}

function get_insert_sql($tn, $start, $end) {
    $sql = sprintf("select * from content, %s where content.contentUuid = %s.contentUuid and a.updateTime >=UNIX_TIMESTAMP('%s:00') and a.updateTime <= UNIX_TIMESTAMP('%s:00') and content.flag <> 2", $tn, $tn, $start, $end);
    return $sql;
}

function get_delete_sql($tn) {
    $sql = sprintf("select * from content, %s where content.contentUuid = %s.contentUuid and content.flag <> 2", $tn, $tn);
    return $sql;
}

function get_shell_command($records) {
    $shell = null;
    foreach ($records as $record) {
        $shell = "rm -rf $1/" . $record["contentUuid"];
    }
    return $shell;
}

function connect($ip, $user, $passwd) {
    $conn = mysql_connect($ip, $user, $passwd);
    return $conn;
}

function select_db($db, $conn) {
    mysql_select_db($db, $conn);
}

function query($sql, $conn) {
    $ret = array();
    $result = mysql_query($sql, $conn);
    while ( ($row = mysql_fetch_array($result)) != null ) {
        $ret[] = $row;
    }
    return $ret;
}

function addFileToZip($path, $zip){
    $handler = opendir($path);
    while( ($filename = readdir($handler)) !== false ) {
        if( $filename != "." && $filename != ".." ) {
            if( is_dir($path . "/" . $filename) ) {
                addFileToZip($path . "/" . $filename, $zip);
            }
            else {
                $zip->addFile($path . "/" . $filename);
            }
        }
    }
    @closedir($path);
}

function do_zip($tn, $records, $zipfile) {
    foreach ($records as $record) {
        $path = $tn . $record["contentUuid"];
        addFileToZip($path, $zipfile);
    }
}





