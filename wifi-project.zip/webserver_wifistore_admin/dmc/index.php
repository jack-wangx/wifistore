<?php
define('APP_DEBUG', TRUE);
define('ROOT', dirname(__FILE__) . '/..');
require '../ThinkPHP/ThinkPHP.php';

return;

