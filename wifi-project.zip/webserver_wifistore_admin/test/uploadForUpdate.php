<html>
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <form class="form-horizontal" action="http://192.168.209.130:5001/dmc/index.php/Content/uploadForUpdate"
    method="post" id="addSoft" enctype="multipart/form-data">
    <input type="hidden" name="contentUuid" id="softUUID" data-auto="true" />
    <fieldset>
      <legend>填写应用信息</legend>
      <div class="control-group">
        <label class="control-label" for="softName">应用名称</label>
        <div class="controls">
          <input name="type" value="soft" />
          <input name="contentUuid" value="691dffc4-b51f-0df8-0f67-49550185454d"/>

        </div>
      </div>
      <div class="control-group">
        <label class="control-label" for="softFile">应用文件</label>
        <div class="controls">
          <span class="btn fileinput-button">
            <i class="icon-folder-close"></i>
            <span id="softFileName">选择文件...</span>
            <input id="file" type="file" name="file" >
          </span>
        </div>
      </div>

    </fieldset>
    <input type="submit" value="submit"/>
  </form>
</div>
</body>
</html>

