<html>
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <form class="form-horizontal" action="http://192.168.209.130:5001/dmc/index.php/Content/updatePost"
    method="post" id="addSoft" enctype="multipart/form-data">
    <input type="hidden" name="contentUuid" id="softUUID" data-auto="true" />
    <fieldset>
      <legend>填写应用信息</legend>
      <div class="control-group">
        <label class="control-label" for="softName">应用名称</label>
        <div class="controls">
          <input name="type" value="game" />
          <input name="contentUuid" value="80c51f88-4734-d357-66a7-609b58544a6e"/>
          <input name="data" value="{}"/>
          <input name="delPics" value="[]"/>
          <input name="categoryIds" value="[]"/>
        </div>
      </div>


    </fieldset>
    <input type="submit" value="submit"/>
  </form>
</div>
</body>
</html>

