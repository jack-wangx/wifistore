<html>
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <form class="form-horizontal" action="http://192.168.209.130:5001/dmc/index.php/Content/category"
    method="post" id="addSoft" enctype="multipart/form-data">
    <input type="hidden" name="contentUuid" id="softUUID" data-auto="true" />
    <fieldset>
      <legend>填写应用信息</legend>
      <div class="control-group">
        <label class="control-label" for="softName">category test</label>
        <div class="controls">
          <input name="categoryId" value="0a14d489-9a16-11e3-b8f8-000c2943e406" />

        </div>
      </div>


    </fieldset>
    <input type="submit" value="submit"/>
  </form>
</div>
</body>
</html>

