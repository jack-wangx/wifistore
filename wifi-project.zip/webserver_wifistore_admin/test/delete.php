<html>
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <form class="form-horizontal" action="http://192.168.209.130:5001/dmc/index.php/Content/delete"
    method="post" id="addSoft" enctype="multipart/form-data">
    <input type="hidden" name="contentUuid" id="softUUID" data-auto="true" />
    <fieldset>
      <legend>填写应用信息</legend>
      <div class="control-group">
        <label class="control-label" for="softName">delete content</label>
        <div class="controls">

          <input name="contentUuid" value="691dffc4-b51f-0df8-0f67-49550185454d"/>

        </div>
      </div>


    </fieldset>
    <input type="submit" value="submit"/>
  </form>
</div>
</body>
</html>

