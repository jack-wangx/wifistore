/**
 * 将json数据处理成jquery.DataTable控件需要的格式
 * @param  {json} data 后台返回的原始json对象
 * @return {json} jquery.DataTable需要的json格式 [look here](www.datatables.net/usage/server-side)
 */
var preprocessData = function (response) {
    var result = {
        aaData: response.data,
        iTotalRecords: response.total,
        iTotalDisplayRecords: response.total
    };
    return result;
};

(function () {
    var dataTable = $('#contentTable').dataTable({
        "bJQueryUI": true,
        "sPaginationType": "full_numbers",
        "sDom": 't<"F"ip>',
        'sAjaxSource': ROOT + '/OTA/getOtaList',
        'bServerSide': true,
        'iDisplayLength': 20,
        'fnServerParams': function (params) {
            paramsMap = params.reduce(function (result, item) {
                result[item.name] = item.value;
                return result;
            }, {});
            params.push({name: 'startIndex', value: paramsMap.iDisplayStart || 0});
            params.push({name: 'pageSize', value: paramsMap.iDisplayLength});
            for (var i = 0; i < params.length; i++) {
                var item = params[i];
                if (item.name.indexOf('iSortCol') != -1) {
                    var colIndex = item.value;
                    if (paramsMap['bSortable_' + colIndex]) {
                        var sortIndex = item.name.split('_')[1];
                        var sortDir = paramsMap['sSortDir_' + sortIndex];
                        var filedName = paramsMap['mDataProp_' + colIndex];
                        params.push({name: 'sort', value: filedName + ' ' + sortDir});
                        break;
                    }
                }
            }
        },
        "fnServerData": function (url, params, fnCallback, oSettings) {
            var timerId = setTimeout(function () {
                NProgress.set(Math.random() * 0.4);
                NProgress.inc();
            }, 300);
            oSettings.jqXHR = $.ajax({
                "dataType": 'json',
                "type": "GET",
                "url": url,
                "data": params,
                "success": function (data) {
                    $(oSettings.nTBody).html('');
                    timerId && clearTimeout(timerId);
                    timerId = null;
                    $(oSettings.nTBody).data('data', data); //保存一份原始数据，以供其他功能使用
                    data = preprocessData(data);
                    fnCallback(data);
                    NProgress.done();
                },
                'error': function ($xhr, txtStatus, msg) {
                    $.gritter.error('请求数据出错: ' + txtStatus + ', ' + msg);
                }
            });
        },
        'aoColumns': [
            {'mData': 'beginTime' },
            {'mData': 'endTime' },
            {
                'mData': 'status', 'aTargets': [0],
                'mRender': function (status) {
                    if (status == 999) {
                        return '正在打包';
                    } else if (status == 1000) {
                        return '打包完成';
                    } else if (status == 1001) {
                        return '打包失败'
                    } else if (status == 1002) {
                        return '已取消';
                    } else {
                        return '';
                    }
                }
            },
            {
                'mData': 'userName'
            },
            {
                'mData': 'createTime'
            },
            {
                'mData': 'status', 'aTargets': [0],
                'mRender': function (status, type, full) {
                    if (status == 999) {
                        return '<button data-uuid="' + full['uuid'] + '" data-loading-text="正在停止..." class="pause btn btn-warning">停止</button>';
                    } else if (status == 1000) {
                        return '<a target="_blank" href="' + full['filePath'] + '" class="btn btn-success">下载</a>';
                    } else if (status == 1001 || status == 1002) {
                        return '<button data-uuid="' + full['uuid'] + '" data-loading-text="正在提交..." class="restart btn btn-success">重新开始</button>';
                    } else {
                        return '';
                    }
                }
            }
        ]
    });

    $('#content').on('click', 'tr .btn.pause', function () {
        var $btn = $(this).button('loading');
        var uuid = $btn.data('uuid');
        $.ajax({
            url: ROOT + '/OTA/cancelOTA',
            type: 'POST',
            dataType: 'json',
            data: {
                uuid: uuid
            },
            success: function (data) {
                if (data.status == 1000) {
                    $.gritter.success('成功停止了导出任务');
                    dataTable.fnDraw(true);
                } else {
                    $.gritter.error(data.msg);
                }
            },
            error: function ($xhr, txtStatus, msg) {
                $.gritter.error('出现了错误: ' + txtStatus + ', ' + msg);
            }
        }).always(function () {
            $btn.button('reset');
        });
    });

    $('#content').on('click', 'tr .btn.restart', function () {
        var $btn = $(this).button('loading'),
            uuid = $btn.data('uuid');

        $.ajax({
            url: ROOT + '/OTA/rezip',
            type: 'POST',
            dataType: 'json',
            data: {
                uuid: uuid
            },
            success: function (data) {
                if (data.status == 1000) {
                    dataTable.fnDraw(true);
                } else {
                    $.gritter.error(data.msg);
                }
            },
            error: function ($xhr, txtStatus, msg) {
                $.gritter.error('出现了错误: ' + txtStatus + ', ' + msg);
            }
        }).always(function () {
            $btn.button('reset');
        });
    });

    //定时刷新页面
    var refresh = function () {
        dataTable.fnDraw();
        setTimeout(refresh, 10 * 1000);
    };
    setTimeout(refresh, 10 * 1000);
})();
