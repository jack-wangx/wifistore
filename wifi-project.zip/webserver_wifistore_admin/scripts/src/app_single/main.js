﻿(function () {

    $('select').select2();

    var hashParams = window.location.hash.substr(1).split('&').reduce(function (result, p) {
        var temp = p.split('=');
        result[temp[0]] = temp[1];
        return result;
    }, {}) || {};

    var deviceList = [];
    var projectList = [];
    var pList = [];
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>";
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>";
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>";
    $(document).ready(function () {
        getFilter();
        $("#backBtn").hide();

        $("#searchOption").click(function () {
            getAppInfo($("#keys").val(), 'select');
        });

        $("#backBtn").on({
            click: function () {
                $("#oneapplist").slideUp(100);
                $("#moreapplist").slideDown(100);
            }
        });

        $("#moreapp").on('click', 'tr', 'click', function () {
            getAppInfo($(this).attr('rel'), 'select');
            $("#backBtn").show();
        });

        if (hashParams['pkgName']) {
            getAppInfo(hashParams['pkgName'], 'select');
        }


        $("#device").change(function () {
            var devicevalue = $("#device option:selected").val();
            if (devicevalue != '-1') {
                $('#project').empty();
                var optHtml = "<option value='-1'>全部项目</option>";
                $.each(pList, function (index, array) {
                    if (array.device == devicevalue) {
                        optHtml += "<option value='" + array.project + "'>" + array.project + "</option>";
                    }
                });
            } else {
                selectInit(projectList, 'project');
            }
            $('#project').append(optHtml);
        });

    });


    function getFilter() {
        var data = { action: 'axo' };
        $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error('发生内部错误，未能获取项目列表！');
                        return false;
                    }
                    if (json) {
                        //alert(JSON.stringify(json));
                        pList = json;
                        $.each(pList, function (index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
            },
            complete: function () { //生成分页条

            },
            error: function () {
                $.gritter.error('加载项目列表失败')
            }
        });
    }


    function getAppInfo(keys, action) {

        if (keys == "" || keys == null || keys == "应用名或包名") {
            $("#msg_ser").empty();
            $("#msg_ser").append("搜索条件不能为空");
            return false;
        }
        var searchKeywords = keys;
        var data = {
            title: keys,
            action: action,
            device: $('#device option:selected').val(),
            project: $('#project option:selected').val()
        };
        $.ajax({
            type: 'POST',
            url: ROOT + '/AppManager/getSingle',
            //data: '{'title':'+ keys +'}',
            data: data,
            dataType: 'json',
            beforeSend: function () {
                //alert(JSON.stringify(data));
                $("#msg_ser").empty();
                $("#msg_ser").append("loading...");
                $("#oneapplist").slideUp(100);
                $("#moreapplist").slideUp(100);
            },
            success: function (json) {
                //alert(JSON.stringify(json))
                status = json.status; //总记录数
                keys = json.keys; //总记录数
                //alert(url+data);
                if (status == 2001) {
                    //alert(JSON.stringify(json.appcountsql));
                    //alert(JSON.stringify(json.count));
                    $("#msg_ser").empty();
                    $("#msg_ser").append("没有记录！");
                } if (status == 1000) {

                    //alert(JSON.stringify(json));
                    if (json.appDetail) {
                        $("#oneapp").empty();
                        $("#appName").empty();
                        $("#appNametitle").empty();
                        var li = "";
                        var appdetail = json.appDetail;
                        $.each(appdetail, function (index, array) { //遍历json数据列
                            li += "<tr><td>版本号</td><td>" + array['appName'] + "</td></tr><tr><td>包名</td><td>" + array['appPagesname'] + "</td></tr><tr><td>使用时间</td><td>" + array['usedTime'] + "</td></tr><tr><td>使用次数</td><td>" + array['usedCount'] + "</td><tr><td>装机量</td><td>" + array['appallcount'] + "</td></tr>";
                        });
                        $("#oneapp").append(li);
                        $.each(appdetail, function (index, array) { //遍历json数据列
                            name = array['appName'] + "的统计信息";
                        });
                        $("#appName").append(name);
                        $("#appNametitle").append(name);
                        $("#msg_ser").empty();
                        $("#oneapplist").slideDown(100);
                        window.location.hash = 'pkgName=' + searchKeywords;
                        drawChart(json.appDetail);
                    }
                    if (json.appList) {
                        $("#backBtn").hide();
                        $("#moreapp").empty();
                        $("#msg_ser").empty();
                        $("#moreapplist").slideDown(100);
                        var li = "";
                        var applist = json.appList;
                        $.each(applist, function (index, array) { //遍历json数据列
                            li += "<tr rel='" + array['appPagesname'] + "'><td>" + array['appName'] + "</td>" + "<td>" + array['appPagesname'] + "</td></tr>";
                        });
                        $("#moreapp").append(li);
                    }
                }
            },
            error: function () {
                $.gritter.error('App数据加载失败')
            }
        });

    }

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function (index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml).trigger('change');
    }

    var drawChart = function (appDetail) {
        var redrawTimer;
        $(window).off('.chart')
            .on('resize.chart', function () {
                redrawTimer && clearTimeout(redrawTimer);
                redrawTimer = setTimeout(function () {
                    drawGender(appDetail.gender);
                    drawUseTime(appDetail.useTime);
                }, 50);
            });
        drawGender(appDetail.gender);
        drawUseTime(appDetail.useTime);
    };

    var chart,
        genderPaper;
    var drawGender = function (genderData) {
        //todo remove data for development
        var female = Math.random() * 100;
        genderData = [['女', female], ['男', 100 - female]];

        var $gender = $('#gender');
        genderPaper = genderPaper || Raphael('gender');
        genderPaper.setSize($gender.width(), 250);
        chart && chart.clear();
        chart = genderPaper.donutchart(0, 0, $gender.width(), 220, 80, genderData, {
            colors: ['#ff92b6', '#5da9e8'],
            legendRenderer: function (value) {
                var cls = value[0] == '男' ? 'male': 'female';
                return ['<div class="legend-item legend-' + cls + '">',
                            '<i class="icon-' + cls + '"></i> <span>' + value[0] + '性占比</span>',
                            '<h4>' + value[1].toFixed(2) + '%</h4>',
                        '</div>'].join('');
            }
        });
    };

    var useTimeChart,
        useTimePaper;
    var drawUseTime = function (useTimeData) {
        //todo remove data for development
        
        useTimeData = [];
        for (var i = 0; i < 24; i+=0.5) {
            useTimeData.push([i, Math.floor(Math.random() * 8000)]);
        }

        useTimeData.push([24, useTimeData[0][1]]);
        var data = useTimeData.reduce(function (result, value) {
            result[0].push(value[0]);
            result[1][0].push(value[1]);
            return result;
        }, [[], [[]]]);

        var $useTime = $('#useTime');
        useTimePaper = useTimePaper || Raphael('useTime');
        useTimePaper.setSize($useTime.width(), 250);
        useTimePaper.clear();
        useTimeChart = useTimePaper.linechart(
            50, 0, $useTime.width() - 100, 220, data[0], data[1],
            {
                axis: '0 1 1 1',
                axisxstep: 24,
                width: 1
            });
    };

})();