﻿(function() {
    var mAction = ACTION;
    var mUniqueId = UNIQUEID;
    var selected;
    var Uname;


    //获取数据
    function getGroupList(){
        var data={ action: "select", type: "all" ,functions:"add"};
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/getUserGroup',
            data: data,
            dataType:'json',
            beforeSend:function(){
                $(".group_dropdown").empty();

            },
            success:function(json){
    
                if(json!=null){
                    clearList();
                    var Groups = json.groups;
                    updateGroupList("#group_list", Groups);
                    initPage();

                }else{
                }
            },
            complete:function(){
            },
            error:function(){

            }
        });
    }


    //--------------------- submit edited perms -------------------------------------

    function submitEditedUser(data){
        if(!data)return false;
        $.ajax({
            type: 'POST',
            url: ROOT + '/User/' + (data.action=="insert" ? "addUser" : "updateUser" ),
            data: data,
            dataType:'json',
            beforeSend:function(){
                $("#submit_edited_user").attr("disabled","disabled");
            },
            success:function(json){
                switch(json.status){
                    case 1000:
                        if(mAction=="edit") {
                            $.gritter.success("修改用户成功！");
                        } else {
                            $.gritter.success("添加用户成功!");
                        }
                        window.location.href=ROOT + '/User/user_manager';
                        break;
                    case 2001:
                        $.gritter.warn("请填写完整的信息！");
                        break;
                    case 2002:
                        $.gritter.warn("用户名格式不正确！");
                        break;
                    case 2003:
                        $.gritter.warn("用户名已存在，请更换！");
                        break;
                    case 9999:
                        $.gritter.warn("内部错误,提交失败！");
                        break;
                }
            },
            complete:function(){  
                $("#submit_edited_user").removeAttr("disabled");
            },
            error:function(){
                $.gritter.error("保存用户信息时发生错误，请重试");
                $("#submit_edited_user").removeAttr("disabled");
            }
        });
    }


    //--------------------- update inherit Group list -------------------------------------

    function updateGroupList(element, list)
    {
        $(element).find(".divRadio").each(function(index,e){$(this).remove();})
        $.each(list,function(index,array){ //遍历json数据列
            var status = "";
            if(array["default"] == "default")
            {
                status = "checked='checked'";
            }
            var $a = createRadio("radioLabel","radioImage","radio",array['groupName'],array['groupId'],status);
            $(element).append($a);
        });
        $(element).find("input").eq(0).attr("checked","checked");
        widgetStyleInit();
    }

    //--------------------- clear list ------------------------------------------
    function clearList(){
        $("#user_name").find("input").each(function(index,e){$(this).text("");})
        $("#group_list").find(".divRadio").each(function(index,e){$(this).remove();})
    }


    //--------------------- load perm lists -------------------------------------

    function getUserInfo(){
        var data;

        data={"action":"select_one","uniqueId": mUniqueId};

        $.ajax({
            type: 'POST',
            url: ROOT + '/User/getUserInfo',
            data: data,
            dataType:'json',
            beforeSend:function(){
            },
            success:function(json){
                switch(json.status){
                    case 1000:
                        $("title").text("修改" + json.userName + "的信息");
                        $(".panelhead").text("修改" + json.userName + "的信息");
                        $("#user_name").find("input").val(json.userName);
                        $("#group_list").find("input").each(function(index, element) {
                            if($(this).attr("id")==json.groupId){
                                $(this).parent().find("label").trigger('click');
                            }
                        });
                        break;
                    case 1002:
                        $.gritter.error("不存在该用户！");
                        break;
                    case 9999:
                        $.gritter.error("发生内部错误！");
                        break;
                    default:
                        $.gritter.error("发生未知错误！错误代码:" + json.status);
                        break;
                }
            },
            complete:function(){
            },
            error:function(){
                $.gritter.error("获取用户信息时发生错误，请刷新页面");
            }
        });
    }

    function getEditedUser(element, element2) {
        $(element).find(".divRadio").each(function(index, val){ //遍历json数据列
            if($(this).find("input").prop("checked"))
                selected = $(this).find("input").attr("id");
        });
        var Uname = $(element2).find("input").val();
        if(Uname == "" || Uname == null)
        {
            $.gritter.warn("未输入用户名");
            return false;
        }
        if(mAction == "edit") {
            var jsonData = {"groupId": selected , "userName": Uname , "uniqueId" : mUniqueId , "action" : "update"};
        } else {
            var jsonData = {"groupId": selected , "userName": Uname , "action" : "insert"};
        }
        return jsonData;
    }

    function initPage() {
        $("#submit_edited_user").on({
            click: function() {
                submitEditedUser(getEditedUser("#group_list", "#user_name"));
            }
        });
        if(mAction == "edit") {
            $("#submit_edited_user").val("提交修改");
            getUserInfo();
        } else {
            $("#submit_edited_user").val("立刻添加");
        }

        $("#user_name").on('focus', "input", function(e) {
            $("#user_name").find("div.prompt").slideDown(100);
        }).on('blur', "input", function(e) {
            $("#user_name").find("div.prompt").slideUp(100);
        });
    }

    $(document).ready(function(e) {
        getGroupList();
    });
})();