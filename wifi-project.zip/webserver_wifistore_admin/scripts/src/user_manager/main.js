﻿(function() {
    $('select').select2();

    var solutionProvider = SOLUTIONPROVIDER;
    var loadingRow = "<tr><td colspan='3'>正在载入数据...</td></tr>";
    var failedRow = "<tr><td colspan='3'>数据加载失败</td></tr>";
    var emptyRow = "<tr><td colspan='3'>没有数据</td></tr>";

//获取数据

    function getGroupList() {
        var data = { action: "select", type: "all", functions: "add" };
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/getUserGroup',
            data: data,
            dataType: 'json',
            beforeSend: function() {
                $("#userGroup").empty();
                var $Option = $("<option></option>");
                $Option.attr("value", "-1");
                $Option.text("全部用户组");
                $("#userGroup").append($Option).trigger('change');
            },
            success: function(json) {

                if (json != null) {
                    var list = json.groups;
                    $.each(list, function(index, array) { //遍历json数据列
                        var $Option = $("<option></option>");
                        $Option.attr("value", array["groupId"]);
                        $Option.text(array['groupName']);
                        //if(array['groupName']==solutionProvider + "_user")
                        //$Option.text("默认用户组");
                        $("#userGroup").append($Option).trigger('change');
                    });

                } else {
                    alert("服务器无响应，通讯失败");
                }
            },
            complete: function() {
            },
            error: function() {

            }
        });
    }


//获取数据

    function getUserList(groupId) {
        var data;
        if (groupId == null) {
            data = { 'action': 'select' };
        } else {
            data = { 'action': 'select', 'groupId': groupId };
        }
        $.ajax({
            type: 'POST',
            url: ROOT + '/User/getUserList',
            data: data,
            dataType: 'json',
            beforeSend: function() {
                $("#user_list").find("tbody").empty();
                $("#user_list").find("tbody").append(loadingRow);
            },
            success: function(json) {
                $("#user_list").find("tbody").empty();
                if (json != null) {
                    var li = "";
                    var list = json.users;
                    if (list.length == 0) {
                        $.gritter.info('不存在用户数据，请添加');
                        return;
                    }
                    $.each(list, function(index, array) { //遍历json数据列
                        li += ["<tr id='" + array["uniqueId"] + "'>",
                                "<td>" + array['userName'] + "</td>",
                                "<td>" + array['groupName'] + "</td>",
                                "<td>",
                                    "<button class='editBtn btn btn-small'><i class='icon-edit'></i> 编辑</button> ",
                                    "<button class='deleteBtn btn btn-small'><i class='icon-remove'></i> 删除</button>",
                                "</td>",
                               "</tr>"].join('');
                    });
                    $("#user_list").find("tbody").append(li);
                } else {
                    $("#user_list").find("tbody").empty();
                    $("#user_list").find("tbody").append(emptyRow);
                }
            },
            complete: function() {
            },
            error: function() {
                $("#user_list").find("tbody").empty();
                $("#user_list").find("tbody").append(failedRow);
            }
        });
    }

    function delete_user(uniqueId) {
        if (uniqueId != null) {
            data = { 'action': 'delete', 'uniqueId': uniqueId };
        } else {
            return;
        }
        $.ajax({
            type: 'POST',
            url: ROOT + '/User/delUser',
            data: data,
            dataType: 'json',
            beforeSend: function() {
                $("#user_list").find("input").each(function(index, element) {
                    $(this).attr("disabled", "disabled")
                });
                ;
            },
            success: function(json) {
                switch (json.status) {
                case 1000:
                    $.gritter.success("删除用户成功!");
                    getUserList();
                    break;
                case 1001:
                    $.gritter.warn("该用户无法删除!");
                    break;
                case 9999:
                    $.gritter.error("发生内部错误！");
                    break;
                default:
                    $.gritter.error("发生未知错误！错误代码:" + json.status);
                    break;
                }
            },
            complete: function() {
                $("#user_list").find("input").each(function(index, element) {
                    $(this).removeAttr("disabled");
                });
                ;
            },
            error: function() {
                $.gritter.error("删除用户时发生错误，请重试");
                $("#user_list").find("input").each(function(index, element) {
                    $(this).removeAttr("disabled");
                });
                ;
            }
        });
    }

    function initPage() {
        $('#user_list').on('click', ".editBtn", function() {
            window.location.href = ROOT + "/User/user_manager?action=edit&uniqueId=" + $(this).parent().parent().attr("id");
        });
        $("#userGroup").on({
            change: function() {
                if ($(this).val() != "-1") {
                    getUserList($(this).val());
                } else {
                    getUserList(null);
                }
            }
        });

        $('#user_list').on('click', ".deleteBtn", function() {
            var r = confirm("确认删除" + $(this).parent().parent().find("td").eq(0).text() + "吗？");
            if (r == true) {
                delete_user($(this).parent().parent().attr("id"));
            } else {
                return;
            }
        });
    }

    $(document).ready(function(e) {
        //alert(groupId);
        getGroupList();
        initPage();
    });
})();