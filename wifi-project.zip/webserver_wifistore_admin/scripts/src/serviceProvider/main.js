﻿(function() {
    $('select').select2();

    var deviceList = [];
    var projectList = [];
    var pList = [];
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>";
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>";
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>";

    var nodata = { 'name': 'Hava no data', 'type': 'pie', 'data': [] };

    $(document).ready(function () {
        getFilter();
    });

    function getFilter() {
        var data = { action: 'axo' };

        $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {

                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error("发生内部错误，未能获取设备、项目列表！");
                        return false;
                    }
                    if (json) {

                        pList = json;
                        $.each(pList, function (index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
                bindSelectEvent();
            },
            complete: function () { //生成分页条
                getCarrier();
            },
            error: function () {
                $.gritter.error("加载设备、项目列表数据时发生错误，请重试");
            }
        });
    }

    function getCarrier() {
        var mPv;
        if ($("#project option:selected").val() != '-1') mPv = $("#project option:selected").val();
        var mDv;
        if ($("#device option:selected").val() != '-1') mDv = $("#device option:selected").val();

        var data = { action: 'select', type: 'pie', name: '设备占有率' };

        if (mPv || mDv) {
            data = { action: 'select', type: 'pie', name: '设备占有率', pv: mPv, dv: mDv };
        }

        $.ajax({
            type: 'POST',
            url: ROOT + '/Device/getSPData',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {

                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error("发生内部错误，未能获取运营商设备分布信息列表！");
                        return false;
                    } else if (json.status == 1000) {
                        setChart(json.bean);
                    } else if (json.status == 2001) {
                        setChart(nodata);
                        $.gritter.warn("没有运营商设备分布信息列表");
                    } else {
                        $.gritter.warn("没有运营商设备分布信息列表");
                    }
                }
            },
            complete: function () {

            },
            error: function () {
                $.gritter.error("加载运营商设备分布信息数据失败，请重试");
            }
        });
    }

    var bindSelectEvent = function (){
        $("#device").change(function () {
            var devicevalue = $("#device option:selected").val(),
                optHtml = '';
            if (devicevalue != '-1') {
                $('#project').empty();
                optHtml = "<option value='-1'>全部项目</option>";
                $.each(pList, function (index, array) {
                    if (array.device == devicevalue) {
                        optHtml += "<option value='" + array.project + "'>" + array.project + "</option>";
                    }
                });
            } else {
                selectInit(projectList, 'project');
            }
            $('#project').append(optHtml);
            getCarrier();
        });

        $("#project").change(function () {
            getCarrier();
        });
    };

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function (index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml).trigger('change');
    }


    function setChart(bean) {
        var chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram_carrier_part',
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: '运营商设备分布图'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage}%</b>',
                percentageDecimals: 1
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function () {
                            var name = {
                                '46000': '中国移动',
                                '46001': '中国联通'
                            };
                            return '<b>' + name[this.point.name] + '</b>: ' + this.percentage + ' %';
                        }
                    }
                }
            },
            series: [bean]
        });


    }
})();
