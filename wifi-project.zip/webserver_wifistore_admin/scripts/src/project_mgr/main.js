﻿(function() {
    var groupId;
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>"
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>"
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>"

    function switch_project(action, axo_value) {
        var data;
        if (axo_value != null) {
            data = { 'action': action, 'axo_value': axo_value };
        } else {
            return;
        }
        var op = {
            'hidden':'设置隐藏',
            'show': '设置显示'
        }[action];
        $.ajax({
            type: 'POST',
            url: ROOT + '/Project/' + ({'hidden':'hide', 'show': 'show'}[action]) + 'Project',
            data: data,
            dataType: 'json',
            beforeSend: function() {
                $("#project_list").find("input").each(function(index, element) {
                    $(this).attr("disabled", "disabled")
                });
                ;
            },
            success: function(json) {
                if (json != null) {
                    switch (json.status) {
                    case 1000:
                        $.gritter.success(op +'成功！');
                        getProjectList();
                        break;
                    case 1002:
                        $.gritter.warn('该项目不存在');
                        break;
                    case 9999:
                        $.gritter.error('发生内部错误！');
                        break;
                    default:
                        $.gritter.error("发生未知错误！错误代码:" + json.status);
                        break;
                    }
                } else {
                    $.gritter.error(op + "失败");
                }
            },
            complete: function() {
                $("#project_list").find("input").each(function(index, element) {
                    $(this).removeAttr("disabled");
                });
            },
            error: function() {
                $.gritter.error(op + "失败");
                $("#project_list").find("input").each(function(index, element) {
                    $(this).removeAttr("disabled");
                });
            }
        });
    }

    //获取数据

    function getProjectList() {

        var data = { action: "select" };
        $.ajax({
            type: 'POST',
            url: ROOT + '/Project/getProjects',
            data: data,
            dataType: 'json',
            beforeSend: function() {
                $("#project_list").find("tbody").empty();
                $("#project_list").find("tbody").append(loadingRow);
            },
            success: function(json) {


                if (json != null) {
                    var flag = json.flag;

                    if (flag == 0) {
                        $("#project_list").find("tbody").empty();
                        $("#project_list").find("tbody").append(emptyRow);
                        return false;
                    } else {
                        //alert("该用户组存在用户无法删除!");
                    }
                    $("#project_list").find("tbody").empty();


                    var li = "";
                    var list = json.axo_details;
                    var groupStr = "";
                    $.each(list, function(index, array) {
                        if (array.aro_group) {
                            $.each(array.aro_group, function(index, array) {
                                groupStr += array.name + ",";
                            });
                            var reg = /,$/gi;
                            groupStr = groupStr.replace(reg, "");
                        } else {
                            groupStr = "无关联用户组"
                        }
                        var switchVal = "";
                        var switchRel = "";
                        if (array.hidden == 0) {
                            switchVal = "隐藏";
                            switchRel = "hidden";
                        } else {
                            switchVal = "显示";
                            switchRel = "show";
                        }
                        li += ["<tr id='" + array["axo_value"] + "'>",
                                "<td>" + array['device'] + "</td>",
                                "<td>" + array['project'] + "</td>",
                                "<td>" + groupStr + "</td>",
                                "<td>",
                                    "<button class='editBtn btn btn-small'><i class='icon-edit'></i> 编辑</button> ",
                                    "<button class='switchBtn btn btn-small' rel='", switchRel, "'>", switchVal, "</button>",
                                "</td></tr>"].join('');
                        groupStr = "";
                    });
                    $("#project_list").find("tbody").append(li);
                } else {
                    $("#project_list").find("tbody").empty();
                    $("#project_list").find("tbody").append(emptyRow);
                }
            },
            complete: function() {
            },
            error: function() {
                $("#project_list").find("tbody").empty();
                $("#project_list").find("tbody").append(failedRow);
            }
        });
    }

    function initPage() {
        $(".editBtn").live({
            click: function() {
                window.location.href = "?action=edit&projectValue=" + $(this).parent().parent().attr("id");
            }
        });
        $(".switchBtn").live({
            click: function() {
                switch_project($(this).attr("rel"), $(this).parent().parent().attr("id"));
            }
        });
    }

    //--------------------- test ------------------------------------------------------

    $(document).ready(function(e) {
        getProjectList();
        initPage();
    });
})();