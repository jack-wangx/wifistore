(function () {
    var deviceList = new Array();
    var projectList = new Array();
    var pList = new Array();
    var $appListItem = $("" +
        "<div class='divAppItem'>" +
        "<img src='../style/img/ic_default_app.png' />" +
        "<span>application</span><br/>" +
        "<textarea class='divmultitext' id='description' name='description' draggable='false'></textarea>" +
        "</div>");
    var $delListItem = $("" +
        "<div class='divDelItem' id='del_item'>" +
        "<strong>com.qq.com</strong><a href='javascript:;'>删除</a><br/>" +
        "<textarea class='divmultitext' id='description' name='description' draggable='false'></textarea>" +
        "</div>");


    var pInit;
    var pUpload;
    var pDelete;
    var pPushmsg;

    var appPushStr = "这款应用你应该会很喜欢的，赶紧下载试试呗。";
    var appDelStr = "这款应用被系统监测到危险行为，建议您立刻卸载哦。";

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function (index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml);
    }

    function getFilter() {
        var data = { action: 'axo' };

        $.ajax({
            type: 'GET',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error('发生内部错误，未能获取项目列表', '发生了错误')
                        return false;
                    }
                    if (json) {
                        pList = json;

                        $.each(pList, function (index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
                $("#tasktype").empty();
                $("#tasktype").append("<option value='-1'>选择任务</option>");
                var tlist = new Array();
                tlist.push('0');
                tlist.push('1');
                tlist.push('2');
                tlist.push('3');
                var tasktypelist = "";
                $.each(tlist, function (index, value) { //遍历json数据列
                    var typeStr = "";
                    switch (value) {
                        case '0':
                            typeStr = "推送";
                            break;
                        case '1':
                            typeStr = "强行推送";
                            break;
                        case '2':
                            typeStr = "删除";
                            break;
                        case '3':
                            typeStr = "强行删除";
                            break;
                        default:
                            typeStr = "未知类别";
                            break;
                    }
                    tasktypelist += "<option value=" + value + ">" + typeStr + "</option>";
                });
                $("#tasktype").append(tasktypelist);
            },
            complete: function () { //生成分页条

            },
            error: function () {
                $.gritter.error('获取设备、项目列表失败')
            }
        });

    }

    $(document).ready(function () {
        getFilter();

        pInit = $("#panel_init");
        pUpload = $("#panel_upload");
        pDelete = $("#panel_delete");
        pPushmsg = $("#panel_pushmsg");


        $('body').on('focus', '#description', function(e) {
            $("#description").next().slideDown(100);
        }).on('blur', '#description', function(e) {
            $("#description").next().slideUp(100);
        });

        $('body').on('click', '.divDelItem a', function() {
            $(this).parent().slideUp(100, function() { $(this).remove() });
        });


        $("#init2upload").click(function() {
            var taskvalue = $("#tasktype option:selected").val();
            if (taskvalue == 2 || taskvalue == 3) {
                pInit.slideUp();
                pDelete.slideDown();
            } else if (taskvalue == 0 || taskvalue == 1) {
                pInit.slideUp();
                pUpload.slideDown();
            } else {
                $.gritter.warn('您还未选择任务种类')
            }
        });

        $('#add_delete').click(function () {
            if ($('#package_input').val()) {
                addDelApp($('#package_input').val());
                $('#package_input').val('');
            } else {
                return;
            }
        })


        $("#upload2pushmsg").click(function () {
            if ($('.divAppItem').length <= 0) {
                $.gritter.warn('您未上传任何应用！')
                error = true;
                return error;
            }
            pUpload.slideUp();
            pPushmsg.slideDown();
            $('#file_upload').uploadify('stop');

        })

        $("#addDeleteTask").click(function () {
            completeTaskAdd(getDelTasks());
        })
        $("#addPushTask").click(function () {
            completeTaskAdd(getTasks());
        })

        $("#device").change(function () {
            var devicevalue = $("#device option:selected").val();
            if (devicevalue != '-1') {
                $('#project').empty();
                var optHtml = "<option value='-1'>全部项目</option>";
                $.each(pList, function (index, array) {
                    if (array.device == devicevalue) {
                        optHtml += "<option value='" + array.value + "'>" + array.project + "</option>";
                    }
                })
            } else {
                selectInit(projectList, 'project');
            }
            $('#project').append(optHtml);
        });

        pInit.show();
        pUpload.hide();
        pDelete.hide();
        pPushmsg.hide();
    });

    function addDelApp(packageName) {
        var $tmp = $delListItem.clone();
        $tmp.find('strong').text(packageName);
        $tmp.find('textarea').text(packageName + "被发现有威胁，建议您立刻卸载");
        $tmp.css('display', 'none');
        $('#del_list').append($tmp);
        $tmp.slideDown();
    }


    function removeDelApp() {
        var $tmp = $delListItem.clone();
        $('#del_list').append($tmp);
    }

    function getTasks() {
        var tasklist = new Array();
        var error = false;
        if ($('.divAppItem').length <= 0) {
            $.gritter.warn('你还未上传任何应用')
            error = true;
            return error;
        }
        $('.divAppItem').each(function (index, element) {
            if (!$(this).find('#description').val()) {
                error = true;
            }
            var tmp = {
                "uuid": $(this).attr('id'),
                "description": $(this).find('#description').val()
            };
            tasklist.push(tmp);
        });
        if (!error) {
            return tasklist;
        } else {
            $.gritter.warn('缺少描述信息')
            return error;
        }
    }

    function getDelTasks() {
        var tasklist = new Array();
        var error = false;
        if ($('.divDelItem').length <= 0) {
            $.gritter.warn('您还未添加要删除的应用')
            error = true;
            return error;
        }

        $('.divDelItem').each(function (index, element) {
            if (!$(this).find('#description').val()) {
                error = true;
            }
            var tmp = {
                "packageName": $(this).find('strong').text(),
                "description": $(this).find('#description').val()
            };
            tasklist.push(tmp);
        });
        if (!error) {
            return tasklist;
        } else {
            $.gritter.warn('缺少描述信息')
            return error;
        }
    }


    function completeTaskAdd(applist) {
        if (!applist) return;
        var projectId = $('#project').val(),
            deviceId = $('#device').val();

        var data = {
            "formaction": "add",
            "deviceid": deviceId,
            "tasktype": $("#tasktype").val(),
            "axo_value": projectId,
            "apps": applist
        };
        $.ajax({
            type: 'POST',
            url: '/controller/include/doaction.php',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {
                if (json) {
                    if (json.status) {
                        switch (json.status) {
                            case 0:
                                $.gritter.error('提交失败，请重试')
                                break;
                            case 1:
                                window.location.href = ROOT + "/AppManager/task_list";
                                break;
                        }
                    }

                }
            }
        });
    }
    $(function () {
        $('#file_upload').uploadify({
            'formData': {
                'timestamp': TIMESTAMP,
                'token': TOKEN
            },
            'buttonText': '添加要上传的应用',
            'removeCompleted': false,
            'fileTypeDesc': 'android apk',
            'fileTypeExts': '*.apk',
            'fileSizeLimit': '50MB',
            'swf': '/vendor/uploadify/uploadify.swf',
            'uploader': '/controller/include/upload.php',
            'auto': false,
            'multi': true,
            'method': 'post',
            'onSelect': function (file) {
                $(".cancel_btn").show();
            },
            'onUploadStart': function() {
                $('#file_upload').uploadify('settings', 'formData', {
                    'taskvalue': $('#tasktype').val(),
                    'formaction': 'uploadapk',
                    'deviceid': $('#device').val(),
                    'projectid': $('#project').val()
                });
            },
            'onUploadSuccess': function (file, data, response) {
                //数据示例
                //data = {"appName":"coolapk","uuid":"df01a3239d49d81f20ecc80423814a7f","status":1000,"picUrl":"http://image.coolapk.com/apk_logo/2012/0814/12202_1344923716_9538.png"};
                var result = eval('(' + data + ')');
                if (result && result.status) {
                    switch (result.status) {
                        case 5001:
                            $('#' + file.id).find('.data').html(' - 添加错误');
                            $('#' + file.id).css('background', '#ffe0e0');
                            $('#' + file.id).find('.uploadify-progress').remove();
                            $('#' + file.id).append("<div><strong>错误信息:</strong>apk后缀名不正确</div>");
                            break;
                        case 5002:
                            $('#' + file.id).find('.data').html(' - 添加错误');
                            $('#' + file.id).css('background', '#ffe0e0');
                            $('#' + file.id).find('.uploadify-progress').remove();
                            $('#' + file.id).append("<div><strong>错误信息:</strong>apk过大</div>");
                            break;
                        case 5003:
                            $('#' + file.id).find('.data').html(' - 添加错误');
                            $('#' + file.id).css('background', '#ffe0e0');
                            $('#' + file.id).find('.uploadify-progress').remove();
                            $('#' + file.id).append("<div><strong>错误信息:</strong>解析失败</div>");
                            break;
                        case 1000:
                            var $tmp = $appListItem.clone();
                            $('#' + file.id).find('.data').html(' - 添加成功');
                            $('#' + file.id).find('.cancel').html('');

                            $tmp.find('img').attr("src", result.picUrl);
                            $tmp.find('span').text(result.appName);
                            $tmp.find('textarea').text(result.appName + "可能是你喜欢的应用哦");
                            $tmp.attr('id', result.uuid);

                            pPushmsg.find(".divTextAreaList").append($tmp);

                            $('#' + file.id).css('background', '#d9f4de');
                            $('#' + file.id).find('.uploadify-progress').remove();
                            $('#' + file.id).append("<br/><img style='width:48px;height:48px;' src='" + result.picUrl + "'/><div>" + result.appName + "</div>");
                            break;
                        case 9999:
                        default:
                            $('#' + file.id).find('.data').html(' - 添加错误');
                            $('#' + file.id).css('background', '#ffe0e0');
                            $('#' + file.id).find('.uploadify-progress').remove();
                            $('#' + file.id).append("<div><strong>错误信息:</strong>系统错误</div>");
                            break;

                    }
                } else {
                    $('#' + file.id).find('.data').html(' - 添加错误');
                    $('#' + file.id).css('background', '#ffe0e0');
                    $('#' + file.id).find('.uploadify-progress').remove();
                    $('#' + file.id).append("<div><strong>错误信息:</strong>未知错误</div>");
                }
            }
        });
    });
})();
