﻿(function () {
    $(function () {
        $('.single-select').on('click.single-click', 'li.item', function () {
            var $li = $(this);
            if ($li.hasClass('selected')) {
                return;
            } else {
                $li.parent().find('.selected').removeClass('selected');
                $li.addClass('selected');
                $li.parent().trigger('selected', $li[0]);
            }
        }).on('selected', function (e, liEl) {
            var $li = $(liEl);
            var hobby = $.trim($li.find('span').text());
            $.ajax({
                url: ROOT + '/UserDemand/getAppList',
                type: 'GET',
                dataType: 'json',
                data: { hobby: hobby }
            }).done(function (data) {
                if (data) {
                    var html = $.map(data, function (d) {
                        return ["<li>",
                                    "<div class='clearfix app'>",
                                        "<img src='", d.iconUrl, "' />",
                                        "<div class='app-name'>", d.appName, "</div>",
                                        "<span class='app-amount'><span>未安装人数：</span>", d.notInstallAmount, "</span>",
                                        '<a href="' + ROOT + '/AppManager/task_list?action=add" class="btn btn-mini"><i class="icon-share"></i>创建推送任务</a>',
                                    "</div>",
                                "</li>"].join('');
                    }).join('');
                } else {
                    var html = "";
                }
                $('#app-list').html(html);
            });
        });
        $('.single-select li.item:first-child').click();

        if (Modernizr.csstransforms) {
            $('.hobby-list .item a').on('mouseenter', function () {
                var $item = $(this).find('i');
                $item.stop().animate({
                    'rotation': 360
                }, 300);
            }).on('mouseout', function () {
                var $item = $(this).find('i');
                $item.stop().animate({
                    'rotation': 0
                }, 0);
            });
        }
    });
})();
