﻿(function() {
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>"
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>"
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>"

    //获取数据
    function getGroupList() {
        var data = { action: "select", type: "all" };
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/getUserGroup',
            data: data,
            dataType: 'json',
            beforeSend: function () {
                $("#group_list").find("tbody").empty();
                $("#group_list").find("tbody").append(loadingRow);
            },
            success: function (json) {
                $("#group_list").find("tbody").empty();

                if (json != null) {
                    var li = "";
                    var list = json.groups;
                    $.each(list, function (index, array) { //遍历json数据列
                        li += ["<tr id='" + array["groupId"] + "'>",
                                "<td>" + array['groupName'] + "</td>",
                                "<td>" + array['objectsNum'] + "人</td>",
                                "<td>" + array['groupParentName'] + "</td>",
                                "<td>",
                                    "<button class='editBtn btn btn-small'><i class='icon-edit'></i> 编辑</button> ",
                                    "<button class='permBtn btn btn-small'>权限</button> ",
                                    "<button class='deleteBtn btn btn-small'><i class='icon-remove'></i> 删除</button>",
                                "</td></tr>"].join('');
                    });
                    $("#group_list").find("tbody").append(li);
                } else {
                    $("#group_list").find("tbody").empty();
                    $("#group_list").find("tbody").append(emptyRow);
                }
            },
            complete: function () {
            },
            error: function () {
                $("#group_list").find("tbody").empty();
                $("#group_list").find("tbody").append(failedRow);
            }
        });
    }

    function delete_group(userId) {
        var type = "delete";
        var data = { action: "delete", groupId: userId };
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/delGroup',
            data: data,
            dataType: 'json',
            beforeSend: function () {
                $("#group_list").find("input").each(function (index, element) {
                    $(this).attr("disabled", "disabled");
                });
            },
            success: function (json) {
                switch (json.status) {
                    case 1000:
                        $.gritter.success("删除用户组成功!");
                        getGroupList();
                        break;
                    case 1001:
                        $.gritter.warn("该用户组存在用户或用户组无法删除!");
                        break;
                    case 9999:
                        $.gritter.error("删除用户组时发生错误");
                        break;
                    default:
                        $.gritter.error("发生未知错误！错误代码:" + json.status);
                        break;
                }
            },
            complete: function () {
                $("#group_list").find("input").each(function (index, element) {
                    $(this).removeAttr("disabled");
                });;
            },
            error: function () {
                $.gritter.error("删除用户组时发生错误，请重试");
                $("#group_list").find("input").each(function (index, element) {
                    $(this).removeAttr("disabled");
                });;
            }
        });
    }

    function initPage() {
        $(".permBtn").live({
            click: function () {
                window.location.href = "?action=auth&groupId=" + $(this).parent().parent().attr("id");
            }
        });
        $(".editBtn").live({
            click: function () {
                window.location.href = "?action=edit&groupId=" + $(this).parent().parent().attr("id");
            }
        });
        $(".deleteBtn").live({
            click: function () {
                var r = confirm("确认删除" + $(this).parent().parent().find("td").eq(0).text() + "吗？");
                if (r == true) {
                    delete_group($(this).parent().parent().attr("id"));
                }
                else {
                    return;
                }
            }
        });
    }

    $(document).ready(function (e) {
        getGroupList();
        initPage();
    });
})();