﻿(function() {


    /**
     * 将json数据处理成jquery.DataTable控件需要的格式
     * @param  {json} data 后台返回的原始json对象
     * @return {json} jquery.DataTable需要的json格式 [look here](www.datatables.net/usage/server-side)
     */
    var preprocessData = function (data) {
        var result = {aaData: []};
        var getProject = function (axoinfo) {
            return axoinfo.project;
        };
        for (var i = 0; i < data.length; i++) {
            var item = data[i];
            var scope = $.map(item.axoinfos.axoinfo, getProject).join(', ');
            var content = item.apps.substr(1);
            var tasktype = item.tasktype;
            result.aaData.push([
                scope, content, item.tasktype, item.createTime,
                item.status, item.status, item.taskuuid
            ]);
        }
        return result;
    };

    var dataTable = $('.data-table').dataTable({
        "bJQueryUI": true,
        "sPaginationType": "full_numbers",
        "sDom": 't',
        'sAjaxSource': ROOT + '/AppManager/gettask',
        'bServerSide': true,
        "fnServerParams": function (params) {
            var mTaskvalue = $('#tasktype').val(),
                mPv = $('#project').val(),
                mDv = $('#device').val();

            if (mTaskvalue != -1) params.push({name: 'taskvalue', value: mTaskvalue});
            if (mPv != -1) params.push({name: 'pv', value: mPv});
            if (mDv != -1) params.push({name: 'dv', value: mDv});
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            $(nRow).data('uuid', aData[6]);
        },
        "fnServerData": function (url, params, fnCallback, oSettings) {
            var timerId = setTimeout(function () {
                NProgress.set(Math.random() * 0.4);
                NProgress.inc();
            }, 300);
            $(oSettings.nTBody).html('');
            oSettings.jqXHR = $.ajax({
                "dataType": 'json',
                "type": "POST",
                "url": url,
                "data": params,
                "success": function (data) {
                    timerId && clearTimeout(timerId);
                    timerId = null;
                    $(oSettings.nTBody).data('data', data); //保存一份原始数据，以供其他功能使用
                    data = preprocessData(data.list || []);
                    fnCallback(data);
                    NProgress.done();
                }
            });
        },
        "aoColumnDefs": [{
            "aTargets": [2],
            "mData": 2,
            "mRender": function (tasktype, type, full) {
                var statusDesc = ['推送', '强行推送', '删除', '强行删除'];
                return statusDesc[parseInt(tasktype, 10)] || '未知类别';
            }
        }, {
            "aTargets": [4],
            "mData": 4,
            "mRender": function (status, type, full) {
                var statusDesc = ['正在推送', '处理中', '待命', '推送失败'];
                return statusDesc[parseInt(status, 10) + 1] || '未知状态';
            }
        }, {
            "aTargets": [5],
            "mData": 5,
            "mRender": function (status, type, full) {
                status = parseInt(status, 10);
                var btnStr = ['停止推送', '无法操作', '开始推送', '无法操作'][status + 1] || '无法操作';
                var btnStatus = [' ', 'disabled', ' ', 'disabled'][status + 1] || 'disabled';
                return [
                    "<button rel='" + status + "' type='button' ",
                    "class='starttask btn btn-small' " + btnStatus + ">" + btnStr + "</button>&nbsp;",
                    "<button type='button' class='del-bt btn btn-small'>删除</button>"
                ].join('');
            }
        }]
    });

    $('select').select2();

    var deviceList = [];
    var projectList = [];
    var pList = [];
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>";
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>";
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>";

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function(index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml).trigger('change');
    }

    function getFilter() {
        var data = { action: 'axo' };

        return $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function() {
            },
            success: function(json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error("发生内部错误，未能获取设备、项目列表！");
                        return false;
                    }
                    if (json) {
                        pList = json;
                        $.each(pList, function(index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
                $("#tasktype").empty();
                $("#tasktype").append("<option value='-1'>全部任务</option>");
                var tlist = new Array();
                tlist.push('0');
                tlist.push('1');
                tlist.push('2');
                tlist.push('3');
                var tasktypelist = "";
                $.each(tlist, function(index, value) { //遍历json数据列
                    var typeStr = "";
                    switch (value) {
                    case '0':
                        typeStr = "推送";
                        break;
                    case '1':
                        typeStr = "强行推送";
                        break;
                    case '2':
                        typeStr = "删除";
                        break;
                    case '3':
                        typeStr = "强行删除";
                        break;
                    default:
                        typeStr = "未知类别";
                        break;
                    }
                    tasktypelist += "<option value=" + value + ">" + typeStr + "</option>";
                });
                $("#tasktype").append(tasktypelist).val(-1).trigger('change');
            },
            complete: function() { //生成分页条

            },
            error: function() {
                $.gritter.error("获取设备、项目信息时发生错误，请重试");
            }
        });
    }

    function getAppTaskList() {
        dataTable.fnDraw();
    }

    $(function() {
        var promise = getFilter();
        promise.done(function () {
            $("#tasktype").change(function() {
                getAppTaskList();
            });

            $("#device").change(function() {
                var devicevalue = $("#device option:selected").val();
                if (devicevalue != '-1') {
                    $('#project').empty();
                    var optHtml = "<option selected='selected' value='-1'>全部项目</option>";
                    $.each(pList, function(index, array) {
                        if (array.device == devicevalue) {
                            optHtml += "<option value='" + array.project + "'>" + array.project + "</option>";
                        }
                    });
                } else {
                    selectInit(projectList, 'project');
                }
                $('#project').append(optHtml);
                getAppTaskList();
            });

            $("#project").change(function() {
                getAppTaskList();
            });
        })
    });

    function startPush(taskuniqueId, appStatus) {
        $.ajax({
            type: 'POST',
            url: ROOT + '/AppManager/setPushStatus',
            data: { taskuniqueId: taskuniqueId, appStatusnum: appStatus },
            cache: false,
            ifModified: true,
            dataType: 'json',
            beforeSend: function() {
                $("#task").find("input").attr('disabled', 'disabled');
            },
            success: function(json) {
                affected = json.affected;
                if (affected == 0) {
                    $.gritter.success("设置推送状态成功!");
                } else {
                    $.gritter.error("设置推送状态失败!");
                }
                getAppTaskList();
            },
            complete: function() { //生成分页条

            },
            error: function() {
                $.gritter.error("设置推送状态发生错误");
            }
        });
    }

    $(function() {
        $('#celebs').on('click', 'tbody tr', function(e) {
            var $tr = $(this);
            var task = getTrData($tr);
            if ($(e.target).hasClass('del-bt')) {
                deleteTask(task);
            } else if ($(e.target).prop('tagName').toLowerCase() !== 'button') {
                showModal(task);
            }
        });

        $("#task").on('click', '.starttask', function() {
            var $tr = $(this).parents('tr:eq(0)');
            var task = getTrData($tr);
            var taskuuid = task['taskuuid'];
            startPush(taskuuid, $(this).attr('rel'));
        });

        var getTrData = function($tr) {
            var uuid = $tr.data('uuid');
            var data = $tr.parents('#task').data('data');
            var tasks = data.list;
            for (var i = 0; i < tasks.length; i++) {
                var task = tasks[i];
                if (task.taskuuid == uuid) {
                    return task;
                }
            }
        };

        var showModal = function(task) {
            var taskScopeHtml = getTaskScopeHtml(task);
            var taskTypeHtml = getTaskTypeHtml(task);
            var taskContentHtml = getTaskContentHtml(task);
            var taskFeedbackHtml = getTaskFeedbackHtml(task);
            var taskRemarkHtml = getTaskRemarkHtml(task);

            var title = task.createTime + '提交的任务';

            $('#modal .title').html(title).data('task', task);
            $('#taskScope').html(taskScopeHtml);
            $('#taskType').html(taskTypeHtml);
            $('#taskContent').html(taskContentHtml);
            $('#taskFeedback').html(taskFeedbackHtml);
            $('#taskRemark').html(taskRemarkHtml);

            $('#modal .edit-bt').show();
            $('#modal .panelbottom').hide();
            $('#modal .complete-bt').hide().button('reset');
            $('#modal').modal('show');
        };

        var getTaskScopeHtml = function(task) {
            var axoInfos = task.axoinfos.axoinfo;
            var axoInfo = {};

            for (var i = 0; i < axoInfos.length; i++) {
                var device = axoInfos[i].device;
                var project = axoInfos[i].project;

                axoInfo[device] = axoInfo[device] || [];
                axoInfo[device].push(project);
            }

            var html = [];
            for (var device in axoInfo) {
                html.push('<dl class="device clearfix">');
                html.push('<dt class="title">', device, '</dt>');
                var projects = axoInfo[device];
                for (var i = 0; i < projects.length; i++) {
                    var project = projects[i];
                    html.push('<dd class="project-item">', project, '</dd>');
                }
                html.push('</dl>');
            }

            return html.join('');
        };

        var getTaskTypeHtml = function(task) {
            var typeStr = '';
            switch (task.tasktype) {
            case '0':
                typeStr = "推送";
                break;
            case '1':
                typeStr = "强行推送";
                break;
            case '2':
                typeStr = "删除";
                break;
            case '3':
                typeStr = "强行删除";
                break;
            default:
                typeStr = "未知类别";
                break;
            }

            return '<span>' + typeStr + '</span>';
        };

        var getTaskContentHtml = function(task) {
            var apps = task.appinfos.appinfo;
            var html = [];
            html.push('<ul class="apps">');
            for (var i = 0; i < apps.length; i++) {
                var app = apps[i];
                html.push('<li class="app">',
                    '<div>',
                    '<img class="app-icon" src="', app.picUrl, '" />',
                    '<span>', app.appName, '</span>',
                    '</div>',
                    '<input class="app-desc" data-origin-value="', app.description, '" type="text" data-app="', app.appuuid, '" disabled="disabled" value="', app.description, '"/>',
                    '</li>');
            }
            html.push('</ul>');
            return html.join('');
        };

        var getTaskFeedbackHtml = function(task) {
            var html = [];
            html.push('<ul class="feedback-list clearfix row">');

            var apps = task.appinfos.appinfo;
            for (var i = 0; i < apps.length; i++) {
                var app = apps[i];
                html.push('<li class="feedback span3">',
                    '<dl>',
                    '<dt>',
                    '<img src="', app.picUrl, '" />',
                    '<span>', app.appName, '</span>',
                    '</dt>',
                    '<dd>推送数: ', app.pushNum, '</dd>',
                    '<dd>安装数: ', app.installNum, '</dd>',
                    '<dd>成功率: ', app.successRate, '</dd>',
                    '</dl>',
                    '</li>');
            }

            html.push('</ul>');
            return html.join('');
        };

        var getTaskRemarkHtml = function(task) {
            var html = [];
            html.push('<input class="remark" data-origin-value="',
                task.remark, '" type="text" data-task="', task.taskuuid,
                '" disabled="disabled" value="', task.remark, '" />');

            return html.join('');
        };

        $('#modal .edit-bt').on('click', function() {
            $(this).hide();
            $('#modal .complete-bt').show();
            $('#taskContent input, #taskRemark input').prop('disabled', false);
        });

        $('#modal .complete-bt').on('click', function() {
            var data = { appInfos: [], taskInfo: {} };
            $('input.app-desc').each(function() {
                var $input = $(this);
                var originDesc = $input.data('origin-value') || '';
                var newDesc = $.trim($input.val());
                if (originDesc !== newDesc) {
                    var appuuid = $input.data('app');
                    data.appInfos.push({ appuuid: appuuid, description: newDesc });
                }
            });
            if (!data.appInfos.length) {
                data.appInfos = '';
            }

            var $remark = $('input.remark');
            var originRemark = $remark.data('origin-value') || '';
            var newRemark = $.trim($remark.val());
            if (originRemark !== newRemark) {
                data.taskInfo.taskuuid = $remark.data('task');
                data.taskInfo.remark = newRemark;
            } else {
                data.taskInfo = '';
            }

            updateTask(data);
        });

        var updateTask = function(data) {
            if (!data.appInfos && !data.taskInfo) {
                $('#modal').modal('hide');
                return;
            }
            $('#modal .complete-bt').button('saving');
            data.action = 'edit';
            $.ajax({
                type: 'post',
                data: data,
                dataType: 'json',
                url: ROOT + '/AppManager/updatetask',
                success: function(response) {
                    if (response !== null && response.status) {
                        switch (response.status) {
                        case 1000:
                            closeEdit();
                            $.gritter.success('保存任务成功');
                            getAppTaskList();
                            break;
                        case 1002:
                            $.gritter.error('保存任务失败');
                            break;
                        default:
                            $.gritter.error('系统错误，请联系管理员');
                            break;
                        }
                    }
                },
                error: function(jqXHR, textStatus) {
                    $.gritter.error('保存任务状态时发生错误, 请重试' + textStatus);
                },
                complete: function() {
                    $('#modal').modal('hide');
                }
            });
        };

        var deleteTask = function(task) {
            if (!confirm('确定要删除该任务吗？')) {
                return;
            }
            var data = { taskuuid: task.taskuuid, action: 'delete' };
            $.ajax({
                type: 'post',
                data: data,
                dataType: 'json',
                url: ROOT + '/AppManager/delTask',
                success: function(response) {
                    switch (response.status) {
                    case 1000:
                        $.gritter.success('删除任务成功');
                        getAppTaskList();
                        break;
                    case 1002:
                        $.gritter.error('删除任务失败');
                        break;
                    default:
                        $.gritter.error('系统错误，请联系管理员');
                        break;
                    }
                },
                error: function(jqXHR, textStatus) {
                    $.gritter.error('无法访问服务器, 请重试');
                }
            });
        };
    });
})();
