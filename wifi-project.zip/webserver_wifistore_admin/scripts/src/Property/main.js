﻿
var chart = null;
var displayBubble = function (data) {
    var paper = Raphael('chartDiv');
    chart = paper.bubblechart({
        items: hobbies
    }, {
        minRadius: 25,
        maxRadius: 90,
        placeholder: [[0, -100, 450]],
        imageMap: {
            '阅读': {
                type: 'fontIcon',
                iconText: '\uf02d'
            },
            '社交': {
                type: 'fontIcon',
                iconText: '\uf082'
            },
            '音乐': {
                type: 'fontIcon',
                iconText: '\uf001'
            },
            '购物': {
                type: 'fontIcon',
                iconText: '\uf07a'
            },
            '游戏': {
                type: 'fontIcon',
                iconText: '\uf11b'
            },
            '影视': {
                type: 'fontIcon',
                iconText: '\uf008'
            },
            '旅游': {
                type: 'fontIcon',
                iconText: '\uf072'
            },
            '金融': {
                type: 'fontIcon',
                iconText: '\uf157'
            },
            '数码': {
                type: 'fontIcon',
                iconText: '\uf030'
            },
            '商务': {
                type: 'fontIcon',
                iconText: '\uf0f2'
            },
            '教育': {
                type: 'fontIcon',
                iconText: '\uf14b'
            },
            '体育': {
                type: 'fontIcon',
                iconText: '\ue117'
            },
            '动漫': {
                type: 'fontIcon',
                iconText: '\ue000'
            }
        }
    });
    chart.hover(function () {
        var sector = this.sector;
        var val = this.data[1];
        var label = this.data[0];
        var total = this.total;
        var bound = sector.getBBox();
        var percentage = (val * 100/ total).toFixed(2) + '%';
        var $pop = $('.popover');
        var lites = $pop.data('tweenlite');
        lites && $.each(lites, function (i, l) { l.kill(); });

        var maxX = paper.width;
        if (bound.x2 > maxX / 2) {
            $pop.removeClass('right').addClass('left');
            var popLeft = bound.x;
            var alignLeft = true;
        } else {
            $pop.removeClass('left').addClass('right');
            var popLeft = bound.x2;
            var alignLeft = false;
        }

        var color = sector.attrs.gradient.split('-')[1];
        $pop.find('.popover-content').html([
            '<div style="color: ', color, '"><strong>', label, '</strong>',
            '<span style="margin-left: 20px;">', percentage, '</span></div>'
        ].join(''));
        $pop.show();
        var h = $pop.height();
        if (alignLeft) {
            popLeft -= $pop.width() + 5;
        }
        $pop.css({
            left: popLeft, top: bound.cy - h / 2
        });
        lites = [];
        if (Modernizr.csstransforms) {
            var origin = (alignLeft ? 'right' : 'left') + ' 50%'
            TweenLite.to($pop[0], 0, { scaleX: 0, scaleY: 0, transformOrigin: origin });
            var tl = TweenLite.to($pop[0], .3, {
                  css: { scaleX: 1, scaleY: 1, transformOrigin: origin },
                  ease: Back.easeOut
            });
            lites.push(tl);
        }
        TweenLite.to(this.sector, .5, {
            raphael: {
                scaleX: 1.1, scaleY: 1.1
            },
            ease: Bounce.easeOut
        });
        TweenLite.to(this.cover, 0, {
            raphael: {
                scaleX: 1.1, scaleY: 1.1
            }
        });
        $pop.data('tweenlite', lites);
    }, function () {
        var $pop = $('.popover');
        var lites = $pop.data('tweenlite');
        lites && $.each(lites, function (i, l) { l.kill(); });
        lites = [];
        if (Modernizr.csstransforms) {
            var bound = this.sector.getBBox();
            var maxX = paper.width;
            var alignLeft = bound.x2 > maxX / 2;
            var origin = (alignLeft ? 'right' : 'left') + ' 50%';
            var tl = TweenLite.to($pop[0], 0.3, {
                css: { scaleX: 0, scaleY: 0, transformOrigin: origin },
                ease: Back.easeIn,
                onComplete: function () {
                    $pop.hide();
                }
            });
            lites.push(tl);
        } else {
            $pop.hide();
        }
        TweenLite.to(this.sector, 0.5, {
            raphael: {
                scaleX: 1, scaleY: 1
            },
            ease: Bounce.easeOut
        });
        TweenLite.to(this.cover, 0, {
            raphael: {
                scaleX: 1, scaleY: 1
            }
        });
        $pop.data('tweenlite', lites);
    });
};
var displayGender = function (genderData) {
    var paper = Raphael('genderChart', 400, 220),
        $gender = $('#genderChart');
    var chart = paper.donutchart(0, 0, $gender.width(), 200, 80, genderData, {
        colors: ['#ff92b6', '#5da9e8'],
        selectable: true,
        legendRenderer: function (value) {
            var cls = value[0] == '男' ? 'male': 'female';
            return ['<div class="legend-item legend-' + cls + '">',
                        '<i class="icon-' + cls + '"></i> <span>' + value[0] + '性占比</span>',
                        '<h4>' + value[1].toFixed(2) + '%</h4>',
                    '</div>'].join('');
        }
    });
    chart.on('activated', function (arc, arcs) {
        var value = arc.value;
        if (value[0] == '男') {
            $('.page-title span').html('男性');
            showMaleData();
        } else {
            $('.page-title span').html('女性');
            showFemaleData();
        }
    }).on('deactivated', function (arc, arcs) {
        if (!arcs[0].selected && !arcs[1].selected) {
            $('.page-title span').html('');
            showAllData();
        }
    });
};
var showMaleData = function () {
    //todo remove
    var data = JSON.parse(JSON.stringify(hobbies));
    for (var i = 0; i < data.length; i++) {
        var hobby = data[i];
        hobby[1] = hobby[1] - Math.random() * 0.5 * hobby[1];
    }
    chart.draw({items: data});
};
var showFemaleData = function () {
    //todo remove
    var data = JSON.parse(JSON.stringify(hobbies));
    for (var i = 0; i < data.length; i++) {
        var hobby = data[i];
        hobby[1] = hobby[1] - Math.random() * 0.5 * hobby[1];
    }
    chart.draw({items: data});
};
var showAllData = function () {
    //todo remove
    var data = hobbies;
    chart.draw({items: data});
};
$(function () {
    //displayAreaPie(hobbies);
    for (var i = 0; i < hobbies.length; i++) {
        var h = hobbies[i];
        if (h[0] == '其他') {
            hobbies.splice(i, 1);
            break;
        }
    }
    $.each(hobbies, function (h) {
        h[1] *= 100;
    });
    displayBubble(hobbies);
    displayGender(gender);
});
