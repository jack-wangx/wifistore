﻿$(function () {
    $('#file_upload').uploadify({
        'formData': {
            'timestamp': TIMESTAMP,
            'token': TOKEN,
            'formaction': 'uploadrom'
        },
        'buttonText': '添加要上传的rom',
        'removeCompleted': false,
        'fileTypeDesc': 'android otapackage',
        'fileTypeExts': '*.zip',
        'fileSizeLimit': '800MB',
        'swf': '/vendor/uploadify/uploadify.swf',
        'uploader': '/controller/include/upload.php',
        'auto': false,
        'multi': true,
        'method': 'post',
        'onSelect': function (file) {
            $(".cancel_btn").show();
        },
        'onUploadStart': function (file) {
        },
        'onUploadSuccess': function (file, data, response) {
            //data = {"status":"1","fileName":"IMG_0458.JPG","filesize":2076461,"md5value":"df01a3239d49d81f20ecc80423814a7f",'error':1};
            switch (data.status) {
                case '0':
                    $('#' + file.id).find('.data').html(' - 添加错误');
                    $('#' + file.id).css('background', '#ffe0e0');
                    $('#' + file.id).find('.uploadify-progress').remove();
                    $('#' + file.id).append("<div><strong>错误信息:</strong>不是正确的android otapackage</div>");
                    break;
                case '1':
                    $('#' + file.id).find('.data').html(' - 添加成功');
                    $('#' + file.id).find('.cancel').html('');
                    $('#' + file.id).css('background', '#d9f4de');
                    $('#' + file.id).find('.uploadify-progress').remove();
                    $('#' + file.id).append("<div><strong>md5:</strong>" + data.md5value + "</div>");
                    break;
            }
        }
    });
});