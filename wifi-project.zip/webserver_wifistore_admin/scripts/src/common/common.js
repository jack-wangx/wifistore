/*! common javascript */
Array.prototype.unique = function () {
    var n = {}, r = []; //n为hash表，r为临时数组
    for (var i = 0; i < this.length; i++) //遍历当前数组
    {
        if (!n[this[i]]) //如果hash表中没有当前项
        {
            n[this[i]] = true; //存入hash表
            r.push(this[i]); //把当前数组的当前项push到临时数组里面
        }
    }
    return r;
}


$("tbody").find("tr").on({
    mouseenter: function () {
        $(this).removeClass('normal_tr');
        $(this).addClass('selected_tr');
    },
    mouseleave: function () {
        $(this).removeClass('selected_tr');
        $(this).addClass('normal_tr');
    }
});

$("tbody").find("input").on({
    mouseover: function (e) {
        return false;
    },
    mousemove: function (e) {
        return false;
    },
    mouseout: function () {
        return false;
    }

});

function getPageBar() {
    //页码大于最大页数
    if (curPage > totalPage) curPage = totalPage;
    //页码小于1
    if (curPage < 1) curPage = 1;
    pageStr = "<span>共" + total + "条</span><span>" + curPage + "/" + totalPage + "</span>";

    //如果是第一页
    if (curPage == 1) {
        pageStr += "<span>首页</span><span>上一页</span>";
    } else {
        pageStr += "<span><a href='javascript:void(0)' rel='1'>首页</a></span><span><a href='javascript:void(0)' rel='" + (curPage - 1) + "'>上一页</a></span>";
    }

    //如果是最后页
    if (curPage >= totalPage) {
        pageStr += "<span>下一页</span><span>尾页</span>";
    } else {
        pageStr += "<span><a href='javascript:void(0)' rel='" + (parseInt(curPage) + 1) + "'>下一页</a></span><span><a href='javascript:void(0)' rel='" + totalPage + "'>尾页</a></span>";
    }

    $("#totalpagecount").html(pageStr);
}


//--------------------- create checkbox, checkboxAccess, radio -------------------------------------

function createCheck(labelClass, imageClass, inputType, checkStr, checkId, status) {
    var $NewCheck = $("<div class='divCheck'><label><div></div><span></span></label><input " + status + " type='" + inputType + "' hidden='true'></input></div>");
    $NewCheck.find("label").addClass(labelClass);
    $NewCheck.find("label").attr("for", checkId);
    $NewCheck.find("span").text(checkStr);
    $NewCheck.find("div").addClass(imageClass);
    $NewCheck.find("input").attr("id", checkId);
    return $NewCheck;
}

//--------------------- create radio -------------------------------------
function createRadio(labelClass, imageClass, inputType, checkStr, checkId, status) {
    var $NewCheck = $("<div class='divRadio'><label><div></div><span></span></label><input " + status + " type='" + inputType + "' hidden='true'></input></div>");
    $NewCheck.find("label").addClass(labelClass);
    $NewCheck.find("label").attr("for", checkId);
    $NewCheck.find("span").text(checkStr);
    $NewCheck.find("div").addClass(imageClass);
    $NewCheck.find("input").attr("id", checkId);
    $NewCheck.find("input").attr("name", "checkwidget");
    return $NewCheck;
}

function checkClickClass(object, checkImageClass, checkedImageClass, checkLabelClass, checkedLabelClass) {
    var checked = object.parent().find('input').attr("checked");
    var disabled = object.parent().find('input').attr("disabled");
    if (checked != "checked" && disabled != "disabled") {
        object.find('div').removeClass();
        object.find('div').addClass(checkedImageClass);
        if (checkLabelClass != 0) {
            object.removeClass();
            object.addClass(checkedLabelClass);
        }
    } else if (checked == "checked" && disabled != "disabled") {
        object.find('div').removeClass();
        object.find('div').addClass(checkImageClass);
        if (checkedLabelClass != 0) {
            object.removeClass();
            object.addClass(checkLabelClass);
        }
    }
}

function radioClickClass(object, checkImageClass, checkedImageClass, checkLabelClass, checkedLabelClass) {
    var checked = object.parent().find('input').prop("checked");
    var disabled = object.parent().find('input').prop("disabled");
    if (!checked && !disabled) {
        object.parent().parent().find('input').each(function () {

            $(this).parent().find('div').removeClass();
            $(this).parent().find('div').addClass(checkImageClass);
        });
        object.find('div').removeClass();
        object.find('div').addClass(checkedImageClass);

    }
}

function checkOnInitClass(object, checkImageClass, checkedImageClass, disableImageClass, disableCheckedImageClass, checkLabelClass, checkedLabelClass) {
    var checked = object.parent().find('input').attr("checked");
    var disabled = object.parent().find('input').attr("disabled");
    if (checked != "checked" && disabled != "disabled") {
        object.find('div').removeClass();
        object.find('div').addClass(checkImageClass);
        if (checkLabelClass != 0) {
            object.removeClass();
            object.addClass(checkLabelClass);
        }
    } else if (checked == "checked" && disabled != "disabled") {
        object.find('div').removeClass();
        object.find('div').addClass(checkedImageClass);
        if (checkedLabelClass != 0) {
            object.removeClass();
            object.addClass(checkedLabelClass);
        }
    } else if (checked == "checked" && disabled == "disabled") {
        object.find('div').removeClass();
        object.find('div').addClass(disableCheckedImageClass);
        if (checkedLabelClass != 0) {
            object.removeClass();
            object.addClass(checkedLabelClass);
        }
    } else if (checked != "checked" && disabled == "disabled") {
        object.find('div').removeClass();
        object.find('div').addClass(disableImageClass);
        if (checkLabelClass != 0) {
            object.removeClass();
            object.addClass(checkLabelClass);
        }
    }

}

function showEdit() {
    $('.divEditPage').show(0);
    $('.divEditBg').fadeIn();

    $('.divEditPanel').show(0);

    $('.divEditContent').css({
        position: 'absolute',
        left: ($(window).width() - $('.divEditContent').outerWidth()) / 2,
        top: ($(window).height() - $('.divEditContent').outerHeight()) / 2 + $(document).scrollTop()
    });

}
function closeEdit() {
    $('.divEditBg').hide();
    $('.divEditPanel').hide();
    $('.divEditPage').hide();
}
function showPopup(element, eventor) {
    var mTop = element.offset().top - $('.popup').height() - 5;
    var mLeft = eventor.pageX - $('.popup').width() / 2;
    $('.popup').find(".arrow_box").html(element.attr("rel"));
    $('.popup').css('top', mTop);
    $('.popup').css('left', mLeft);
    $('.popup').show();
}
function updatePopup(element, eventor) {
    var mTop = element.offset().top - $('.popup').height() - 5;
    var mLeft = eventor.pageX - $('.popup').width() / 2;
    $('.popup').css('top', mTop);
    $('.popup').css('left', mLeft);
}
function closePopup() {
    $('.popup').hide();
}

function widgetStyleInit() {
    //--------------------------------权限双项选择控件初始化-----------------------------------

    $("label.checkLabelAccess").each(function (index, element) {
        checkOnInitClass($(this), "checkDenyImage", "checkAccessImage", "checkDenyImage", "checkAccessImage", "checkLabelDeny", "checkLabelAccess");
    });

    $("label.checkLabelDeny").each(function (index, element) {
        checkOnInitClass($(this), "checkDenyImage", "checkAccessImage", "checkDenyImage", "checkAccessImage", "checkLabelDeny", "checkLabelAccess");
    });

    //--------------------------------多选控件初始化-----------------------------------
    $("label.checkLabel").each(function (index, element) {
        checkOnInitClass($(this), "checkImage", "checkImageChecked", "checkImageDisable", "checkImageCheckedDisable", 0, 0);
    });

    //--------------------------------单选控件初始化-----------------------------------
    $("label.radioLabel").each(function (index, element) {
        checkOnInitClass($(this), "radioImage", "radioImageChecked", "radioImageDisable", "radioImageCheckedDisable", 0, 0);

    });

}


function widgetEventInit() {

    //--------------------------------权限双项选择控件初始化---------------------------------
    $('body').on('click', "label.checkLabelAccess", function() {
        checkClickClass($(this), "checkDenyImage", "checkAccessImage", "checkLabelDeny", "checkLabelAccess");
    });

    $('body').on('click', "label.checkLabelDeny", function() {
        checkClickClass($(this), "checkDenyImage", "checkAccessImage", "checkLabelDeny", "checkLabelAccess");
    });

    //--------------------------------多选控件初始化-----------------------------------
    $('body').on('click', "label.checkLabel", function() {
        checkClickClass($(this), "checkImage", "checkImageChecked", 0, 0);
    });

    //--------------------------------单选控件初始化----------------------------------s
    $('body').on('click', "label.radioLabel", function() {
        radioClickClass($(this), "radioImage", "radioImageChecked", 0, 0);
    });

    //--------------------------------tab控件初始化-----------------------------------
    if ($.fn.tabs) {
        $("div.tabs").tabs("div.panelcontent > div.tab_content", {
            tabs: 'div.tab',     //确定哪些区域为选项卡
            effect: 'slide'     //展开效果，slide为纵向滑动
        });
    }

}

$(function () {
    $(document).ready(function (e) {


        widgetStyleInit();
        widgetEventInit();
        //--------------------------------初始化窗口-----------------------------------
        $(window).resize();

        $("div.prompt").hide();

        var vartable = $("div.table_more");
        vartable.on("click", function () {
            $(this).slideUp(1000);
            $(this).next().eq(0).slideDown(1000);
        });
    });


    $(window).resize(function () {
        var overlay_height;
        if (($(window).height() - $("body").height()) >= 0) {
            overlay_height = $(window).height();
        } else {
            overlay_height = $("body").height();
        }
        $('.divEditPage').css({
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: overlay_height - $(document).scrollTop(),

        });
        $('.divEditContent').css({
            position: 'absolute',
            left: ($(window).width() - $('.divEditContent').outerWidth()) / 2,
            top: ($(window).height() - $('.divEditContent').outerHeight()) / 2 + $(document).scrollTop()
        });

    });

});

