﻿var T = {
    charts: {},
    object: {
        clone: function (obj) {
            if (!T.isObject(obj)) return obj;
            return T.isArray(obj) ? obj.slice() : T.extend({}, obj);
        }
    },
    isObject: function(obj) {
        return obj === Object(obj);
    },
    isArray: Array.isArray || function(obj) {
        return toString.call(obj) == '[object Array]';
    },
    extend: function(obj) {
        each(slice.call(arguments, 1), function(source) {
            if (source) {
                for (var prop in source) {
                    obj[prop] = source[prop];
                }
            }
        });
        return obj;
    },
    g: function (sel) {
        return $(sel)[0];
    }
};
T.charts.Class = function () {
    var a = arguments.length;
    var d = arguments[0];
    var c = arguments[a - 1];
    var e = typeof c.initialize == "function" ? c.initialize : function () {
        d.prototype.initialize.apply(this, arguments)
    };
    if (a > 1) {
        var b = [e, d].concat(Array.prototype.slice.call(arguments).slice(1, a - 1), c);
        T.charts.inherit.apply(null, b)
    } else {
        e.prototype = c
    }
    e.extend = function (g) {
        if (!"[object Array]" == Object.prototype.toString.call(g)) {
            g = Array.prototype.concat.call(g)
        }
        var f = g.length;
        while (f--) {
            g[f].call(e.prototype)
        }
        return e
    };
    return e
};
T.charts.inherit = function (f, d) {
    var c = function () {
    };
    c.prototype = d.prototype;
    f.prototype = new c;
    var b, a, e;
    for (b = 2, a = arguments.length; b < a; b++) {
        e = arguments[b];
        if (typeof e === "function") {
            e = e.prototype
        }
        T.charts.Util.extend(f.prototype, e)
    }
};
T.charts.Util = T.charts.Util || {};
T.charts.Util.extend = function (a, e) {
    a = a || {};
    if (e) {
        for (var d in e) {
            var c = e[d];
            if (c !== undefined) {
                a[d] = c
            }
        }
        var b = typeof window.Event == "function" && e instanceof window.Event;
        if (!b && e.hasOwnProperty && e.hasOwnProperty("toString")) {
            a.toString = e.toString
        }
    }
    return a
};
T.charts.Util.blank = function () {
};
T.charts.Chart = T.charts.Class({
    paper: null, container: null, _data: null,
    defaultOpts: { exportSVG: false, containerId: "ContainerId" },
    initialize: function (b, a) {
        var c = T.charts.Util.extend;
        this._data = T.object.clone(b);
        a = a || b || {};
        a = c(T.object.clone(this.defaultOpts), T.object.clone(a));
        this.options = c(T.object.clone(this.options), a);
        this.opts = c(T.object.clone(this.opts), a);
        Raphael.exportSVG = this.options.exportSVG;
        this.container = T.g(this.options.containerId);
        if (!this.container) {
            return
        }
        this.container.firstChild && this.container.removeChild(this.container.firstChild);
        this.paper = Raphael(a.containerId, "100%", "100%")
    }, CLASS_NAME: "T.charts.Chart"
});

(function () {
    var d = Math;//, a = T.i18n.number.formatNumber, b = T.i18n.currency.format, e = T.i18n.number.formatRatio, c = T.number.randomInt;
    T.charts.Bubble = T.createChart({
        opts: {
            maxRadius: 70, minRadius: 39, maxFontSize: 26, minFontSize: 12,
            maxImgWidth: 44, minImgWidth: 22, decay: 10, limit: 20,
            animate: true, exportSVG: false,
            baseUri: T.config.systemConfig.webRoot + "/css/images/int_",
            imageMap: {
                "服装饰品": "clothes.png", "个护美容": "facial.png",
                "食品餐饮": "food.png", "汽车": "car.png", "影视": "movie.png",
                "阅读": "read.png", "音乐": "music.png", "母婴": "infant.png",
                "房产": "arc.png", "家居": "house.png", "游戏": "game.png",
                "社交": "social.png", "体育": "sports.png", "金融财经": "finance.png",
                "教育培训": "education.png", "数码": "digital.png",
                "时政与财经": "news.png", "健康保健": "health.png",
                "旅游": "travel.png"
            },
            TXT_ATTR: {
                fill: "#fff", "font-size": 22, "font-family": "SimHei"
            },
            backColors: ["90-#47acd7-#6fd2e9", "90-#6bb22c-#a8d545", "90-#fa9025-#fcc33b",
                "90-#db6574-#e07484", "90-#92c420-#c4df32", "90-#514dba-#7e78d9", "90-#1a73a6-#29b3cf",
                "90-#d3543e-#eb8d6c", "90-#e569d3-#f1a4e7", "90-#d69f03-#eccb01"],
            strokes: ["#78b8d0", "#a6c874", "#fdbd50", "#d54f5f", "#abd046", "#5955c0",
                "#2e93c1", "#d1654f", "#f096df", "#d5ae35"],
            tipTpl: '<div class="chart-tip"><div class="chart-tip-title">#{2}</div><div class="chart-tip-content"><p>#{0}<span>#{1}</span></p></div></div>',
            onmouseout: function (f) {
                this.tip && this.tip.hideTip()
            }
        },
        _bar: null, _balls: null, _groups: null,
        initialize: function (g, f) {
            T.charts.Chart.prototype.initialize.apply(this, [g, f]);
            this.draw(g)
        },
        draw: function (f) {
            this.paper.clear();
            this._data = f;
            this._initBalls();
            this.drawCircle();
            if (!this.opts.exportSVG) {
                this._bindEvents()
            }
        },
        _initBalls: function () {
            var g = T.g(this.opts.containerId);
            var k = this._data && this._data.items && this._data.items[0] && this._data.items[0][1] || 0;
            this._bar = { width: g.offsetWidth, height: g.offsetHeight, totalDecay: 0, maxValue: k };
            this._groups = [];
            this._balls = [];
            if (!this._data || !this._data.items) {
                return
            }
            for (var h = 0; h < this._data.items.length; h++) {
                var j = this._data.items[h][1];
                if (j > this._bar.maxValue) {
                    this._bar.maxValue = j
                }
                var f = this.randomPosition(j);
                ball = T.extend(f, { ratio: j });
                ball = this.relocation(ball, 1);
                this._balls.push(ball);
                this._groups.push(this.paper.set())
            }
        },
        drawCircle: function () {
            var m = this.paper, o = this.opts, v = this._bar, z = this._data, q = z.items, A = this._balls, x = this._groups, A = this._balls;
            v.totalDecay = 0;
            var w = 10, y = this;
            var l = function (B) {
                return function () {
                    var E = A[B];
                    var C = o["font-size"][B];
                    var F = (q[B][0] || "").substring(0, 2);
                    var D = m.text(E.cx, E.cy - C / 2, F);
                    D.attr(o.TXT_ATTR).attr({ "font-size": C });
                    x[B].push(D)
                }
            };
            for (var t = 0; t < q.length; t++) {
                var s = A[t];
                var g = this.getRadius(s.ratio);
                var h = m.circle(s.cx, s.cy, g);
                h.attr({ stroke: o.strokes[t], fill: o.backColors[t] });
                x[t].push(h);
                var p = this.getFontSize(s.ratio);
                var n = q[t][0];
                var u = m.text(s.cx, s.cy - p * 4 / 5, n);
                u.attr(o.TXT_ATTR).attr({ "font-size": p });
                this._groups[t].push(u);
                var r = this.getImageWidth(s.ratio);
                var f = o.imageMap[n];
                if (f) {
                    var j = o.baseUri;
                    if (T.browser.ie == 6) {
                        j += "ie6_"
                    }
                    var k = this.createImage(j + f, s.cx - r / 2, s.cy, r, r);
                    this._groups[t].push(k)
                }
                if (!o.exportSVG) {
                    this._setHover(h, t)
                }
            }
        },
        randomPosition: function (g) {
            var j = this._bar, h = this.opts, f = this.getRadius(g, true);
            return { cx: c(f, j.width - f), cy: c(f, j.height - f) }
        },
        collided: function (k, j) {
            var h = k.cx - j.cx, g = k.cy - j.cy, f = d.pow(d.pow(h, 2) + d.pow(g, 2), 0.5), l = this.getRadius(k.ratio) + this.getRadius(j.ratio) - f;
            if (l <= 0) {
                return false
            }
            return { x: -l * h / f, y: -l * g / f }
        },
        collidedAdge: function (h) {
            var g = this.getRadius(h.ratio);
            var f = 0, j = 0;
            if (h.cx - g < 0) {
                f = g - h.cx
            }
            if (h.cx + g > this._bar.width) {
                f = this._bar.width - h.cx - g
            }
            if (h.cy - g < 0) {
                j = g - h.cy
            }
            if (h.cy + g > this._bar.height) {
                j = this._bar.height - h.cy - g
            }
            return { x: f, y: j }
        },
        relocation: function (g, k, j) {
            var h = this._balls, j = j || this.flashStrategy;
            for (var f = 0; f < h.length; f++) {
                var l = this.collided(h[f], g);
                if (l) {
                    if (k > 5) {
                        this._bar.totalDecay += this.opts.decay;
                        k = 0
                    }
                    T.extend(g, this.randomPosition(g.ratio));
                    this.relocation(g, k + 1);
                    break
                }
            }
            return g
        },
        justify: function (g) {
            var f = this._groups, j = this._balls;
            for (var h = 0; h < f.length; h++) {
                if (f[h].length == 0) {
                    continue
                }
                if (h == g) {
                    continue
                }
                var k = this.collided(j[h], j[g]);
                if (k) {
                    this.simpleMove(h, g, k)
                }
            }
        },
        simpleMove: function (l, g, f) {
            var k = this._balls[l];
            var j = this._balls[g];
            var m = this;
            if (k == j) {
                return false
            }
            var h = this.collidedAdge({ cx: k.cx - f.x / 2, cy: k.cy - f.y / 2, ratio: k.ratio });
            var o = h.x - f.x / 2;
            var n = h.y - f.y / 2;
            k.cx += o;
            k.cy += n;
            console.log(k.cx + ":" + k.cy);
            this._groups[l].animate({ transform: ["...", "t", o, n].join() }, 200, (function (p) {
                return function () {
                    m.justify(p)
                }
            })(l));
            h = this.collidedAdge({ cx: j.cx + f.x / 2, cy: j.cy + f.y / 2, ratio: j.ratio });
            o = h.x + f.x / 2;
            n = h.y + f.y / 2;
            j.cx += o;
            j.cy += n;
            console.log(j.cx + ":" + j.cy);
            this._groups[g].animate({ transform: ["...", "t", o, n].join() }, 200, (function (p) {
                return function () {
                }
            })(g));
            return false
        },
        getRadius: function (h, g) {
            var l = this._bar, k = this.opts;
            var j = l.totalDecay;
            if (g) {
                j = 0
            }
            var f = (k.maxRadius - k.minRadius) * h / l.maxValue + k.minRadius - j;
            return f
        },
        getFontSize: function (g) {
            var j = this._bar, h = this.opts;
            var f = d.floor((h.maxFontSize - h.minFontSize) * g / j.maxValue) + h.minFontSize;
            return f
        },
        getImageWidth: function (g) {
            var j = this._bar, h = this.opts;
            var f = (h.maxImgWidth - h.minImgWidth) * g / j.maxValue + h.minImgWidth;
            return f
        },
        _bindEvents: function () {
            var f = this;
            T.event.on(window, "resize", function () {
                var g = T.g(f.opts.containerId).offsetWidth;
                if (f._bar.width == g) {
                    return
                }
                f._bar.width = g;
                f.draw(f._data)
            });
            T.event.on(this.paper.canvas, "mouseover", function (g) {
                f.opts.onmouseout.call(f)
            })
        }, _setHover: function (h, f) {
            var g = this;
            (function (k, j) {
                var l = { index: j, jndex: 0, target: k[0], data: g._data.items[j], label: g._data.items[j][0] };
                g._groups[j].hover(function (m) {
                    T.event.stop(m);
                    g._groups[j].forEach(function (n) {
                        n.toFront()
                    });
                    k.attr({ "fill-opacity": 0.7 });
                    if (g.opts.onmouseover) {
                        g.opts.onmouseover.call(g, l)
                    }
                }, function () {
                    k.attr({ "fill-opacity": 1 });
                    if (g.opts.onmouseout) {
                        g.opts.onmouseout.call(g, l)
                    }
                })
            })(h, f)
        }, axisFormat: function (g, f) {
            switch (f) {
                case "百分比":
                case "%":
                    return e(g);
                case "时长":
                    return g;
                case "元":
                    return b(g);
                default:
                    return a(g)
            }
        }, createImage: function (l, g, n, j, f) {
            if (Raphael.svg) {
                return this.paper.image(l, g, n, j, f)
            } else {
                var k = this;
                var h = function (p) {
                    this[0] = p;
                    var o = this;
                    this.onmouseover = function (q) {
                        T.event.on(p, "mouseover", q);
                        return o
                    };
                    this.onmouseout = function (q) {
                        T.event.on(p, "mouseout", q);
                        return o
                    };
                    this.hover = function (r, q) {
                        return o.onmouseover(r).onmouseout(q)
                    };
                    this.toFront = function () {
                        p.parentNode.appendChild(p);
                        Raphael._tofront(o, k.paper)
                    }
                };
                h.prototype = Raphael.el;
                var m = document.createElement("img");
                T.dom.setStyles(m, { width: j, height: f, top: n, left: g, position: "absolute" });
                T.g(this.paper.canvas).appendChild(m);
                m.src = l;
                return new h(m)
            }
        }, CLASS_NAME: "T.charts.Bubble"
    })
})();