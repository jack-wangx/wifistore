﻿(function () {
    /**
    opts: {
        data: {
            items: []
        },
        minRadius: 11,
        maxRadius: 12,
        decay: 1
    } 
    */
    var defaultOpts = {
        maxRadius: 70, minRadius: 39, maxFontSize: 26, minFontSize: 12,
        maxImgWidth: 44, minImgWidth: 22, decay: 10, limit: 20,
        animate: true,
        imageMap: {},
        baseUri: '',//T.config.systemConfig.webRoot + "/css/images/int_",
        TXT_ATTR: {
            fill: "#fff", "font-size": 22, "font-family": "SimHei"
        },
        backColors: ["90-#47acd7-#6fd2e9", "90-#6bb22c-#a8d545", "90-#fa9025-#fcc33b",
            "90-#db6574-#e07484", "90-#92c420-#c4df32", "90-#514dba-#7e78d9", "90-#1a73a6-#29b3cf",
            "90-#d3543e-#eb8d6c", "90-#e569d3-#f1a4e7", "90-#d69f03-#eccb01",
            "90-#326CD1-#5996FF", "90-#16A825-#59D966", "90-#A732D1-#CD50FA"
        ],
        strokes: ["#78b8d0", "#a6c874", "#fdbd50", "#d54f5f", "#abd046", "#5955c0",
            "#2e93c1", "#d1654f", "#f096df", "#d5ae35"],
        tipTpl: '<div class="chart-tip"><div class="chart-tip-title">#{2}</div><div class="chart-tip-content"><p>#{0}<span>#{1}</span></p></div></div>',
        onmouseout: function (f) {
            this.tip && this.tip.hideTip()
        },
        placeholder: [[0, 0, 0]] //占位区域[[cx, cy, r], ...]
    }

    function Bubblechart(paper, data, opts) {
        var tempOpts = $.extend({}, defaultOpts);
        $.extend(tempOpts, opts);
        this.opts = opts = tempOpts || {};

        this.paper = paper;
        var cover = paper.set();
        var total = 0;
        for (var i = 0; i < data.items.length; i++) {
            total += data.items[i][1];
        }
        this.hover = function (fin, fout) {
            fout = fout || function () { };
            var me = this;
            for (var i = 0; i < cover.length; i++) {
                (function (sector, j) {
                    sector.mouseover(function () {
                        var o = {
                            sector: sector[0],
                            cover: sector[1],
                            data: me._data.items[j],
                            total: total,
                            label: me._groups[i]
                        };
                        fin.call(o);
                    }).mouseout(function () {
                        var o = {
                            sector: sector[0],
                            cover: sector[1],
                            data: me._data.items[j],
                            total: total,
                            label: me._groups[i]
                        };
                        fout.call(o);
                    });
                })(cover[i], i);
            }
            return this;
        };

        this.draw = function (data) {
            //this.paper.clear();
            this._data = data;
            total = 0;
            for (var i = 0; i < data.items.length; i++) {
                total += data.items[i][1];
            }
            this._initBalls();  
            this.drawCircle();
        };

        this._initBalls = function () {
            var el = paper.canvas.parentNode;
            var maxValue = this._data && this._data.items && this._data.items[0] && this._data.items[0][1] || 0;
            this._bar = { width: el.offsetWidth, height: el.offsetHeight, totalDecay: 0, maxValue: maxValue };
            this._groups = [];
            this._balls = [];
            this._ballMap = {};
            if (!this._data || !this._data.items) {
                return
            }
            for (var h = 0; h < this._data.items.length; h++) {
                var name = this._data.items[h][0];
                var val = this._data.items[h][1];
                if (this._ballMap[name]) {
                    this._ballMap[name].ratio = val;
                    continue;
                }
                var val = this._data.items[h][1];
                if (val > this._bar.maxValue) {
                    this._bar.maxValue = val
                }
                var pos = this.randomPosition(val);
                ball = $.extend(pos, { ratio: val });
                ball = this.relocation(ball, 1);
                ball.name = name;
                this._balls.push(ball);
                this._ballMap[name] = ball;
                this._groups.push(this.paper.set());
            }
        };

        this.drawCircle = function () {
            var paper /*m*/ = this.paper,
                opts /*o*/ = this.opts,
                bar /*v*/ = this._bar,
                data /*z*/ = this._data,
                items /*q*/ = data.items,
                balls /*A*/ = this._balls,
                groups /*x*/ = this._groups;
            bar.totalDecay = 0;
            var w = 10, me /*y*/ = this;
            var l = function (idx) {
                return function () {
                    var E = balls[idx];
                    var C = opts["font-size"][idx];
                    var F = (items[idx][0] || "").substring(0, 2);
                    var textEl = paper.text(E.cx, E.cy - C / 2, F);
                    textEl.attr(opts.TXT_ATTR).attr({ "font-size": C });
                    groups[idx].push(textEl)
                }
            };
            for(var k = 0; k < cover.length; k++) {
                cover[k].reused = false;
            }
            for (var t = 0; t < items.length; t++) {
                var ball = balls[t];
                var radius = this.getRadius(ball.ratio),
                    circle = null,
                    coverCircle = null;
                for(var k = 0; k < cover.length; k++) {
                    if (cover[k].name == ball.name) {
                        circle = cover[k];
                        cover[k].reused = true;
                    }
                }
                if (!circle) {
                    var g = paper.set();

                    var circle = paper.circle(ball.cx, ball.cy, radius);
                    circle.attr({
                        stroke: opts.strokes[t], fill: opts.backColors[t],
                        cursor: 'pointer'
                    });
                    g.name = ball.name;
                    groups[t].push(circle);
                    g.push(circle);
                    g.group = t;
                    var labelFontSize = this.getFontSize(ball.ratio);
                    var label = items[t][0];
                    var text = paper.text(ball.cx, ball.cy - labelFontSize * 4 / 5, label);
                    text.attr(opts.TXT_ATTR).attr({ "font-size": labelFontSize });
                    this._groups[t].push(text);
                    var imgWidth = this.getImageWidth(ball.ratio);
                    var imgSrc = opts.imageMap[label];
                    if (imgSrc) {
                        if (imgSrc.type && imgSrc.type == 'img') {
                            var baseUri = opts.baseUri;
                            var ieTest = /(msie) ([\w.]+)/.exec(navigator.userAgent);
                            var browser = ieTest[1] || "";
                            var version = ieTest[2] || "0";
                            if (browser == "ie" && version == "6.0") {
                                baseUri += "ie6_"
                            }
                            var img = this.createImage(baseUri + imgSrc, ball.cx - imgWidth / 2, ball.cy, imgWidth, imgWidth);
                            this._groups[t].push(img);
                        } else if (imgSrc.type == 'fontIcon') {
                            var icon = this.createIcon(imgSrc, ball.cx, ball.cy + imgWidth / 2, imgWidth, imgWidth);
                            this._groups[t].push(icon);
                        }
                    }
                    
                    //增加一层cover，用于触发hover事件
                    var coverCircle = paper.circle(ball.cx, ball.cy, radius);
                    coverCircle.attr({
                        opacity: 0.1,
                        fill: 'white'
                    });
                    g.push(coverCircle);
                    cover.push(g);
                } else {
                    circle.animate({
                        'r': radius
                    }, 300, 'easeOut');
                }
            }
            for(var k = 0; k < cover.length; k++) {
                if (cover[k].reused === false) {
                    cover[k].remove();
                    cover[k].clear();
                    this._groups[cover[k].group].forEach(function (el) {
                        el.remove();
                    });
                    this._groups.splice(cover[k].group, 1);
                    cover.splice(k, 1);
                }
            }
        };

        this.createImage = function (url, x, y, width, height) {
            if (Raphael.svg) {
                return this.paper.image(url, x, y, width, height)
            } else {
                var bubblechart = this;
                var h = function (imgEl) {
                    this[0] = imgEl;
                    var me = this;
                    this.onmouseover = function (handler) {
                        $(imgEl).on("mouseover", handler);
                        return me;
                    };
                    this.onmouseout = function (handler) {
                        $(imgEl).on("mouseout", handler);
                        return me;
                    };
                    this.hover = function (handler1, handler) {
                        return me.onmouseover(handler1).onmouseout(handler)
                    };
                    this.toFront = function () {
                        imgEl.parentNode.appendChild(imgEl);
                        Raphael._tofront(me, bubblechart.paper)
                    }
                };
                h.prototype = Raphael.el;
                var imgEl = document.createElement("img");
                $(imgEl), css({ width: width, height: height, top: y, left: x, position: "absolute" });
                $(this.paper.canvas).append(imgEl);
                imgEl.src = url;
                return new h(imgEl)
            }
        };

        this.createIcon = function (iconOpts, x, y, width, height) {
            var font = paper.getFont('FontAwesome');
            if (font) {
                var text = paper.print(x - width / 2, y, iconOpts.iconText, font, width);
                text.attr('fill', 'white');
            } else {
                var text = paper.text(x, y, iconOpts.iconText)
                text.attr({
                    "fill": 'white',
                    "font-size": width,
                    'font-family': 'FontAwesome'
                });
            }
            return text;
        };

        this.getFontSize = function (radius) {
            var j = this._bar, h = this.opts;
            var f = Math.floor((h.maxFontSize - h.minFontSize) * radius / j.maxValue)
                + h.minFontSize;
            return f
        };


        this.getImageWidth = function (radius) {
            var j = this._bar, h = this.opts;
            var f = (h.maxImgWidth - h.minImgWidth) * radius / j.maxValue
                + h.minImgWidth;
            return f
        },

        this.relocation = function (ball, k) {
            var balls = this._balls.slice(0),
                j = j || this.flashStrategy,
                placeholder = this.opts.placeholder;

            if (placeholder) {
                placeholder.forEach(function (holder) {
                    balls.push({cx: holder[0], cy: holder[1], radius: holder[2]});
                });
            }
            for (var i = 0; i < balls.length; i++) {
                var l = this.collided(balls[i], ball);
                if (l) {
                    if (k > 5) {
                        this._bar.totalDecay += this.opts.decay;
                        k = 0
                    }
                    $.extend(ball, this.randomPosition(ball.ratio));
                    this.relocation(ball, k + 1);
                    break
                }
            }
            //检测指定的占位区
            return ball;
        };

        /**
         * 碰撞检测
         * @param  {object} ball1 球体1
         * @param  {object} ball2 球体2
         */
        this.collided = function (ball1, ball2) {
            var k = ball1,
                j = ball2;
            var h = k.cx - j.cx,
                g = k.cy - j.cy,
                f = Math.pow(Math.pow(h, 2) + Math.pow(g, 2), 0.5),
                l = (k.radius === undefined ? this.getRadius(k.ratio) : k.radius) +
                    (j.radius === undefined ? this.getRadius(j.ratio) : j.radius) - f;
            if (l <= 0) {
                return false
            }
            return { x: -l * h / f, y: -l * g / f }
        };

        var randomInt = function (min, max) {
            return Math.floor(Math.random() * (max - min + 1) + min);
        };

        this.randomPosition = function (val) {
            var bar = this._bar,
                radius = this.getRadius(val, true);
            return {
                cx: randomInt(radius, bar.width - radius),
                cy: randomInt(radius, bar.height - radius)
            }
        };

        this.getRadius = function (val, b) {
            var bar = this._bar, opts = this.opts;
            var decay = bar.totalDecay;
            if (b) {
                decay = 0
            }
            var result = (opts.maxRadius - opts.minRadius) * val / bar.maxValue + opts.minRadius - decay;
            return result;
        }

        this.draw(data);
    };

    //inheritance
    var F = function () { };
    F.prototype = Raphael.g;
    Bubblechart.prototype = new F;

    //public
    Raphael.fn.bubblechart = function (values, opts) {
        return new Bubblechart(this, values, opts);
    }
})();