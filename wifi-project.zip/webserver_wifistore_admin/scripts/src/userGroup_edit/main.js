﻿(function () {
    var mAction = ACTION;
    //<?echo $ACTION;?>;
    var mGroupId = GROUPID;
    var selected;
    var Gname;

    function getGroupInfo() {
        var data;

        data = { "action": "select_one", "groupId": mGroupId };

        $.ajax({
            type: 'POST',
            url: ROOT +'/UserGroup/getSingleGroup',
            data: data,
            dataType: 'json',
            beforeSend: function () {

            },
            success: function (json) {
                switch (json.status) {
                    case 1000:
                        $("title").text("修改" + json.name + "的信息");
                        $(".panelhead").text("修改" + json.name + "的信息");
                        $("#group_name").find("input").val(json.name);
                        break;
                    case 1002:
                        $.gritter.error("不存在该权限组！");
                        break;
                    case 9999:
                        $.gritter.error("获取权限组信息时发生错误！");
                        break;
                    default:
                        $.gritter.error("发生未知错误！错误代码:" + json.status);
                        break;
                }
            },
            complete: function () {

            },
            error: function () {
                $.gritter.error("获取权限组信息时发生错误！请重试");
            }
        });
    }

    //--------------------- submit edited perms -------------------------------------

    function submitEditedGroup(data) {
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/' + (data.action == 'insert' ? "addGroup" : 'updateGroup'),
            data: data,
            dataType: 'json',
            beforeSend: function () {
                $("#submit_edited_group").attr("disabled", "disabled");
            },
            success: function (json) {
                if (json != null) {
                    switch (json.status) {
                        case 1000:
                            if (mAction == "edit") { 
                                $.gritter.success("修改成功！"); 
                            } else { 
                                $.gritter.success("添加成功！"); 
                            }
                            window.location.href = ROOT + '/UserGroup/userGroup_manager';
                            break;
                        case 2001:
                            $.gritter.warn("有信息为空！请填写后再提交");
                            break;
                        case 2002:
                            $.gritter.warn("用户组名格式不正确！");
                            break;
                        case 2003:
                            $.gritter.warn("用户组名已存在，请换名！");
                            break;
                        case 9999:
                            $.gritter.error("内部错误,提交失败！");
                            break;
                        default:
                            $.gritter.error("发生未知错误！错误代码:" + json.status);
                            break;
                    }
                }
            },
            complete: function () {
                $("#submit_edited_group").removeAttr("disabled");
            },
            error: function () {
                $.gritter.error("保存用户组信息时发生错误，请重试");
            }
        });
    }


    //--------------------- update inherit Group list -------------------------------------

    function updateGroupList(element, list) {
        $(element).find(".divRadio").each(function (index, e) { $(this).remove(); })
        $.each(list, function (index, array) { //遍历json数据列
            var status = "";
            if (array["default"] == "default") {
                status = "checked='checked'";
            }
            var $a = createRadio("radioLabel", "radioImage", "radio", array['groupName'], array['groupId'], status);
            $(element).append($a);
        });
        widgetStyleInit();
    }

    //--------------------- clear list ------------------------------------------
    function clearList() {
        $("#group_name").find("input").each(function (index, e) { $(this).text(""); })
        $("#group_list").find(".divRadio").each(function (index, e) { $(this).remove(); })
    }


    //--------------------- load perm lists -------------------------------------

    function getGroupList() {
        var data = { action: "select", type: "one", functions: "edit", groupId: mGroupId };
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/getUserGroup',
            data: data,
            dataType: 'json',
            beforeSend: function () {
                clearList();
            },
            success: function (json) {
                // $type=json.type;
                // alert(json.ttt);
                if (json != null) {
                    var Groups = json.groups;
                    if (mAction != "edit") {
                        updateGroupList("#group_list", Groups);
                    } else {
                        $('#group_list').remove();
                    }

                    initPage();
                } else {
                }
            },
            complete: function () {
            },
            error: function () {
                $.gritter.error("获取用户组信息时发生错误，请重试");
            }
        });
    }

    function initPage() {
        $("#submit_edited_group").live({
            click: function () {
                submitEditedGroup(getEditedGroup("#group_list", "#group_name"));
            }
        })

        if (mAction == "edit") {
            $("#submit_edited_group").val("提交修改");
            getGroupInfo();
        }
        else {
            $("#submit_edited_group").val("立刻添加");
        }
        $("#group_name").find("input").live({
            click: function (e) {
                $("#group_name").find("div.prompt").slideDown(100);
            },
            blur: function (e) {
                $("#group_name").find("div.prompt").slideUp(100);
            }
        });
    }

    function getEditedGroup(element, element2) {
        $(element).find(".divRadio").each(function (index, val) { //遍历json数据
            if ($(this).find("input").prop("checked"))
                selected = $(this).find("input").attr("id");
        });
        Gname = $(element2).find("input").val();
        var jsonData;
        if (mAction == "edit") {
            jsonData = { action: "update", name: Gname, group_id: mGroupId };
        }
        else {
            jsonData = { action: "insert", group_parent_id: selected, group_name: Gname };
        }
        return jsonData;
    }

    $(document).ready(function(e) {
        getGroupList();

    });
})();