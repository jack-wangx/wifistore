﻿(function () {
    $('select').select2();

    var deviceList = [];
    var projectList = [];
    var pList = [];
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>";
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>";
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>";


    $(document).ready(function () {
        getFilter();

        $('.panelcontent tbody').on('click', ".delBtn", function (e) {
            e.stopPropagation();
            delPackges($(this).attr('rel'));
        });
    });

    var bindSelectEvent = function () {
        $("#device").change(function () {
            var devicevalue = $("#device option:selected").val(),
                optHtml = '';
            if (devicevalue != '-1') {
                $('#project').empty();
                optHtml = "<option value='-1'>全部项目</option>";
                $.each(pList, function (index, array) {
                    if (array.device == devicevalue) {
                        optHtml += "<option value='" + array.project + "'>" + array.project + "</option>";
                    }
                });
            } else {
                selectInit(projectList, 'project');
            }
            $('#project').append(optHtml);
            getVersionList();
        });

        $("#project").change(function () {
            getVersionList();
        });
    };

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function (index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml).trigger('change');
    }

    function getFilter() {
        var data = { action: 'axo' };
        $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error("发生内部错误，未能获取设备、项目列表！");
                        return false;
                    }
                    if (json) {
                        pList = json;
                        $.each(pList, function (index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
                bindSelectEvent();
                getVersionList();
            },
            complete: function () { //生成分页条

            },
            error: function () {
                $.gritter.error('获取设备、项目列表时发生错误，请重试');
            }
        });
    }
    var rominfo;

    function getVersionList() {
        var mPv;
        if ($("#project option:selected").val() != '-1') mPv = $("#project option:selected").val();
        var mDv;
        if ($("#device option:selected").val() != '-1') mDv = $("#device option:selected").val();

        var data = { action: 'select' };
        if (mPv || mDv) {
            data = { action: 'select', pv: mPv, dv: mDv };
        }

        $.ajax({
            type: 'POST',
            url: ROOT + '/Fota/getVersion',
            data: data,
            dataType: 'json',
            beforeSend: function () {
                $("#status").empty();
                $("#task").empty();
                $("#status").append(loadingRow);
            },
            success: function (json) {
                if (json && json !== '') {
                    if (json.status && json.status !== '') {
                        switch (json.status) {
                            case 1002:
                                $("#task").empty();
                                $("#status").empty();
                                $("#status").append(emptyRow);
                                return false;

                            case 9999:
                                $("#task").empty();
                                $("#status").empty();
                                $("#status").append(failedRow);
                                break;
                            default:

                                break;
                        }
                    };
                    if (json.list && json.list.length > 0) {
                        var li = "";
                        var list = json.list;
                        rominfo = new Array();
                        $.each(list, function (index, array) { //遍历json数据列
                            rominfo[array['versionCode']] = array;

                            li += ["<tr rel='", array['versionCode'], "'>",
                                        "<td id='app'>" + array['devicemodel'] + "</td>",
                                        "<td>" + array['projectname'] + "</td>",
                                        "<td>" + array['versionCode'] + "</td>",
                                        "<td>" + array['uploadtime'] + "</td>",
                                        "<td>",
                                            "<button class='delBtn btn btn-small' rel='", array['versionCode'], "'><i class='icon-remove'></i> 删除</button>",
                                        "</td>",
                                    "</tr>"].join('');
                        });
                        $("#status").empty();
                        $("#task").empty();
                        $("#task").append(li);
                    } else {
                        $("#task").empty();
                        $("#status").empty();
                        $("#status").append(emptyRow);
                    }
                } else {
                    $("#task").empty();
                    $("#status").empty();
                    $("#status").append(failedRow);
                }


            },
            complete: function () { //生成分页条
            },
            error: function () {
                $("#task").empty();
                $("#status").empty();
                $("#status").append(failedRow);
                $.gritter.error("加载版本数据时发生错误，请重试")
            }
        });
    }

    function delPackges(versionCode) {
        if (confirm("确认删除？")) {
            var rom = rominfo[versionCode];
            data = { 'action': 'delete', 'axo_value': rom['axo_value'], 'versionCode': versionCode };

            $.ajax({
                type: 'POST',
                url: ROOT + '/Fota/delVersion',
                data: data,
                dataType: 'json',
                beforeSend: function () {
                },
                success: function (json) {

                    if (json) {
                        switch (json.status) {
                            case 1000:
                                $.gritter.success("删除版本成功")
                                getVersionList();
                                break;
                            case 4001:
                                $.gritter.warn("有相关的OTA包，无法删除此版本");
                                break;
                            case 9999:
                                $.gritter.error("系统错误，请联系管理员");
                                break;
                            default:
                                $.gritter.error("系统错误，请联系管理员");
                                break;
                        }
                    }
                },
                complete: function () { //生成分页条
                },
                error: function () {
                    $.gritter.error("删除版本时发生错误，请重试");
                }
            });
        }
    }

    $(function () {
        $(".panelcontent tbody").on('click', "tr", function() {
            var versionCode = $(this).attr('rel');
            var array = rominfo[versionCode];
            $("#rom").empty();
            var otas = array['otaInfo'];

            var otaTds = "<td>no ota</td>";
            if (otas && otas.length > 0) {
                otaTds = "";
                $.each(otas, function(index, ota) { //遍历json数据列

                    otaTds += ota + "</br>";
                });
            }

            var li = "<tr ><td><strong>机型:</strong></td><td>" + array['devicemodel'] + "</td></tr>" +
                "<tr ><td><strong>项目:</strong></td><td>" + array['projectname'] + "</td></tr>" +
                "<tr ><td><strong>版本号:</strong></td><td>" + array['versionCode'] + "</td></tr>" +
                "<tr ><td><strong>文件名:</strong></td><td>" + array['rompackgesname'] + "</td></tr>" +
                "<tr ><td><strong>md5值:</strong></td><td>" + array['md5value'] + "</td></tr>" +
                "<tr ><td><strong>文件大小:</strong></td><td>" + array['fileSize'] + "</td></tr>" +
                "<tr ><td><strong>上传时间:</strong></td><td>" + array['uploadtime'] + "</td></tr>" +
                "<tr ><td><strong>备注:</strong></td><td>" + array['versionRemark'] + "</td></tr>" +
                "<tr><td><strong>相关的OTA包:</strong></td><td>" + otaTds + "</td></tr>";


            $("#rom").append(li);
            $('#modal').modal('show');
        });
    });
})();
