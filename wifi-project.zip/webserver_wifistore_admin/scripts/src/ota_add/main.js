﻿(function() {
    var deviceList = new Array();
    var projectList = new Array();
    var pList = new Array();

    function projectInit(list, target) {
        var ulHtml = "";
        $(target).empty();
        if (list) {
            $.each(list, function(index, value) { //遍历json数据列
                ulHtml += "<li rel='" + value + "'>" + value + "</li>";
            });
        } else {
            ulHtml = "无可选项";
        }
        $(target).html(ulHtml);
    }

    function romInit(list, target) {
        var ulHtml = "";
        $(target).empty();
        if (list) {
            $.each(list, function(index, array) { //遍历json数据列
                ulHtml += "<li rel='" + array.rompackgesname + "' id='" + array.md5 + "'>" + array.versionCode + "</li>";
            });
        } else {
            ulHtml = "无可选项";
        }
        $(target).html(ulHtml);
        $('#target').triggerHandler('renderrom');
    }

    function getDeviceProject() {
        var data = { action: 'axo' };
        $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function() {
            },
            success: function(json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error('发生内部错误，未能获取项目列表！')
                        return false;
                    }
                    if (json) {
                        pList = json;
                        $.each(pList, function(index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        projectList = projectList.unique();
                        projectInit(deviceList, '#base .device ul');
                        projectInit(deviceList, '#target .device ul');
                    }
                } else {
                    projectInit(null, '#base .device ul');
                    projectInit(null, '#target .device ul');
                }
            },
            complete: function() { //生成分页条

            },
            error: function() {
                $.gritter.error('加载项目数据时出现错误，请重试');
                projectInit(null, '#base .device ul');
                projectInit(null, '#target .device ul');
            }
        });
    }

    function getRom(dv, pv, target) {
        var data = { action: 'select', devicemodel: dv, projectname: pv };
        $.ajax({
            type: 'POST',
            url: ROOT + '/Fota/getRom',
            data: data,
            dataType: 'json',
            beforeSend: function() {
            },
            success: function(json) {
                if (json) {
                    if (json.status == 2001) {
                        $.gritter.warn('未选择机型与项目！');
                        return false;
                    }
                    if (json.list) {
                        romInit(json.list, target);
                    } else {
                        romInit(null, target);
                    }
                } else {
                    romInit(null, target);
                }
            },
            complete: function() {
            },
            error: function() {
                $.gritter.error('加载Rom数据时出现错误，请重试');
                romInit(null, target);
            }
        });
    }

    function getProjectViaDevice(device) {
        var tmp = new Array();
        $.each(pList, function(index, array) {
            if (array.device == device) {
                tmp.push(array.project);
            }
        });
        return tmp;
    }

    $(document).ready(function() {
        getDeviceProject();
        $("#basepackges").click(function() {
            $('#base').slideDown(100);
            $('#selectedBase').slideUp(100);
            $("#postonename").attr("value", "");
            $("#postonenamever").attr("value", "");
            $('.panel2').slideUp(100);
            $('.panel3').slideUp(100);
            $("#targetpackges").click();
        });

        $("#targetpackges").click(function() {
            $('#target').slideDown(100);
            $('#selectedTarget').slideUp(100);
            $("#posttargetname").attr("");
            $("#posttargetnamever").attr("");
            $('.panel3').slideUp(100);
        });

        $('#base .device ul').on('click', 'li', function() {
            var device = $(this).attr('rel');
            $('#base .device ul li').removeClass('selected').removeAttr('selected');
            $(this).addClass('selected').attr('selected', 'selected');
            projectInit(getProjectViaDevice(device), "#base .project ul");
            $('#base .rom ul').empty();
            $('#base').triggerHandler('deviceselected', [device, this]);
        });
        $('#target .device ul').on('click', 'li', function() {
            var device = $(this).attr('rel');
            $('#target .device ul li').removeClass('selected').removeAttr('selected');
            $(this).addClass('selected').attr('selected', 'selected');
            projectInit(getProjectViaDevice(device), "#target .project ul");
            $('#target .rom ul').empty();
            $('#target').triggerHandler('renderproject');
        });
        $('#base .project ul').on('click', 'li', function() {
            var device = $('#base .device ul li[selected]').attr('rel');
            var project = $(this).attr('rel');
            $('#base .project ul li').removeClass('selected');
            $(this).addClass('selected');
            getRom(device, project, "#base .rom ul");
            $('#base').triggerHandler('projectselected', [project, this]);
        });
        $('#target .project ul').on('click', 'li', function() {
            var device = $('#target .device ul li[selected]').attr('rel');
            var project = $(this).attr('rel');
            $('#target .project ul li').removeClass('selected');
            $(this).addClass('selected');
            getRom(device, project, "#target .rom ul");
        });
        $('#base .rom ul').on('click', 'li', function() {
            $("#basename").empty();
            $("#basename").text($(this).text());
            $("#postonename").attr("value", $(this).attr('rel'));
            $("#postonenamever").attr("value", $(this).text());

            $('#base').slideUp(100);
            $('#selectedBase').slideDown(100);
            $('#base .rom ul li').removeClass('selected');
            $(this).addClass('selected');

            var romId = $(this).attr('id');
            $('#base').triggerHandler('romselected', [romId, this]);
        });
        $('#target .rom ul').on('click', 'li', function() {
            $("#targetname").empty();
            $("#targetname").text($(this).text());
            $("#posttargetname").attr("value", $(this).attr('rel'));
            $("#posttargetnamever").attr("value", $(this).text());
            $("#axo_value").attr("value", $(this).attr('id'));
            $('#target').slideUp(100);
            $('#selectedTarget').slideDown(100);
            $('#target .rom ul li').removeClass('selected');
            $(this).addClass('selected');
            $('#target').triggerHandler('romselected', [$(this).attr('id'), this]);
        });
    });

    $(function() {
        var renderProject = function() {
            var $targetProject = $('#target .project ul');
            var $targetRom = $('#target .rom ul');
            var baseProject = $('#base .project ul li.selected').attr('rel') || '';
            if (!baseProject) {
                return;
            }
            $targetProject.children('li.hidden, li.selected').removeClass('hidden selected');
            $targetRom.empty();
            var $tempProjects = $targetProject.children(':not([rel=' + baseProject + '])');
            $tempProjects.addClass('hidden');
            $visibleProjects = $targetProject.children(':not(li.hidden)');
            if ($visibleProjects.length == 1) {
                $visibleProjects.click();
            }
        };
        var renderRom = function() {
            var $targetRom = $('#target .rom ul');
            var baseRomId = $('#base .rom ul li.selected').attr('id') || '';
            if (!baseRomId) {
                return;
            }
            $targetRom.children('li.hidden, li.selected').removeClass('hidden selected');
            $targetRom.children('[id=' + baseRomId + ']').addClass('hidden');
            var $visibleRom = $targetRom.children(':not(.hidden)');
            if (!$visibleRom.length) {
                $targetRom.html('无可选项');
            }
        };

        $('#base').on('deviceselected', function(e, device, liEl) {
            var $targetDevice = $('#target .device ul');
            var $targetProject = $('#target .project ul');
            var $targetRom = $('#target .rom ul');

            $targetDevice.children('li.hidden, li.selected').removeClass('hidden selected');
            $targetProject.empty();
            $targetRom.empty();
            $targetDevice.children(':not([rel=' + device + '])').addClass('hidden');
            $targetDevice.children(':not(li.hidden)').click();
        }).on('projectselected', renderProject).on('romselected', function() {
            $('.panel2').show().slideUp(0).slideDown(100);
            renderRom();
        });
        $('#target').on('renderproject', renderProject).on('renderrom', renderRom).
            on('romselected', function(e, romId, liEl) {
                $('.panel3').show().slideUp(0).slideDown(100);
            });
        ;
    });
})();