﻿(function() {
    $(document).ready(function (e) {
        $('#version_part').slideUp(0);
        partChart();

    });

    function showVersion(project) {
        $('#project_part').slideUp(300);
        $('#version_part').slideDown(300);
        setTimeout(versionChart(project), 300);
    }
    window.showProject = function() {
        $('#version_part').slideUp(300);
        $('#project_part').slideDown(300);
        setTimeout(partChart(), 300);
    };

    function version_part_chart(bean, count, project) {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram_version_part',
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: true
            },
            title: {
                text: project
            },
            subtitle: {
                text: "全部地区(活跃设备:" + count + ")"
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage}%</b>',
                percentageDecimals: 1
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function () {
                            return '<b>' + this.point.name + '</b>: ' + this.percentage + ' %';
                        }
                    }
                }
            },
            series: [bean]
        });
    }

    function project_part_chart(bean, count) {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram_project_part',
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: true
            },
            title: {
                text: '项目分布'
            },
            subtitle: {
                text: '全部地区(活跃设备:' + count + ')'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage}%</b>',
                percentageDecimals: 1
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    events: {
                        click: function (e) {

                            showVersion(e.point.name);
                            //   window.href = 'http://www.google.com.hk'
                        }
                    },
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function () {
                            return '<b>' + this.point.name + '</b>: ' + this.percentage + ' %';
                        }
                    }
                }
            },
            series: [bean]
        });
    }

    function partChart() {
        var data = { action: 'select', type: 'pie', name: '设备占有率' };

        $.ajax({
            type: 'POST',
            url: ROOT + '/Fota/getVersionDistri',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error("发生内部错误，未能获取项目信息！");
                    } else if (json.status == 1000) {
                        mAxoProject = json.axo_project;
                        project_part_chart(json.bean, json.count);

                    } else if (json.status == 2001) {
                        setChart(nodata);
                    } else {
                        $.gritter.warn("没有项目信息！");
                    }
                }
            },
            complete: function () {

            },
            error: function () {
                $.gritter.error("获取项目信息时发生错误！");
            }
        });
    }

    var mProject;
    var mAxoProject;
    function versionChart(project) {
        mProject = project;
        var mAxoValue = mAxoProject[project];
        if (mAxoValue) {
            var data = { action: 'select_by_axo', axoValue: mAxoValue, type: 'pie', name: '设备占有率' };

            $.ajax({
                type: 'POST',
                url: ROOT + '/Fota/getVersionDistriByAxo',
                data: data,
                dataType: 'json',
                beforeSend: function () {
                },
                success: function (json) {
                    if (json) {
                        if (json.status == 9999) {
                            alert("发生内部错误，未能获取版本信息！");
                        } else if (json.status == 1000) {
                            version_part_chart(json.bean, json.count, project);
                        } else if (json.status == 2001) {
                            setChart(nodata);
                        } else {
                            $.gritter.warn("没有版本信息！");
                        }
                    }
                },
                complete: function () {

                },
                error: function () {
                    $.gritter.error("获取项目版本时发生错误！");
                }
            });
        }
    }
})();
