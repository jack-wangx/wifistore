﻿(function() {
    var mProjectValue = PROJECTVALUE;
    var mAction = ACTION;


    function getProject() {
        var data = { action: "select", type: "one", axo_value: mProjectValue };
        $.ajax({
            type: 'POST',
            url: ROOT + '/Project/getProjects',
            data: data,
            dataType: 'json',
            beforeSend: function () {
                clearList();
            },
            success: function (json) {
                if (json != null) {
                    var list = json.axo_details;
                    $.each(list, function (index, array) {
                        $("#devicename").find("input").val(array.device);
                        $("#projectname").find("input").val(array.project);
                        $("#devicename").find("input").attr("disabled", "disabled");
                        $("#projectname").find("input").attr("disabled", "disabled");
                        $(".panelhead").text("修改" + array.project + "的信息");
                        $.each(array.aro_group, function (index, array) {
                            $("#project_list").find("input").each(function (index, element) {
                                if ($(this).attr("id") == array.aro_group_id) {
                                    $(this).parent().find("label").click();
                                }
                            });
                        })
                    })
                } else {
                    $.gritter.error('获取项目信息时出现错误');
                }
            },
            complete: function () {
            },
            error: function () {
                $.gritter.error('获取项目信息时出现错误，请重试');
            }
        });
    }
    //--------------------- update inherit Group list -------------------------------------

    function updateGroupList(element, list) {
        $(element).find(".divCheck").each(function (index, e) { $(this).remove(); })
        $.each(list, function (index, array) { //遍历json数据列
            var status = "";
            if (array["default"] == "default") {
                status = "checked='checked'";
            }
            var $a = createCheck("checkLabel", "checkImage", "checkbox", array['groupName'], array['groupId'], status);
            $(element).append($a);
        });
        widgetStyleInit();
    }

    //--------------------- submit edited perms -------------------------------------

    function submitEditedProject(data) {

        $.ajax({
            type: 'POST',
            url: ROOT + '/Project/' + (data.action == 'update' ? 'updateProject' : 'addProject'),
            data: data,
            dataType: 'json',
            beforeSend: function () {
                $("#submit_edited_project").attr("disabled", "disabled");
            },
            success: function (json) {
                if (json != null) {
                    switch (json.status) {
                        case 1000:
                            if (mAction == "edit") { 
                                $.gritter.success('修改成功！')
                            }
                            else { 
                                $.gritter.success('添加成功！')
                            }
                            setTimeout(function () {
                                window.location.href = ROOT + '/Project/project_mgr';
                            }, 0);
                            break;
                        case 2001:
                            $.gritter.warn('有信息为空！')
                            break;
                        case 2002:
                            $.gritter.warn('项目或机型名格式不正确！')
                            break;
                        case 2003:
                            $.gritter.warn('该机型与项目已存在，请换名！')
                            break;
                        case 9999:
                            $.gritter.error('内部错误,提交失败！')
                            break;
                    }
                } else {
                    $.gritter.error('服务器无响应，通讯失败')
                }
            },
            complete: function () {
                $("#submit_edited_project").removeAttr("disabled");
            },
            error: function () {
                $.gritter.error('提交失败，未链接到网络')
                $("#submit_edited_project").removeAttr("disabled");
            }
        });
    }

    function getGroupList() {
        var data = { action: "select", type: "all", functions: "add" };
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/getUserGroup',
            data: data,
            dataType: 'json',
            beforeSend: function () {
                clearList();
            },
            success: function (json) {
                // $type=json.type;
                // alert(json.ttt);
                if (json != null) {
                    var Groups = json.groups;
                    if (mAction == "edit") {
                        $("#group_name").find("input").val(json.groupName);
                        Gname = json.groupName;
                    }
                    updateGroupList("#project_list", Groups);
                    initPage();
                } else {
                    $.gritter.error('获取用户组失败！');
                }
            },
            complete: function () {
            },
            error: function () {
                $.gritter.error('获取用户组失败！请重试');
            }
        });
    }

    function initPage() {
        $("#submit_edited_project").live({
            click: function () {
                if (getEditedProject("#project_list", "#devicename", "#projectname"))
                { submitEditedProject(getEditedProject("#project_list", "#devicename", "#projectname")) };

            }
        })

        if (mAction == "edit") {
            $("#submit_edited_project").val("提交修改");
            getProject();
        }
        else {
            $("#submit_edited_project").val("立刻添加");
        }
        $("#projectname").find("input").live({
            focus: function (e) {
                $("#projectname").find("div.prompt").slideDown(100);
            },
            blur: function (e) {
                $("#projectname").find("div.prompt").slideUp(100);
            }
        });
        $("#devicename").find("input").live({
            focus: function (e) {
                $("#devicename").find("div.prompt").slideDown(100);
            },
            blur: function (e) {
                $("#devicename").find("div.prompt").slideUp(100);
            }
        });
    }

    function getEditedProject(list, devicename, projectname) {
        var group_list = new Array();
        $(list).find(".divCheck").each(function (index, val) { //遍历json数据列
            if ($(this).find("input").prop("checked")) {
                var selected = $(this).find("input").attr("id");
                var group = { "id": selected };
                group_list.push(group);
            }
        });

        var devicename = $(devicename).find("input").val();
        var projectname = $(projectname).find("input").val();
        if (devicename == "" || devicename == null || projectname == "" || projectname == null) {
            $.gritter.info('请输入机型和项目名');
            return false;
        }
        if (mAction == "edit") {
            var jsonData = { "axo_value": mProjectValue, "groupList": group_list, "devicename": devicename, "projectname": projectname, "action": "update" };
        }
        else {
            var jsonData = { "groupList": group_list, "devicename": devicename, "projectname": projectname, "action": "insert" };
        }
        return jsonData;
    }

    function clearList() {
        $("#devicename").find("input").each(function (index, e) { $(this).text(""); })
        $("#projectname").find("input").each(function (index, e) { $(this).text(""); })
        $("#project_list").find(".divRadio").each(function (index, e) { $(this).remove(); })
    }

    $(document).ready(function (e) {
        getGroupList();
    })
})();