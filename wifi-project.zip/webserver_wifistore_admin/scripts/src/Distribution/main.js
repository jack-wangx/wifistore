﻿//生成随机数据

(function () {

    var pieColors = Color.randColors(30);

    $('select').select2();

    Jla.require("Ali.Map.Control.Cube");
    var map;
    var cubeControl;
    function onLoad() {
        //使用id为mapDiv的层创建一个地图对象
        //steplessZoom参数为true表示采用无级缩放的模式
        map = new AliMap("mapDiv");
        //map.setCursor("normal", "default");
        $('#mapDiv div:last').hide();
        //加入地图魔方功能支持
        var defaultColors = ['#C4DDFF'];
        cubeControl = new (Jla.get("Ali.Map.Control.Cube"))()
        cubeControl.setDefaultColors(defaultColors);
        cubeControl.setLabelVisibility('None');

        AliEvent.addListener(cubeControl, 'areaclick', function (place) {
            var adminCenter = place.adminCenter;
            var latLng = new AliLatLng(adminCenter.la, adminCenter.lo);
            var districtName = place.name + '(' + (cubeControl.data[place.name] || 0).toFixed(2) + '%) 的用户爱好排名';
            var hobbies = hobbyForDistrict[place.name];

            if (hobbies) {
                var html = '<div class="disctrict-pie-chart"></div>';
            } else {
                var html = '<div>暂无数据</div>';
            }

            //清除画布
            var $chart = $('.disctrict-pie-chart');
            var paper = $chart.data('paper');
            paper && paper.remove();

            var infoWin = map.openInfoWindow(latLng, districtName, html);

            setTimeout(function () {
                if (hobbies) {
                    infoWin.setContentSize(new AliPoint(260, 200));
                } else {
                    infoWin.setContentSize(new AliPoint(200, 40));
                }
                infoWin.moveIntoView();
                if (hobbies) {
                    drawPieChart(hobbies);
                }
            }, 1)
        });
        var drawPieChart = function (hobbies) {
            var data = [],
                labels = [];
            for (var i = 0; i < hobbies.length; i++) {
                var h = hobbies[i];
                data.push(h[1]);
                labels.push(h[0]);
            }
            var el = $('.disctrict-pie-chart')[0];
            var paper = Raphael(el, 260, 200);
            var opts = {
                legend: labels,
                legendpos: 'west',
                maxSlices: 8,
                legendothers: '其他'
            };
            Raphael.g.txtattr.cursor = 'pointer';
            chart = paper.piechart(150, 100, 60, data, opts);
            $(el).data('paper', paper);
            addInteractiveToPie(chart, paper, opts);
        };
        AliEvent.addListener(cubeControl, 'areafocus', function (place) {
            cubeControl.regionControl.setRegionShape(place, {
                weight: 2, color: "#FFDEA8"
            });
        });
        AliEvent.addListener(cubeControl, 'areablur', function (place) {
            cubeControl.regionControl.setRegionShape(place, {
                weight: 1, color: 'white'
            });
        });
        AliEvent.addListener(map, 'click', function (point, overlay, area) {
            if (!area) {
                map.closeInfoWindow();
            }
        });

        cubeControl.focusDistrict = function (district) {
            var place = this.getDistrictPlace(district);
            place && cubeControl.regionControl.setRegionShape(place, {
                weight: 2, color: "#DA542E"
            });
        };
        cubeControl.blurDistrict = function (district) {
            var place = this.getDistrictPlace(district);
            place && cubeControl.regionControl.setRegionShape(place, {
                weight: 1, color: 'white'
            });
        };
        /**
        根据行政区域名称，获取AliPlace对象
        */
        cubeControl.getDistrictPlace = function (districtName) {
            var places = this.placelist.allPlaces;
            for (var key in places) {
                place = places[key];
                if (place.name == districtName) {
                    return place;
                }
            }
        };
        cubeControl.onRegionFocus = function (place) {
            AliEvent.trigger(this, "areafocus", [place, this.areaConfig[place.code]]);
            AliEvent.trigger(this.map, "areafocus", [place, this.areaConfig[place.code]])
        };
        cubeControl.onRegionBlur = function (place) {
            AliEvent.trigger(this, "areablur", [place, this.areaConfig[place.code]]);
            AliEvent.trigger(this.map, "areablur", [place, this.areaConfig[place.code]])
        };
        /**
        设置一个区域的背景色
        */
        cubeControl.setRegionBgColor = function (place, color) {
            place.bgColor = color;
            regionControl = this.regionControl;
            regionControl.setRegionShape(place, {
                bgcolor: color,
                color: this.getBorderColor(),
                weight: this.getBorderWidth()
            });
        };
        /**
        获取一个区域的背景色
        */
        cubeControl.getRegionBgColor = function (place) {
            return place.bgColor || defaultColors[0];
        };
        /**
        设置一个区域的背景色
        */
        cubeControl.setDistrictBgColor = function (districtName, color) {
            var place = this.getDistrictPlace(districtName);
            if (place) {
                this.setRegionBgColor(place, color);
            }
        };

        cubeControl.setRegionLabel = function (place, text) {
            cubeControl.regionControl.showRegionLabel(place, 0, text);
        };

        cubeControl.setDistrictLabel = function (district, text) {
            var place = cubeControl.getDistrictPlace(district);
            this.setRegionLabel(place, text);
        };

        cubeControl.clearMap = function () {
            var allPlaces = this.placelist.allPlaces;
            for (var code in allPlaces) {
                if (code > 0) {
                    this.setRegionBgColor(allPlaces[code], defaultColors[0]);
                    this.setRegionLabel(allPlaces[code], ' ');
                }
            }
        };

        map.addControl(cubeControl);
        //开始显示地图
        cubeControl.showMap("0", {
            onShow: function (place) {
                //map.disableDragging();
                map.setZoom(4, true);
                map.setDblClickAction('none');
                map.setCenter(new AliLatLng(38.48719, 106.23090));//银川的坐标
                //displayAreaColor(usageData, usageMap);
                // timeline.setActive(new Date(Date.now()).getMonth() - 1);
                
                var month = new Date(Date.now9).getMonth();
                //todo remove
                month = 8;
                displayData(month, $('#category').val(), function () {
                    drawAreaLine();
                });
            }
        });

        var getScale = function (amt) {
            return amt / 3;
        };

        /**
        显示区域颜色
        */
        var displayAreaColor = function (data, dataMap) {
            map.closeInfoWindow();

            for (var i = 0; i < data.length; i++) {
                var temp = data[i];
                district = temp[0];
                amt = temp[1];
                var color = Color.darkenColor(defaultColors[0], getScale(amt));
                cubeControl.setDistrictBgColor(district, color);
                cubeControl.data = dataMap;
            }
        };

        $('#category').on('change', function () {
            var $sel = $(this);
            var catId = $sel.val();
            // var month = timeline.getMonth();
            displayData(new Date(Date.now()).getMonth(), catId);
        });


        // var timeline = new Timeline('.timeline');
        // timeline.on('active', function (e, $li, month) {
        //     var catId = $('#category').val();
        //     if (catId) {
        //         displayData(month, catId);
        //     }
        // }).on('startplay', function (e, currIndex) {
        //     timeline.autoPlay(1, 7, false);
        // });

        var displayData = function (month, catId, callback) {
            $.ajax({
                type: 'GET',
                dataType: 'json',
                url: ROOT + '/Distribution/getDistribution',
                data: {
                    month: month,
                    catId: catId
                }
            }).done(function (data) {
                $('.month-pane').html(month + '月');
                data = processData(data);
                var dataMap = {};
                $.map(data, function (d) {
                    dataMap[d[0]] = d[1];
                });
                displayAreaColor(data, dataMap);
                var colorMap = displayAreaPie(data);
                displayDistTable(data, colorMap);
                callback && callback.call(this, data);
            });
        };

        
    }
    Jla.onReady(onLoad);


    var lastPaper;
    var displayAreaPie = function (data) {
        var colorMap = {};
        lastPaper && lastPaper.remove();
        var paper = lastPaper = Raphael('pieChartDiv');
        var vals = [];
        var legends = [];
        var k = 9, kx = 0;
        var othersTotal = 0;
        for (var i = 0; i < data.length; i++) {
            d = data[i];
            if (d[0] != '其他' && kx < k) {
                vals.push(d[1]);
                legends.push(d[0]);
                kx++;
            } else {
                othersTotal += d[1];
            }
        }

        if (othersTotal > 0) {
            legends.push('其他省份');
            vals.push(othersTotal);
        }

        var result = vals.slice(0).map(function (val, i) {
            return {province: legends[i], value: val};
        }).sort(function (a, b) {
            return b.value - a.value;
        }).reduce(function (result, item, i) {
            result[item.province] = i;
            return result;
        }, {});

        paper.clear();
        var opts = {
            legend: legends,
            legendpos: 'east',
            minPercent: 0.1,
            colors: pieColors
        };
        Raphael.g.txtattr.cursor = 'pointer';
        var pie = paper.piechart(paper.width / 2 - 50, paper.height / 2, 100, vals, opts);
        $('#pieChartDiv').data('pie', pie);
        addInteractiveToPie(pie, paper, opts);
        pie.on('activated', function () {
            var district = opts.legend[this.value.order];
            var $tr = $('#tr_' + district).addClass('active');
            var $colorBlock = $tr.find('.color-block');
            $colorBlock.stop().animate({
                scaleX: 1.2, scaleY: 1.2
            }, 300, 'easeOutBounce');
            cubeControl.focusDistrict(district);
        }).on('deactivated', function () {
            var district = opts.legend[this.value.order];
            var $tr = $('#tr_' + district).removeClass('active');
            var $colorBlock = $tr.find('.color-block');
            $colorBlock.stop().animate({
                scaleX: 1, scaleY: 1
            }, 300, 'easeOutBounce');
            cubeControl.blurDistrict(district);
        });

        $(window).off('.distribution')
            .on('resize.distribution', function () {
                if (lastPaper) {
                    lastPaper.remove();
                    lastPaper = null;
                }
                this.redrawTimer && clearTimeout(this.redrawTimer);
                this.redrawTimer = setTimeout(function () {
                    displayAreaPie(data);
                    var $lineAreaChart = $('#lineAreaChart');
                    var chart = $lineAreaChart.data('chart');
                    chart && chart.redraw($lineAreaChart.width(), $lineAreaChart.height());
                }, 50);
            });

        return result;
    };

    var displayDistTable = function (data, colorMap) {
        var buffer = [];
        for (var i = 0; i < data.length; i++) {
            var item = data[i];
            var str = '<tr data-index="' + colorMap[item[0]] + '" data-province="' + item[0] + '" id="tr_' + item[0] + '">'+
                        '<td><span class="color-block" style="background-color:' +
                        (pieColors[colorMap[item[0]]] || pieColors[i] || 'transparent') +
                        '"></span></td><td>' + item[0] + '</td><td>' +
                        item[1].toFixed(2) + '%</td><td>' + item[2] + '</td></tr>';
            buffer.push(str);
        }
        $('#distTable tbody').html(buffer.join(''));
    };

    var addInteractiveToPie = function (pie, paper, opts) {
        pie.on('activated', function fin() {
            TweenLite.to(this.sector, .5, {
                raphael: {
                    scaleX: 1.1, scaleY: 1.1,
                    localPivot: { x: this.cx, y: this.cy }
                },
                ease: Bounce.easeOut
            });

            if (this.label) {
                TweenLite.to(this.label[0], .5, { raphael: { r: 7.5 }, ease: Bounce.easeOut });
                this.label[1].attr({ "font-weight": 800 });
            }

            var districtName = opts.legend[this.value.order];
            var percentage = districtName + " " + (this.value * 100 / this.total).toFixed(2) + '%';
            var tempTip = this.sector.tempTip = paper.text(paper.width / 2, this.cy - this.r - this.r / 2.3, percentage);
            tempTip.attr({ opacity: 0.1, 'font-size': '20px', 'font-weight': '400' });
            tempTip.animate({ opacity: 0.8 }, 300, 'linear')
        }).on('deactivated', function fout() {
            TweenLite.to(this.sector, .5, {
                raphael: {
                    scaleX: 1, scaleY: 1,
                    localPivot: { x: this.cx, y: this.cy }
                },
                ease: Bounce.easeOut
            });

            if (this.label) {
                TweenLite.to(this.label[0], .5, { raphael: { r: 5 }, ease: Bounce.easeOut });
                this.label[1].attr({ "font-weight": 400 });
            }
            if (this.sector.tempTip) {
                this.sector.tempTip.stop();
                this.sector.tempTip.remove();
            }
        });
    };

    $('#distTable').on('mouseenter', 'tbody tr', function () {
        var index = $(this).data('index');
        if (!$('#pieChartDiv').data('pie').setActive(index, true)) {
            cubeControl.focusDistrict($(this).data('province'));
        }
        $('#lineAreaChart').data('chart').highlightArea($(this).data('province'));
    }).on('mouseleave', 'tbody tr', function () {
        var index = $(this).data('index');
        if (!$('#pieChartDiv').data('pie').setActive(index, false)) {
            cubeControl.blurDistrict($(this).data('province'));
        }
        $('#lineAreaChart').data('chart').removeHighlight($(this).data('province'));
    });

})();

var processData = function (data, sorted) {
    //todo remove
    var total = 0;
    sorted = sorted === undefined ? true : sorted;
    for (var i = 0; i < data.length; i++) {
        var d = data[i];
        total += d[1];
    }
    for (i = 0; i < data.length; i++) {
        data[i][0] = data[i][0].replace(/(省|市|壮族自治区|维吾尔自治区)/, '');
        data[i][1] = data[i][1] * 100 / total; //todo remove
        data[i][2] = (data[i][1] * 100000).toFixed(0);
    }
    if (sorted) {
        data = data.sort(function (a, b) {
            return b[1] - a[1];
        });
    }
    return data;
};

(function () {
    $('.help-bt').tooltip({
        html: true,
        title: function () {
            return $(this).find('span').html();
        }
    });
})();


var drawAreaLine = function () {
    var getDistribution = function (month, callback) {
        return $.ajax({
            type: 'GET',
            dataType: 'json',
            url: ROOT + '/Distribution/getDistribution',
            data: {
                month: month,
                catId: $('#category').val()
            }
        }).done(function (data) {
            data = processData(data, false);
            data = data.reduce(function (result, item) {
                result[0].push(item[0]);
                result[1].push([[month - 2, item[2]]]);
                return result;
            }, [[], []]);
            callback.call(this, data[0], data[1]);
        });
    };

    var paper = Raphael('lineAreaChart'),
        chart = null;
    [2, 3, 4, 5, 6, 7, 8].reduce(function(promise, month) {
        if (!promise) {
            return getDistribution(month, function (provinces, data) {
                chart = paper.arealinechart(0, 30, $('#lineAreaChart').width(), 500, data, {
                    xAlias: {
                        values: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
                        renderer: function (value) {
                            return (value + 2) + '月';
                        }
                    },
                    areas: provinces,
                    colors: Color.getColorsFromTransition(['#207EFF', '#91C0FF', '#BF5B30'], data.length) //从渐变色中均匀的取n个颜色值
                });
                $('#lineAreaChart').data('chart', chart);
            });
        } else {
            return promise.then(function () {
                return getDistribution(month, function (provinces, data) {
                    chart.appendData(data);
                });
            });
        }
    }, null);
};