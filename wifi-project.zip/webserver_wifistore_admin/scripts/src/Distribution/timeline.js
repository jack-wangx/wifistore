﻿function Timeline(selector) {
    var $el = $(selector),
        _currIndex = 0,
        _len = $el.find('li').length,
        _loopTimer = -1,
        _duration = 1000,
        _isPlaying = false,
        me = this;
    $el.find('li').on('mouseenter', function () {
        var $li = $(this);
        if (!$li.hasClass('active')) {
            $li.find('span').show().fadeOut(0).stop().fadeIn(300);
        }
    }).on('mouseleave', function () {
        var $li = $(this);
        if (!$li.hasClass('active')) {
            $li.find('span').stop().fadeOut(300);
        }
    });

    $el.find('li i').on('click', function () {
        var $li = $(this).parent();
        if (!$li.hasClass('active')) {
            _setActive($li);
        }
    });

    $el.find('.play').on('click.timeline', function () {
        $play = $(this);
        if (!$play.hasClass('playing')) {
            $play.removeClass('icon-play').addClass('playing icon-pause')
                .attr('title', '暂停');
            $el.trigger('startplay', _currIndex);
        } else {
            me.stopPlay();
        }
    });

    this.on = function (eventName, handler) {
        $el.on(eventName, handler);
        return this;
    };

    this.setActive = function (index) {
        _setActive($el.find('li').eq(index));
        return this;
    };

    this.autoPlay = function (from, stop, loop, duration) {
        _duration = duration || _duration;
        var start = from || _currIndex || 0;
        _loopActive(start, start, stop, loop);
        return this;
    };

    this.stopPlay = function () {
        clearTimeout(_loopTimer);
        _isPlaying = false;
        var $play = $el.find('.play');
        $play.removeClass('playing icon-pause').addClass('icon-play')
            .attr('title', '播放');
        $el.trigger('stopplay');
        return this;
    };

    this.getMonth = function () {
        if (_currIndex) {
            return parseInt($el.find('li.active').text());
        } else {
            return -1;
        }
    };

    var _setActive = function ($li) {
        var $preActiveLi = $el.find('li.active');
        $preActiveLi.find('span').stop().fadeOut(300);
        $preActiveLi.removeClass('active');
        $li.addClass('active');
        _currIndex = $li.index();
        $el.trigger('active', [$li, parseInt($li.text())]);
        var $span = $li.find('span');
        $span.show().fadeOut(0).stop().fadeIn(300);
    };

    var _loopActive = function (index, startIndex, stopIndex, loop, force) {
        if (!_isPlaying || force) {
            _isPlaying = true;
            me.setActive(index);
            if (index < stopIndex) {
                _loopTimer = setTimeout(function () {
                    _loopActive(index + 1, startIndex, stopIndex, loop, true);
                }, _duration);
            } else if (loop) {
                _loopTimer = setTimeout(function () {
                    _loopActive(startIndex, startIndex, stopIndex, loop, true);
                }, _duration);
            } else {
                me.stopPlay();
            }
        }
    };
}
