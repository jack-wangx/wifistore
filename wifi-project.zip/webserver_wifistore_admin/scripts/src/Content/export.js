/**
 * 将json数据处理成jquery.DataTable控件需要的格式
 * @param  {json} data 后台返回的原始json对象
 * @return {json} jquery.DataTable需要的json格式 [look here](www.datatables.net/usage/server-side)
 */
var preprocessData = function (response) {
    var result = {
        aaData: response.data,
        iTotalRecords: response.total,
        iTotalDisplayRecords: response.total
    };
    return result;
};

(function () {
    $('#datetime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 10,
        format: 'YYYY-MM-DD HH:mm',
        timePicker12Hour: false,
        opens: 'left',
        startDate: g_lastExportTime,
        endDate: g_nowTime,
        showDropdowns: true,
        minDate: '2014-01-01',
        locale: {
            applyLabel: '确定',
            cancelLabel: '取消',
            fromLabel: '起始时间',
            toLabel: '截止时间',
            daysOfWeek: "日_一_二_三_四_五_六".split("_"),
            monthNames: "1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月".split("_")
        }
    }, function (start, end) {
        $('#startDate').val(start.format('YYYY-MM-DD HH:mm'));
        $('#endDate').val(end.format('YYYY-MM-DD HH:mm'));

        //重新加载数据
        dataTable.fnPageChange(0);
    });

    var dataTable = $('#contentTable').dataTable({
        "bJQueryUI": true,
        "sPaginationType": "full_numbers",
        "sDom": 't<"F"ip>',
        'sAjaxSource': ROOT + '/Content/exportList',
        'bServerSide': true,
        'iDisplayLength': 20,
        'fnServerParams': function (params) {
            params.push({name: 'startDate', value: $('#startDate').val() });
            params.push({name: 'endDate', value: $('#endDate').val() });

            paramsMap = params.reduce(function (result, item) {
                result[item.name] = item.value;
                return result;
            }, {});
            params.push({name: 'startIndex', value: paramsMap.iDisplayStart || 0});
            params.push({name: 'pageSize', value: paramsMap.iDisplayLength});
            for (var i = 0; i < params.length; i++) {
                var item = params[i];
                if (item.name.indexOf('iSortCol') != -1) {
                    var colIndex = item.value;
                    if (paramsMap['bSortable_' + colIndex]) {
                        var sortIndex = item.name.split('_')[1];
                        var sortDir = paramsMap['sSortDir_' + sortIndex];
                        var filedName = paramsMap['mDataProp_' + colIndex];
                        params.push({name: 'sort', value: filedName + ' ' + sortDir});
                        break;
                    }
                }
            }
        },
        "fnRowCallback": function (nRow, aData, iDisplayStart, iDisplayIndexFull) {
            $(nRow).data('uuid', aData['contentUuid']);
        },
        "fnServerData": function (url, params, fnCallback, oSettings) {
            var timerId = setTimeout(function () {
                NProgress.set(Math.random() * 0.4);
                NProgress.inc();
            }, 300);
            $(oSettings.nTBody).html('');
            oSettings.jqXHR = $.ajax({
                "dataType": 'json',
                "type": "GET",
                "url": url,
                "data": params,
                "success": function (data) {
                    timerId && clearTimeout(timerId);
                    timerId = null;
                    $(oSettings.nTBody).data('data', data); //保存一份原始数据，以供其他功能使用
                    data = preprocessData(data);
                    fnCallback(data);
                    NProgress.done();
                },
                'error': function ($xhr, txtStatus, msg) {
                    $.gritter.error('请求数据出错: ' + txtStatus + ', ' + msg);
                }
            });
        },
        'aoColumns': [
            {
                'mData': 'type', 'aTargets': [0],
                'mRender': function (type) {
                    var typeDesc = {
                        'soft': '应用',
                        'game': '游戏',
                        'video': '视频',
                        'music': '音乐',
                        'picture': '图片'
                    };
                    return typeDesc[type];
                }
            },
            {
                'mData': 'iconUrl', 'aTargets': [1], 'bSortable': false,
                'mRender': function (iconUrl, type, full) {
                    return '<img src="' + iconUrl + '" class="content-icon" />';
                }
            },
            { 'mData': 'name' },
            { 'mData': 'author' },
            { 'mData': 'createTime' },
            { 'mData': 'updateTime' }
        ]
    });

    $('#exportBtn').on('click', function () {
        var $btn = $(this),
            startDate = $('#startDate').val(),
            endDate = $('#endDate').val();
        $btn.button('loading');
        $(window).on('beforeunload', function () {
            return '更新包正在生成，请耐心等待\n若刷新或者离开页面，需要重新生成更新包！';
        });
        $.ajax({
            url: ROOT + '/Content/makeOTA',
            type: 'POST',
            dataType: 'json',
            data: {
                startDate: startDate,
                endDate: endDate
            },
            success: function (data) {
                if (data.status == 1000) {
                    $.gritter.success('生成更新包成功! 下载马上开始');
                    var downUrl = ROOT + '/Content/downloadExportZip?startDate=' + startDate + '&endDate=' + endDate;
                    $('#downloadIfrm').prop('src', downUrl);
                } else {
                    $.gritter.error(data.msg);
                    $btn.button('reset');
                }
            },
            error: function ($xhr, txtStatus, msg) {
                $.gritter.error('请求数据出错: ' + txtStatus + ', ' + msg);
                $btn.button('reset');
            }
        }).always(function () {
            $(window).off('beforeunload');
        });
    });
})();
