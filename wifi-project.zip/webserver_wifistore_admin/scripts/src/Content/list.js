/**
 * 将json数据处理成jquery.DataTable控件需要的格式
 * @param  {json} data 后台返回的原始json对象
 * @return {json} jquery.DataTable需要的json格式 [look here](www.datatables.net/usage/server-side)
 */
var preprocessData = function (response) {
    var result = {
        aaData: response.data,
        iTotalRecords: response.total,
        iTotalDisplayRecords: response.total
    };
    return result;
};

var dataTable = $('#contentTable').dataTable({
    "bJQueryUI": true,
    "sPaginationType": "full_numbers",
    "sDom": 't<"F"ip>',
    'sAjaxSource': ROOT + '/Content/getList',
    'bServerSide': true,
    'iDisplayLength': 20,
    'fnServerParams': function (params) {
        params.push({name: 'type', value: gType});
        $filterWords = $('#filterWords');
        var filterWords = $.trim($filterWords.val());
        if (filterWords) {
            params.push({name: 'filterWords', value: filterWords});
        }
        paramsMap = params.reduce(function (result, item) {
            result[item.name] = item.value;
            return result;
        }, {});
        params.push({name: 'startIndex', value: paramsMap.iDisplayStart || 0});
        params.push({name: 'pageSize', value: paramsMap.iDisplayLength});
        for (var i = 0; i < params.length; i++) {
            var item = params[i];
            if (item.name.indexOf('iSortCol') != -1) {
                var colIndex = item.value;
                if (paramsMap['bSortable_' + colIndex]) {
                    var sortIndex = item.name.split('_')[1];
                    var sortDir = paramsMap['sSortDir_' + sortIndex];
                    var filedName = paramsMap['mDataProp_' + colIndex];
                    params.push({name: 'sortField', value: filedName + ' ' + sortDir});
                    break;
                }
            }
        }
    },
    "fnRowCallback": function (nRow, aData, iDisplayStart, iDisplayIndexFull) {
        $(nRow).data('uuid', aData['contentUuid']);
    },
    "fnServerData": function (url, params, fnCallback, oSettings) {
        var timerId = setTimeout(function () {
            NProgress.set(Math.random() * 0.4);
            NProgress.inc();
        }, 300);
        $(oSettings.nTBody).html('');
        oSettings.jqXHR = $.ajax({
            "dataType": 'json',
            "type": "GET",
            "url": url,
            "data": params,
            "success": function (data) {
                timerId && clearTimeout(timerId);
                timerId = null;
                $(oSettings.nTBody).data('data', data); //保存一份原始数据，以供其他功能使用
                data = preprocessData(data);
                fnCallback(data);
                NProgress.done();
            }
        });
    },
    'aoColumns': g_aoData
});

(function () {
    $('#contentTable').on('click', 'a.fancybox', function (e) {
        $.fancybox.open($(this).parent().find('a.fancybox'));
        e.preventDefault();
    });
})();
