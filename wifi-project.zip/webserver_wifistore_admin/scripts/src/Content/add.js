var toStr = Object.prototype.toString;

(function () {
    var now = new Date(),
        year = now.getYear() + 1900,
        years = [];
    for(var i = 0; i <= 50; i++) {
        var temp = year - i;
        years.push('<option value="' + temp + '">' + temp + '</option>');
    }
    var html = years.join('');
    $('#videoYear, #musicYear').html(html).each(function () {
        $select = $(this);
        var val = $select.data('value');
        if (val) {
            $select.val($select.data('value'));
        }
    });

    $('.screenshot-preview').on('click', '.cancel-btn', function () {
        var $btn = $(this);
        var val = $btn.data('value');
        if (val) {
            var $deletedPics = $btn.parents('form').find('[name=deletedPics]');
            var deletedPics = $deletedPics.val();
            deletedPics += ',' + val;
            $deletedPics.val(deletedPics);
        }
        $btn.parents('li').remove();
    });

    $('[name=category]').each(function () {
        var $sel = $(this),
            type = $sel.data('type');

        var fillSelect = function (data) {
            var html = data.map(function (d) {
                return '<option value="' + d.id + '">' + d.name + '</option>';
            }).join('');
            var selValue = $sel.data('value');
            $sel.html(html).select2({
                width: 414
            });
            if (selValue) {
                var categoryIds = selValue.split(','),
                    mainCatId = g_categories[type],
                    mainCatIndex = categoryIds.indexOf(mainCatId);

                categoryIds.splice(mainCatIndex, 1);
                selValue && $sel.select2('val', categoryIds);
            }
        };

        $.ajax({
            url: ROOT + '/Content/category',
            type: 'GET',
            data: {
                categoryId: g_categories[type]
            },
            dataType: 'json',
            success: function (data) {
                fillSelect(data);
            },
            error: function () {
                $.gritter.error('加载分类数据失败, 请刷新页面');
            }
        });
    });
})();

(function () {
    var initZipUploader = function (type) {
        if (toStr.call(type) === '[object Array]') {
            type.forEach(function (t, i) {
                initZipUploader(t)
            });
            return;
        }
        var zipInputId = '#' + type + 'ZipFile',
            zipUploadBtnId = '#' + type + 'ZipUpload',
            zipFileNameSpanId = '#' + type + 'ZipFileName';
        $(zipInputId).fileupload({
            autoUpload: false,
            acceptFileTypes: /(\.|\/)(zip)$/i
        }).on('fileuploadprocessalways', function (e, data) {
            var index = data.index,
                file = data.files[index];
            if (file.error) {
                $.gritter.error(file.error);
                if (!data.files.length) {
                    $(zipUploadBtnId).hide();
                }
            } else {
                var fileName = data.files[0].name;
                $(zipFileNameSpanId).text(fileName);
                $(zipInputId).attr('title', fileName + ', 点击重新选择');
                $(zipUploadBtnId).show();
            }
        });
        $(zipUploadBtnId).click(function () {
            $(zipInputId).fileupload('disable');
            $this = $(this);
            $this.button('loading');
            var jqXHR = $(zipInputId).fileupload('send')
                .done(function (result) {
                    var id = result.data.id;
                    window.location.replace(ROOT + '/Content/update?type=' + type + '?id=' + id);
                })
                .fail(function (jqXHR, textStatus) {
                    $(zipInputId).fileupload('enable');
                    $this.button('reset');
                });
        });
    };

    var initMainFileUploader = function (type) {
        if (toStr.call(type) === '[object Array]') {
            type.forEach(function (t, i) {
                initMainFileUploader(t)
            });
            return;
        }
        var fileInputId = '#' + type + 'File',
            fileNameSpanId = '#' + type + 'FileName',
            contentUuidId = '#' + type + 'UUID',
            contentNameId = '#' + type + 'Name';
            fileTypes = {
                'soft': /(\.|\/)(apk)$/i,
                'game': /(\.|\/)(apk)$/i,
                'video': /(\.|\/)(mp4)$/i,
                'music': /(\.|\/)(mp3)$/i,
                'picture': /(\.|\/)(jpe?g|png)$/i,
            };
        $(fileInputId).fileupload({
            url: typeof(isUpdate) =="undefined" ? ROOT + '/Content/uploadMain' : ROOT + '/Content/uploadForUpdate',
            autoUpload: false,
            acceptFileTypes: fileTypes[type],
            replaceFileInput: false,
            formData: {
                type: type,
                contentUuid: $(contentUuidId).val()
            }
        }).on('fileuploadprocessalways', function (e, data) {
            var index = data.index,
                file = data.files[index];
            if (file.error) {
                $.gritter.error(file.error);
            } else {
                var fileName = data.files[0].name;
                $(fileNameSpanId).text(fileName);
                $(fileInputId).attr('title', fileName + ', 点击重新选择');
                //自动根据app文件名设置应用名称
                var $contentName = $(contentNameId);
                if ($contentName.data('auto')) {
                    var name = fileName.split('.');
                    name.splice(-1);
                    $contentName.val(name.join('.')).data('auto', 'true');
                }
                $(this).data('file', file);
            }
        });
    };

    var initScreenshotUploader = function (type) {
        if (toStr.call(type) === '[object Array]') {
            type.forEach(function (t, i) {
                initScreenshotUploader(t)
            });
            return;
        }

        var fileInputId = '#' + type + 'Screenshot',
            previewDivId = '#' + type + 'ScreenshotPreview',
            contentUuidId = '#' + type + 'UUID';

        $(fileInputId).fileupload({
            url: ROOT + '/Content/upload',
            autoUpload: false,
            previewMaxWidth: 40,
            previewMaxHeight: 68,
            acceptFileTypes: /(\.|\/)(jpe?g|png)$/i,
            previewCrop: true,
            replaceFileInput: false,
            formData: {
                type: type,
                inputName: 'screenshot'
            }
        }).on('fileuploadprocessalways', function (e, data) {
            var index = data.index,
                file = data.files[index];

            if (file.error) {
                $.gritter.error(file.error);
            } else if (file.preview) {
                var html = [
                    '<li>',
                        '<a title="移除" href="javascript:void(0)" data-index="',
                        index, '" class="cancel-btn btn btn-danger">',
                            '<i class="icon-remove-circle"></i>',
                        '</a>',
                    '</li>'
                ].join('');

                var $node = $(html).appendTo(previewDivId);
                $node.prepend(file.preview).data('file', file);
            }
        });
    };

    var initSinglePicUploader = function (inputId) {
        if (toStr.call(inputId) === '[object Array]') {
            inputId.forEach(function (t, i) {
                initSinglePicUploader(t)
            });
            return;
        }
        var formData = {
                type: inputId == '#videoCover' ? 'video'
                                    : inputId == '#musicCover' ? 'music' : 'picture'
            };

        var url = ROOT + '/Content/uploadMain';
        if (typeof(isUpdate) != 'undefined') {
            url = ROOT + '/Content/uploadForUpdate';
        }

        if (inputId != '#pictureFile') {
            formData.inputName = 'cover';
            url = ROOT + '/Content/upload';
        }
        $(inputId).fileupload({
            url: url,
            autoUpload: false,
            previewMaxWidth: inputId == '#pictureFile' ? 240 : 160,
            previewMaxHeight: inputId == '#pictureFile' ? 400 : 120,
            acceptFileTypes: /(\.|\/)(jpe?g|png)$/i,
            previewCrop: true,
            replaceFileInput: false,
            formData: formData
        }).on('fileuploadprocessalways', function (e, data) {
            var index = data.index,
                file = data.files[index];

            if (file.error) {
                $.gritter.error(file.error);
            } else if (file.preview) {
                var $preview = $(inputId).parent().next('.cover-preview');
                $preview.empty().prepend(file.preview);
                if (inputId != '#pictureFile') {
                    $preview.data('file', file);
                }
            }
        });
    };

    var submitFile = function (target) {
        if (toStr.call(target) == '[object Array]') {
            var $input = $(target[0]),
                $fileEl = $(target[1]);
        } else {
            var $input = $(target),
                $fileEl = $(target);
        }
        var contentUuid = $input.parents('form').find('[name=contentUuid]').val(),
            formData = $input.fileupload('option', 'formData');
        formData.contentUuid = contentUuid;
        var def = new $.Deferred();
        def.resolve();
        $fileEl.each(function () {
            var $temp = $(this);
            def = def.then(function () {
                if ($temp.data('file')) {
                    return $input.fileupload('send', {
                        files: [$temp.data('file')],
                        paramName: 'file',
                        dataType: 'json',
                        formData: formData
                    });
                }
            }, function () {
                $temp.addClass('upload-error');
                $.gritter.error('上传文件的过程中出错');
            });
        });
        return def;
    };
    var submitForm = function (formId) {
        $form = $('#' + formId);
        var data = $form.serializeArray().reduce(function (result, item) {
            result[item.name] = item.value;
            return result;
        }, {});

        var contentUuid = data.contentUuid,
            type = data.type,
            delPics = data.deletedPics && data.deletedPics.substr(1).split(','),
            categoryIds = $form.find('[name=category]').select2('val');

        delete data.contentUuid;
        delete data.type;
        delete data.deletedPics;
        delete data.category;

        categoryIds.unshift(g_categories[type]);
        return $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            data: {
                contentUuid: contentUuid,
                type: type,
                delPics: delPics,
                categoryIds: categoryIds,
                data: data
            },
            dataType: 'json'
        });
    };
    var listenForm = function (formId, fields) {
        var $form = $('#' + formId);
        $form.on('submit', function (e) {
            var $submitBt = $form.find('button[type=submit]');
            $submitBt.button('loading');
            var firstFileInput = fields[0],
                def = submitFile(firstFileInput),
                guid;
            if ($(firstFileInput).data('file')) {
                def.done(function (data) {
                    guid = data.uuid;
                    $form.find('[name=contentUuid]').val(guid);
                });
            }
            for(var i = 1; i < fields.length; i++) {
                var field = fields[i];
                def = def.then((function (field) {
                    return function () {
                        return submitFile(field)
                    }
                })(field));
            }
            def = def.then(function () {
                return submitForm(formId);
            });
            def.done(function () {
                $.gritter.success('保存成功');
                $submitBt.text('保存成功!');
            }).fail(function () {
                $.gritter.error('保存失败');
                $submitBt.button('reset');
            });
            e.preventDefault();
        });
    };

    initZipUploader(['soft', 'game', 'video', 'music', 'picture']);
    initMainFileUploader(['soft', 'game', 'video', 'music', 'picture']);
    initScreenshotUploader(['soft', 'game', 'video']);
    initSinglePicUploader(['#videoCover', '#musicCover', '#pictureFile']);

    var processQueue = {
        'addSoft': ['#softFile', ['#softScreenshot', '#softScreenshotPreview li']],
        'addGame': ['#gameFile', ['#gameScreenshot', '#gameScreenshotPreview li']],
        'addVideo': ['#videoFile', ['#videoCover', '#videoCoverPreview'], ['#videoScreenshot', '#videoScreenshotPreview li']],
        'addMusic': ['#musicFile', ['#musicCover', '#musicCoverPreview']],
        'addPicture': ['#pictureFile']
    };

    for(var formId in processQueue) {
        listenForm(formId, processQueue[formId]);
    }
})();
