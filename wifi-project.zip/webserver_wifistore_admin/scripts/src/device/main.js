﻿(function () {

    $('select').select2();

    var preprocessData = function (data) {
        var result = {
            iTotalRecords: data.totals || 0,
            iTotalDisplayRecords: data.totals || 0,
            aaData: data.list || []
        };
        return result;
    };

    var createDataTable = function (tableEl, ajaxUrl, extraParams) {
        var dataTable = $(tableEl).dataTable({
            "bJQueryUI": true,
            "sPaginationType": "full_numbers",
            "sDom": 't<"F"ip>',//'<""l>t<"F"fp>',
            'sAjaxSource': ajaxUrl,
            'bServerSide': true,
            "iDisplayLength": 4,
            'aoColumns': [
                {"mData": "i"},
                {"mData": "province",
                    "mRender": function (data, type, full) {
                        return data || '未知省份';
                    }
                },
                {"mData": "total"}
            ],
            "fnServerParams": function (params) {
                var mPv = $('#project').val(),
                    mDv = $('#device').val(),
                    iDisplayStart = 0,
                    iDisplayLength = 10;

                if (mPv != -1) params.push({name: 'pv', value: mPv});
                if (mDv != -1) params.push({name: 'dv', value: mDv});
                for (var i = 0; i < params.length; i++) {
                    var param = params[i];
                    if (param.name == 'iDisplayStart') {
                        iDisplayStart = param.value; 
                    } else if (param.name == 'iDisplayLength') {
                        iDisplayLength = param.value;
                    }
                }
                params.push({name: 'pageNum', value: iDisplayStart / iDisplayLength});
                params.push.apply(params, extraParams);
            },
            "fnServerData": function (url, params, fnCallback, oSettings) {
                var timerId = setTimeout(function () {
                    NProgress.set(Math.random() * 0.4);
                    NProgress.inc();
                }, 300);
                oSettings.jqXHR = $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": url,
                    "data": params,
                    "success": function (data) {
                        timerId && clearTimeout(timerId);
                        timerId = null;
                        data = preprocessData(data || {});
                        fnCallback(data);
                        NProgress.done();
                    }
                });
            }
        });
        $(tableEl).data('data-table', dataTable);
    };
    createDataTable('#activeDevice', ROOT + '/Device/getpro', [{name: 'type', value: 0}]);
    createDataTable('#hasSim', ROOT + '/Device/getpro', [{name: 'type', value: 1}]);
    createDataTable('#noSim', ROOT + '/Device/getpro', [{name: 'type', value: 2}]);

    var deviceList = [];
    var projectList = [];
    var pList = [];
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>"
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>"
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>"


    $(document).ready(function () {
        getFilter();
    });

    function getFilter() {
        var data = { action: 'axo' };

        $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {

                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error("发生内部错误，未能获取项目列表！");
                        return false;
                    }
                    if (json) {

                        pList = json;
                        $.each(pList, function (index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
                bindSelectEvent();
            },
            complete: function () { //生成分页条
                getDataAll();
            },
            error: function () {
                $.gritter.error('加载机型、项目列表数据时出现错误，请重试');
            }
        });
    }

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function (index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml).trigger('change');
    }

    var bindSelectEvent = function () {

        $("#device").change(function () {
            var devicevalue = $("#device option:selected").val();
            if (devicevalue != '-1') {
                $('#project').empty();
                var optHtml = "<option value='-1'>全部项目</option>";
                $.each(pList, function (index, array) {
                    if (array.device == devicevalue) {
                        optHtml += "<option value='" + array.project + "'>" + array.project + "</option>";
                    }
                });
            } else {
                selectInit(projectList, 'project');
            }
            $('#project').append(optHtml);
            reloadData();
        });

        $("#project").change(function () {
            reloadData();
        });
    };

    var reloadData = function () {
        $('#activeDevice,#hasSim,#noSim').each(function () {
            $(this).data('data-table').fnPageChange('first');
        });
        getDataAll();
    };

    function getDataAll() {

        var mPv;
        if ($("#project option:selected").val() != '-1') mPv = $("#project option:selected").val();
        var mDv;
        if ($("#device option:selected").val() != '-1') mDv = $("#device option:selected").val();

        var data = { action: 'select' };

        if (mPv || mDv)
        { data = { action: 'select', pv: mPv, dv: mDv } };

        $.ajax({
            type: 'POST',
            url: ROOT + '/Device/getall',
            data: data,
            dataType: 'json',
            beforeSend: function () {

            },
            success: function (json) {

                $("#listcount").empty();


                var countdevide = "";
                var countall = json.countall;
                $.each(countall, function (index, array) { //遍历json数据列
                    countdevide += "<tr><td>" + array['totaldevice'] + "</td>" + "<td>" + array['project'] + "</td>" + "<td>" + array['totalyessim'] + "</td>" + "<td>" + array['totalnosim'] + "</td></tr>";
                });
                $("#listcount").append(countdevide);
            },
            complete: function () { //生成分页条
            },
            error: function () {
                $.gritter.error('获取总体概况的数据时出现错误，请重试');
            }
        });
    }

})();