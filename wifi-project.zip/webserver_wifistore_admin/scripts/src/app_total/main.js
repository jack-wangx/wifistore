(function () {

    $('select').select2();

    var preprocessData = function (data) {
        var result = {
            iTotalRecords: data.totals || 0,
            iTotalDisplayRecords: data.totals || 0,
            aaData: data.list || []
        };
        return result;
    };

    var createDataTable = function (tableEl, ajaxUrl) {
        var dataTable = $(tableEl).dataTable({
            "bJQueryUI": true,
            "sPaginationType": "full_numbers",
            "sDom": 't<"F"ip>',//'<""l>t<"F"fp>',
            'sAjaxSource': ajaxUrl,
            'bServerSide': true,
            "iDisplayLength": 10,
            'aoColumns': [
                {"mData": "rank"},
                {"mData": "appName"},
                {"mData": "total"}
            ],
            "fnServerParams": function (params) {
                var mPv = $('#project').val(),
                    mDv = $('#device').val(),
                    iDisplayStart = 0,
                    iDisplayLength = 10;

                if (mPv != -1) params.push({name: 'pv', value: mPv});
                if (mDv != -1) params.push({name: 'dv', value: mDv});
                for (var i = 0; i < params.length; i++) {
                    var param = params[i];
                    if (param.name == 'iDisplayStart') {
                        iDisplayStart = param.value; 
                    } else if (param.name == 'iDisplayLength') {
                        iDisplayLength = param.value;
                    }
                }
                params.push({name: 'pageNum', value: iDisplayStart / iDisplayLength});
            },
            "fnServerData": function (url, params, fnCallback, oSettings) {
                var timerId = setTimeout(function () {
                    NProgress.set(Math.random() * 0.4);
                    NProgress.inc();
                }, 300);
                oSettings.jqXHR = $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": url,
                    "data": params,
                    "success": function (data) {
                        timerId && clearTimeout(timerId);
                        timerId = null;
                        data = preprocessData(data || {});
                        fnCallback(data);
                        NProgress.done();
                    }
                });
            }
        });
        $(tableEl).data('data-table', dataTable);
    };
    createDataTable('#usedTime', ROOT + '/AppManager/getUsedTime');
    createDataTable('#usedCount', ROOT + '/AppManager/getUsedCount');
    createDataTable('#activeCount', ROOT + '/AppManager/getActivaction');

    var curPage = 1; //当前页码
    var total, pageSize, totalPage;
    //获取数据
    var reloadData = function() {
        $('.data-table').each(function () {
            $(this).data('data-table').fnPageChange('first');
        });
    };

    var deviceList = [];
    var projectList = [];
    var pList = [];

    $(document).ready(function () {
        getFilter();
    });
    var getFilter = function() {
        var data = { action: 'axo' };

        $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getaxo',
            data: data,
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error('发生内部错误，未能获取项目列表', '内部错误');
                        return false;
                    }
                    if (json) {
                        pList = json;
                        $.each(pList, function (index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
                bindSelectEvent();
            },
            complete: function () { //生成分页条

            },
            error: function () {
                $.gritter.error('加载设备、项目数据失败', '加载数据失败');
            }
        });
    };

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function (index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml).trigger('change');
    }

    var bindSelectEvent = function () {
        $("#device").change(function () {
            var devicevalue = $("#device").val(),
                optHtml = '';
            if (devicevalue != '-1') {
                $('#project').empty();
                optHtml = "<option value='-1'>全部项目</option>";
                $.each(pList, function (index, array) {
                    if (array.device == devicevalue) {
                        optHtml += "<option value='" + array.project + "'>" + array.project + "</option>";
                    }
                });
            } else {
                selectInit(projectList, 'project');
            }
            $('#project').append(optHtml);
            reloadData();
        });

        $("#project").change(function () {
            reloadData();
        });
    };
})();