﻿(function() {
    var mOwnlist = new Array();
    var availableList = new Array();
    var mAction = 'update';
    var group_id = GROUPID;
    var group_name;

    //--------------------- submit edited perms -------------------------------------

    function submitPermList(mData){
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/updatePermission',
            data: {'group_id':group_id,'action':mAction,'groups':mData},
            dataType:'json',
            beforeSend:function(){
                $("#submit_btn").attr("disabled","disabled");
            },
            success:function(json){
                switch(json.status){
                    case 1000:
                        $.gritter.success("修改权限组成功！");
                        window.location.href=ROOT + "/UserGroup/userGroup_manager";
                        break;
                    case 9999:
                        $.gritter.error("获取权限组数据失败: " + json.status);
                        break;
                    default:
                        $.gritter.error("发生未知错误！错误代码:" + json.status);
                        break;
                }
            },
            complete:function(){  
                $("#submit_btn").removeAttr("disabled");
            },
            error:function(){
                $.gritter.error('修改权限组时发生错误"');
                $("#submit_btn").removeAttr("disabled");
            }
        });
    }

    //--------------------- clear list ------------------------------------------
    function clearList(){
        $("#inherit_perm").find(".divCheck").each(function(index,e){$(this).remove();})
        $("#available_perm").find(".divCheck").each(function(index,e){$(this).remove();})
        $("#own_perm").find(".divCheck").each(function(index,e){$(this).remove();})
    }

    //--------------------- load perm lists -------------------------------------

    function getPermList(groupId){
        var data;
        data={'action':'select','group_id':groupId};
        $.ajax({
            type: 'POST',
            url: ROOT + '/UserGroup/getPermission',
            data: data,
            dataType:'json',
            beforeSend:function(){
                clearList();
            },
            success:function(json){
                //total = json.totals; //总记录数
                // alert(total);
                //pageSize = json.pageSize; //每页显示条数
                //curPage = page; //当前页
                //totalPage = json.totalPage; //总页数
                if(json!=null){
                    var inheritGroup = json.inheritgroup;
                    $("#inherit_perm").find(".divlabeltitle").text("继承自" + inheritGroup.name + "的权限");


                    var inheritList = json.inheritlist;
                    if(json.ownlist != null && json.ownlist.length > 0)
                    {mOwnlist = json.ownlist;}
                    if(json.availablelist != null && json.availablelist.length > 0)
                    {availableList = json.availablelist;}

                    updateShowPermList("#inherit_perm", inheritList);
                    updatePermList("#own_perm", mOwnlist);

                    updateAvaiPermList("#available_perm", availableList);

                    getEditedPermList("#own_perm");

                    initPage();
                }else{
                }
            },
            complete:function(){
            },
            error:function(){
                $.gritter("获取权限组数据时失败");
            }
        });
    }

    //--------------------- update inherit Perm list -------------------------------------

    function updateShowPermList(element, list)
    {
        if(list!=null){
            $.each(list,function(index,array){ //遍历json数据列
                var status = "disabled='disabled'";
                if(array["allow"] == "1")
                {
                    status += "checked='checked'";
                }
                var $a = createCheck("checkLabelAccess","checkAccessImage","checkbox",array['name'],array['value'] + "show",status);
                $(element).append($a);
            });
            widgetStyleInit();
        }else{return false;}
    }

    //--------------------- update inherit Perm list -------------------------------------

    function updatePermList(element, list)
    {
        if(list.length > 0){
            $(element).find(".divCheck").each(function(index,e){$(this).remove();})

            $.each(list,function(index,array){ //遍历json数据列
                var status = "";
		  
                if(array["allow"] == "1")
                {
                    status = "checked='checked'";
                }
                var $a = createCheck("checkLabelAccess","checkAccessImage","checkbox",array['name'],array['value'],status);
                $(element).append($a);
            });
            widgetStyleInit();
        }else{return false;}
    }

    //--------------------- update available Perm list -------------------------------------
	
    function updateAvaiPermList(element, list)
    {
        $(element).find(".divCheck").each(function(index,e){$(this).remove();});
        if(list.length > 0){
	
	
            $.each(list,function(index,array){ //遍历json数据列 
                var status = "";
                var $a = createCheck("checkLabel","checkImage","checkbox",array['name'],array['value'],status);
                $(element).append($a);
            });
            $(element).parent().find("#perm_type").find(".divRadio").each(function(index, element) {
                var a = $(this).find("input").attr("id");
                if( a == "allowId")
                {
                    $(this).find("label").click();
                }	
            });
            widgetStyleInit();
        }else{return false;}
    }

    //--------------------- bind result with group id -------------------------------------
	
    function bindJSON(list){
        var mOwnlist = new Array();
	

        $.each(list,function(index,array){ //遍历json数据列
            var ownlist = {"value" : array["value"], "allow" : array["allow"] };
            mOwnlist.push(ownlist);
        });

	


        var json = "{\"action\":\"update\",\"group_id\" : 22,\"ownlist\":[{\"allow\":\"allow\",\"value\":\"1234\"}]}";


        ///jsonData.ownlist = [{"allow":"allow","value":"1234"}];
        //alert(json);
        return mOwnlist;
        //return $.parseJSON(json);
    }

    //--------------------- get edited perm list -------------------------------------

    function getEditedPermList(element)
    {

        if($(element).find(".divCheck").length != 0){
            var jsonData = "{\"ownlist\":[";
            $(element).find(".divCheck").each(function(index, val){ //遍历json数据列

                var permId = $(this).find("input").attr("id");
                var status = $(this).find("input").attr("checked");
                var permName = $(this).find("span").text();
                if(status == "checked")
                {
                    status = "1";
                }else
                {
                    status="0"
                }
                jsonData += "{\"value\":\""+ permId +"\",\"allow\":\""+ status +"\",\"name\":\""+ permName +"\"},";
            });
	
            jsonData = jsonData.substring(0,jsonData.length-1) + "]}" ;
            return $.parseJSON(jsonData);
            //$.each(json.group,function(index,array){
            //		alert(array["value"]);
            //		alert(array["allow"]);
            //		});

        }else{return false;}
    }

    //--------------------- get add perm list -------------------------------------

    function getAddPermList(element)
    {
        var jsonData = "{\"addPermList\":[";
        var jsonDataAdd = "";
        var status = "";
	
        $(element).parent().find("#perm_type").find(".divRadio").each(function(index, element) {
            var a = $(this).find("input").attr("checked");
            var b = $(this).find("input").attr("id");
            if( a == "checked"  && b == "allowId")
            {
                status = "1";
            }else if( a == "checked"  && b == "denyId")
            {
                status = "0";
            }
        });
        $(element).find(".divCheck").each(function(index, val){ //遍历json数据列
		  
            var permId = $(this).find("input").attr("id");
            var selected = $(this).find("input").attr("checked");
            var permName = $(this).find("span").text();
		  
            if(selected == "checked")
            { 
                jsonDataAdd += "{\"value\":\""+ permId +"\",\"allow\":\""+ status +"\",\"name\":\""+ permName +"\"},";
            }
        });
        if(jsonDataAdd != ""){
            jsonData = jsonData + jsonDataAdd.substring(0,jsonDataAdd.length-1) + "]}" ;
        } else {
            $.gritter.warn("未选择权限");
            return false;
        }
        return $.parseJSON(jsonData);
        //$.each(json.group,function(index,array){
        //		alert(array["value"]);
        //		alert(array["allow"]);
        //		});
    }
	


    //--------------------- move perms from addlist to editedlist -------------------------------------
    function movePerm(element){
        var list = getAddPermList(element);
	
        $.each(list.addPermList,function(index, xArray){
            //alert(xArray["value"]);
            //alert(xArray["allow"]);
            var ownlist = {};
            ownlist.name = xArray["name"];
            ownlist.value = xArray["value"];
            ownlist.allow = xArray["allow"];
            mOwnlist.push(ownlist);
			
		
            $.each(availableList,function(index, yArray){
                if(xArray["value"] == yArray["value"]){
                    availableList.splice(index, 1);             
                    return false; 
                }
            })
				

        })
    }

    //--------------------- page init function ----------------------------
    function initPage(){
	
        $("#cancel_add").live({
            click: function(){
                closeEdit();
            }
        })
        $("#submit_edit_perm").live({
            click: function(){
                if (getEditedPermList("#own_perm").ownlist) {
                    mOwnlist = getEditedPermList("#own_perm").ownlist;submitPermList(bindJSON(mOwnlist));
                } else {
                    $.gritter.warn("未添加任何规则！")
                }
            }
        })
	
        $("#add_new_perm").live({
            click: function(){
                if(getEditedPermList("#own_perm")) {
                    mOwnlist = getEditedPermList("#own_perm").ownlist;
                }
                if(availableList) {
                    updateAvaiPermList("#available_perm", availableList);
                    showEdit();
                }
            }
        });
        $("#submit_add_perm").live({
            click: function(){
                movePerm("#available_perm");
                updateAvaiPermList("#available_perm", availableList);
                updatePermList("#own_perm", mOwnlist);
                closeEdit();
            }
        })
    }

    $(document).ready(function(e) {
        getPermList(group_id);
    })
})();