﻿(function() {
    $('select').select2();
    var deviceList = [];
    var projectList = [];
    var pList = [];
    var loadingRow = "<tr><td colspan='9'>正在载入数据...</td></tr>";
    var failedRow = "<tr><td colspan='9'>数据加载失败</td></tr>";
    var emptyRow = "<tr><td colspan='9'>没有数据</td></tr>";

    $(document).ready(function() {
        getFilter();

        $('.panelcontent tbody').on('click', ".downBtn", function(e) {
            e.stopPropagation();
            window.open($(this).attr('url'));
        });

        $('.panelcontent tbody').on('click', ".pushBtn", function(e) {
            e.stopPropagation();
            editPackges($(this).attr('uuid'), $(this).attr('ispush'), $(this).attr('code'));
        });
        $('.panelcontent tbody').on('click', ".deleteBtn", function(e) {
            e.stopPropagation();
            deletePackage($(this).attr('uuid'));
        });

        
    });

    var bindSelectEvent = function () {
        $("#device").change(function() {
            var devicevalue = $("#device option:selected").val(),
                optHtml = '';
            if (devicevalue != '-1') {
                $('#project').empty();
                optHtml = "<option value='-1'>全部项目</option>";
                $.each(pList, function(index, array) {
                    if (array.device == devicevalue) {
                        optHtml += "<option value='" + array.project + "'>" + array.project + "</option>";
                    }
                });
            } else {
                selectInit(projectList, 'project');
            }
            $('#project').append(optHtml);
            getFotaList();
        });

        $("#project").change(function() {
            getFotaList();
        });
    };

    function selectInit(list, type) {
        var optHtml;
        if (type == 'device') {
            optHtml = "<option value='-1'>全部机型</option>";
            target = "#device";
        } else if (type == 'project') {
            optHtml = "<option value='-1'>全部项目</option>";
            target = "#project";
        }
        $(target).empty();

        if (list) {
            $.each(list, function(index, value) {
                optHtml += "<option value='" + value + "'>" + value + "</option>";
            });
        }
        $(target).append(optHtml).trigger('change');
    }

    function getFilter() {
        var data = { action: 'axo' };
        $.ajax({
            type: 'POST',
            url: ROOT + '/AXO/getAXO',
            data: data,
            dataType: 'json',
            beforeSend: function() {
            },
            success: function(json) {
                if (json) {
                    if (json.status == 9999) {
                        $.gritter.error('发生内部错误，未能获取项目列表！');
                        return false;
                    }
                    if (json) {
                        pList = json;
                        $.each(pList, function(index, array) {
                            deviceList.push(array.device);
                            projectList.push(array.project);
                        });
                        deviceList = deviceList.unique();
                        selectInit(deviceList, 'device');
                        projectList = projectList.unique();
                        selectInit(projectList, 'project');
                    }
                } else {
                    selectInit(null, 'device');
                    selectInit(null, 'project');
                }
                getFotaList();
                bindSelectEvent();
            },
            complete: function() { //生成分页条

            },
            error: function() {
                $.gritter.error('获取项目列表数据时出现错误，请重试');
            }
        });
    }

    var otainfos;

    function getFotaList() {

        var mPv;
        if ($("#project option:selected").val() != '-1') mPv = $("#project option:selected").val();
        var mDv;
        if ($("#device option:selected").val() != '-1') mDv = $("#device option:selected").val();

        data = { action: 'select', pv: mPv, dv: mDv };

        $.ajax({
            type: 'POST',
            url: ROOT + '/Fota/getOtaList',
            data: data,
            dataType: 'json',

            beforeSend: function() {
                $("#status").empty();
                $("#task").empty();
                $("#status").append(loadingRow);
            },
            success: function(json) {

                var att;
                var pushStr;
                var createStr;
                if (json && json != '') {
                    if (json.status && json.status != '') {

                        switch (json.status) {
                        case 1002:
                            $("#task").empty();
                            $("#status").empty();
                            $("#status").append(emptyRow);
                            return false;
                        case 9999:
                            $.gritter.error('获取OTA包列表时出现错误');
                            return;
                        case 1000:
                            if (json.list && json.list.length > 0) {
                                var li = "";
                                var list = json.list;
                                otainfos = new Array();
                                $.each(list, function(index, array) {
                                    if (array['create'] == '-1') {
                                        att = "disabled";
                                        img = "<img src='../style/img/indicator_loading.gif'>";
                                    } else {
                                        att = "";
                                        img = "";
                                    }
                                    switch (array['ispush']) {
                                    case '1':
                                        pushStr = "推送处理中";
                                        pushBtnStr = "取消推送";
                                        break;
                                    case '0':
                                        pushStr = "未推送";
                                        pushBtnStr = "推送";
                                        break;
                                    case '-1':
                                        pushStr = "正在推送";
                                        pushBtnStr = "取消推送";
                                        break;
                                    case '2':
                                        pushStr = "推送失败";
                                        pushBtnStr = "推送";
                                        break;
                                    default:
                                        pushStr = "未知状态";
                                        pushBtnStr = "无法操作";
                                        att = "disabled";
                                        break;
                                    }

                                    switch (array['create']) {
                                    case '1':
                                        createStr = "生成成功有警告";
                                        break;
                                    case '0':
                                        createStr = "生成成功";
                                        break;
                                    case '-1':
                                        createStr = "生成中";
                                        break;
                                    case '2':
                                        createStr = "生成失败";
                                        break;
                                    defaultkey: "value", 
                                        createStr = "未知状态";
                                        att = "disabled";
                                        break;
                                    }
                                    otainfos[array['versionCode']] = array;
                                    var itemInfo = "<p><span>文件名：</span>" + array['filename'] + "</p><p><span>md5值：</span>" + array['md5value'] + "</p><p><span>异常信息：</span>" + array['errormessage'] + "</p>";
                                    li += ["<tr rel='" + array['versionCode'] + "'>",
                                            "<td id='app'>" + array['devicemodel'] + "</td>",
                                            "<td id='app'>" + array['projectname'] + "</td>",
                                            "<td>" + array['versionCode'] + "</td>",
                                            "<td>" + array['uploadtime'] + "</td>",
                                            "<td>" + img + createStr + "，" + pushStr + "</td>",
                                            "<td>",
                                                "<button class='downBtn btn btn-small' url='", array['downloadurl'] ,"'><i class='icon-download'></i> 点击下载</button> ",
                                                "<button class='pushBtn btn btn-small' uuid='", array['uuid'], "' ispush='", array['ispush'], "' code='", array['code'], "' ", att, ">", pushBtnStr, "</button> ",
                                                "<button class='deleteBtn btn btn-small' url='", array['uuid'] ,"'><i class='icon-remove'></i> 删除</button>",
                                            "</td>", 
                                           "</tr>"].join('');
                                });

                                $("#status").empty();
                                $("#task").empty();
                                $("#task").append(li);
                            } else {
                                $("#task").empty();
                                $("#status").empty();
                                $("#status").append(emptyRow);
                            }


                            break;
                        default:
                            $("#task").empty();
                            $("#status").empty();
                            $("#status").append(failedRow);
                            return false;
                        }
                    }
                }

            },
            complete: function() { //生成分页条
            },
            error: function() {
                $("#task").empty();
                $("#status").empty();
                $("#status").append(failedRow);
            }
        });
    }

    function editPackges(Packges, status, code) {
        var name = Packges;
        $.ajax({
            type: 'POST',
            url: ROOT + '/Fota/editOta',
            data: 'Packges=' + name + "&status=" + status + "&code=" + code,
            dataType: 'json',
            beforeSend: function() {
            },
            success: function(json) {
                total = json.affected; //总记录数
                if (total == 0) {
                    $.gritter.success('操作通过');
                }
                if (total == -1) {
                    $.gritter.error('操作失败');
                }
                if (total == -2) {
                    $.gritter.error('操作失败');
                }
                getFotaList();
            },
            error: function() {
                $.gritter.error('操作失败');
            }
        });
    }

    function deletePackage(uuid) {

        var data = { 'action': 'delete', 'uuid': uuid };
        $.ajax({
            type: 'POST',
            url: ROOT + '/Fota/delOta',
            data: data,
            dataType: 'json',
            beforeSend: function() {
            },
            success: function(json) {
                if (json) {
                    var status = json.status;
                    if (status) {
                        switch (status) {
                        case 1000:
                            $.gritter.success('操作成功！');
                            getFotaList();
                            break;
                        case 9999:
                            $.gritter.error('操作失败！');
                            break;
                        default:
                            $.gritter.error('操作失败！');
                            break;
                        }
                    }
                }
            },
            error: function() {
                $.gritter.error('操作失败！');
            }
        });
    }

    $(".panelcontent tbody").on('click', 'tr', function() {
        var versionCode = $(this).attr('rel');

        var otainfo = otainfos[versionCode];
        $("#ota").empty();
        var otaUpgradeInfo = otainfo['otaUpgradeInfo'];
        var li = "<tr ><td><strong>机型:</strong></td><td>" + otainfo['devicemodel'] + "</td></tr>" +
            "<tr ><td><strong>项目:</strong</td><td>" + otainfo['projectname'] + "</td></tr>" +
            "<tr ><td><strong>版本号:</strong</td><td>" + otainfo['versionCode'] + "</td></tr>" +
            "<tr ><td><strong>文件名:</strong</td><td>" + otainfo['filename'] + "</td></tr>" +
            "<tr ><td><strong>md5值:</strong</td><td>" + otainfo['md5value'] + "</td></tr>" +
            "<tr ><td><strong>文件大小:</strong</td><td>" + otainfo['fileSize'] + "</td></tr>" +
            "<tr ><td><strong>打包时间:</strong</td><td>" + otainfo['uploadtime'] + "</td></tr>" +
            "<tr ><td><strong>备注:</strong</td><td>" + otainfo['versionMark'] + "</td></tr>" +
            "<tr><td><strong>升级反馈:</strong</td><td>升级率:" + otaUpgradeInfo['upgradeRate'] +
            "</br>升级成功率:" + otaUpgradeInfo['upgradeSuccessRate'] +
            "</br>升级总数:" + otaUpgradeInfo['upgradeSuccessCount'] +
            "</td></tr>";
        $("#ota").append(li);
        $('#modal').modal('show');
    });
})();