﻿module.exports = function (grunt) {
    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        uglify: {
            options: {
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd") %> */\n'
            },
            build: {
                src: 'scripts/src/<%= pkg.name %>.js',
                dest: 'scripts/build/<%= pkg.name %>.min.js'
            }
        },
        yuidoc: {
            compile: {
                name: '<%= pkg.name %>',
                description: '<%= pkg.description %>',
                version: '<%= pkg.version %>',
                url: '<%= pkg.homepage %>',
                options: {
                    paths: './scripts/src',
                    outdir: './scripts/doc'
                }
            }
        },
        connect: {
            options: {
                port: 9000,
                hostname: 'localhost'
            },
            test: {
                options: {
                    port: 9001
                }
            }
        },
        open: {
            server: {
                path: 'http://localhost:<%= connect.options.port %>'
            }
        },
        jasmine: {
            pivotal: {
                src: './scripts/src/**/*.js',
                options: {
                    specs: './scripts/specs/*-spec.js',
                    //template: require('./scripts/specs/spec-tpl.js'),
                    host: '<%= connect.test.options.host %>:<%= connect.test.options.port %>'
                }
            }
        },
        jshint: {
            all: [
              'Gruntfile.js',
              'scripts/src/*.js',
              'scripts/specs/*.js'
            ]
        },
        resolveDependency: {
            bower: true,
            'g.raphael': {
                repository: 'git://github.com/DmitryBaranovskiy/g.raphael',
                version: 'v0.5'
            },
            'uploadify': 'http://www.uploadify.com/wp-content/uploads/files/uploadify.zip'
        },
        copyAsset: {
            'Font-Awesome': {
                dest: 'vendor/font-awesome/',
                src: ['css/', 'font/']
            },
            'jquery': {
                dest: 'vendor/jquery',
                src: ['*.js', '*.map']
            },
            'jquery.tools': {
                dest: 'vendor/jquery.tools',
                src: ['src/*']
            },
            'jquery-validation': {
                dest: 'vendor/jquery-validation/',
                src: ['jquery.validate.js', 'additional-methods.js', 'localization/']
            },
            'Gritter': {
                dest: 'vendor/Gritter/',
                src: ['css/', 'images/', 'js/*.js']
            },
            'respond': {
                dest: 'vendor/respond/',
                src: ['*.js']
            },
            'raphael': {
                dest: 'vendor/raphael',
                src: ['*.js']
            },
            'g.raphael': {
                dest: 'vendor/raphael',
                src: ['g.*.js']
            },
            'es5-shim': {
                dest: 'vendor/es5-shim',
                src: ['*shim*.js', '*shim.map']
            },
            'gsap': {
                dest: 'vendor/gsap',
                src: ['src/uncompressed/*', 'src/minified/*']
            },
            'bootstrap': {
                dest: 'vendor/bootstrap/',
                src: ['img/', 'js/', 'less/bootstrap.less', 'less/responsive.less']
            }
        }
    });

    // Load the plugin that provides the "uglify" task.
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-open');
    grunt.loadNpmTasks('grunt-contrib-connect');
    grunt.loadNpmTasks('grunt-contrib-jasmine');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-git');
    grunt.loadNpmTasks('grunt-curl');
    require('./grunt-resolvedependency.js')(grunt);

    // Default task(s).
    grunt.registerTask('default', ['uglify']);
    //生成文档
    grunt.registerTask('doc', ['yuidoc']);
    //测试
    grunt.registerTask('test', [
                       'jshint',
                       'connect:test',
                       'jasmine:pivotal'
    ]);
};