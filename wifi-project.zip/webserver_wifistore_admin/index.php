<?php
include_once('./controller/allow.php');
switch (getPermission()) {
    case 1000:

        break;
    case 1001:
        header("Location:/dmc/index.php/Distribution/index");
        exit;
    case 1002:
        header("Location:/dmc/index.php/Account/login");
        exit;
    default:
        # code...
        break;
}
