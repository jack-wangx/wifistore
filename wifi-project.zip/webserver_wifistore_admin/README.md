# 内容管理平台概述

内容管理平台用于管理整个平台的资源内容

## 更新包

更新包用于更新站点的批量内容, 包括应用、游戏、视频、音乐及图片(以下称为**资源**). 更新包包含一系列**更新项**

## 更新项

更新包包含一批更新项, 更新项关联到具体的资源. 更新项中包含**资源标识**/**资源类型**/**更新动作**以及和具体更新动作关联的**资源信息**

### 资源标识

资源标识必须在全站点保持唯一, 以确保资源更新的一致性. 

### 资源类型

资源类型有5种: 应用/游戏/视频/图片/音乐

### 更新动作

包含, 新增/修改/删除

### 资源信息

不同资源类型的资源信息各异

1. 应用的资源信息
应用名/包名/应用文件/描述/截图

1. 游戏的资源信息
游戏名/包名/应用文件/描述/截图

1. 视频的资源信息
视频名/视频文件/描述/截图/

1. 图片的资源信息
图片名/图片文件/

1. 音乐的资源信息
歌曲名/歌曲文件/艺术家/专辑名/封面

## 内容管理平台的功能点

1. 用户消费信息
1. 资源管理

    1. 增删改资源信息
    1. 生成更新包及更新项

## 接口定义

* **内容相关**

    controller: Content

    ``` c#
    ///<summary>
    /// 返回列表页面
    ///<param name="type" type="string">内容的类型, 应用/游戏/壁纸/音乐/视频</param>
    ///</summary>
    list(string type)
    ```

    ``` c#
    ///<summary>
    /// 获取内容列表
    ///<param name="type" type="string">内容的类型, 应用/游戏/壁纸/音乐/视频</param>
    ///<param name="pageIndex" type="int">查询的页面索引</param>
    ///<param name="pageSize" type="int">页大小</param>
    ///<param name="sortField" type="string">排序的字段</param>
    ///<param name="filterWords" type="string">搜索的关键字</param>
    ///</summary>
    getList(string type, int pageIndex, int pageSize, string sortField, string filterWords)
    ```

    ``` c#
    ///<summary>
    /// 获取二级分类
    ///<param name="catId" type="string">内容的类型的guid</param>
    ///</summary>
    category(string catId)
    ```

    ``` c#
    ///<summary>
    /// 删除内容
    ///</summary>
    delete(string id)
    ```

    ``` c#
    ///<summary>
    /// method:get 返回内容新建页面
    ///</summary>
    add(string type)
    ```

    ``` c#
    ///<summary>
    /// 增加一个内容
    ///<param name="type" type="string">内容的类型, 应用/游戏/壁纸/音乐/视频</param>
    ///<param name="data" type="Array">json对象, 包含内容的属性, 不同的内容类型有不同的字段值</param>
    ///</summary>
    add(string type, Array data)
    ```

    ``` c#
    ///<summary>
    /// method:get 返回内容编辑页面
    ///</summary>
    update(string id, string type)
    ```

    ``` c#
    ///<summary>
    /// method:post 增加一个内容
    ///<param name="type" type="string">内容的类型, 应用/游戏/壁纸/音乐/视频</param>
    ///<param name="data" type="Array">json对象, 包含内容的属性, 不同的内容类型有不同的字段值</param>
    ///</summary>
    update(string type, Array data)
    ```

    ``` c#
    ///<summary>
    /// 上传文件
    ///<param name="type" type="string">内容的类型, 应用/游戏/壁纸/音乐/视频</param>
    ///<return type="JSONObject">
    /// 从文件中提取到的内容信息
    /// {status:1, data: {type: "", name: "", description: "" , xxx}}
    ///</return>
    ///</summary>
    upload(string type)
    ```

    ``` c#
    ///<summary>
    /// 返回导出更新包页面
    ///<param name="startDate" type="string">起始的内容更新日期</param>
    ///<param name="endDate" type="string">截止的内容更新日期</param>
    ///</summary>
    export(string startDate, string endDate);
    ```

    ``` c#
    ///<summary>
    /// 导出更新包
    ///<param name="startDate" type="string">起始的内容更新日期</param>
    ///<param name="endDate" type="string">截止的内容更新日期</param>
    ///<return>更新包</return>
    ///</summary>
    exportContents(string startDate, string endDate);
    ```
